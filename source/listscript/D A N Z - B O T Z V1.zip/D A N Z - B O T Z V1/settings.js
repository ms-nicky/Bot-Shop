require("./all/module.js")

//========== Setting Owner ==========//
global.owner = "6285664637742" //ganti nomor kalian
global.bot = "6285664637742" //wajib di ganti 
global.namaowner = "DanzMarketplace" //ganti nama owner
global.namaKontak = "Pushkontak By Danzz"
global.v = "V1"
global.type = "case"

//======== Delay Botz ========//
global.delaypushkontak = "5000"
global.delayjpm = "5000"

//======== Setting Bot & Link ========//
global.namabot = "*\`乂 D A N Z - B O T Z 乂\`*" // ganti nama bot
global.idsaluran = "120363364159254858@newsletter" // ganti id saluran @newsletter
global.linkgc = 'https://chat.whatsapp.com/Kz6JWbQY6m7A0aKUDfEi8r'
global.linktesti = 'https://whatsapp.com/channel/0029Vb1r2d95vKABTDoMOu0K'
global.packname = "Stiker By DanzzBot"
global.author = "Anomali Danz"

//========== Setting Event ==========//
global.welcome = false
global.autoread = false
global.anticall = false

//==== Waktu Jeda Jpm & Pushkon ====//
global.delaypushkontak = 5500
global.delayjpm = 5500

//========= Setting Url Foto =========//
global.image = "https://img101.pixhost.to/images/330/550821732_skyzopedia.jpg"
global.imgfake = "https://img101.pixhost.to/images/330/550821732_skyzopedia.jpg"
global.qris = "https://img101.pixhost.to/images/330/550821732_skyzopedia.jpg"

//========= Setting Payment =========//
global.dana = "089690235468"
global.qris = "https://img101.pixhost.to/images/330/550822234_skyzopedia.jpg"

//========= Setting Message =========//
global.msg = {
"error": "*\`乂 D A N Z - B O T Z 乂\`*\nTerjadi kesalahan saat menggunakan fitur",
"done": "*\`乂 D A N Z - B O T Z 乂\`*\nFitur sudah selesai", 
"premium": "*\`乂 D A N Z - B O T Z 乂\`*\nFitur hanya bisa diakses oleh *premium*", 
"wait": "*\`乂 D A N Z - B O T Z 乂\`*\nSedang menjalankan fitur", 
"group": "*\`乂 D A N Z - B O T Z 乂\`*\nFitur hanya bisa diakses di group", 
"private": "*\`乂 D A N Z - B O T Z 乂\`*\nHanya bisa diakses di pribdi botz", 
"admin": "*\`乂 D A N Z - B O T Z 乂\`*\nHanya admin group", 
"adminbot": "*\`乂 D A N Z - B O T Z 乂\`*\nBot harus admin", 
"owner": "*\`乂 D A N Z - B O T Z 乂\`*\nHanya bisa di akses owner", 
"developer": "*\`乂 D A N Z - B O T Z 乂\`*\nHanya bisa di akses developer"
}


let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})