module.exports = async (danzz, m, store) => {
try {
const body = (m.mtype === 'conversation' && m.message.conversation) ? m.message.conversation : (m.mtype == 'imageMessage') && m.message.imageMessage.caption ? m.message.imageMessage.caption : (m.mtype == 'documentMessage') && m.message.documentMessage.caption ? m.message.documentMessage.caption : (m.mtype == 'videoMessage') && m.message.videoMessage.caption ? m.message.videoMessage.caption : (m.mtype == 'extendedTextMessage') && m.message.extendedTextMessage.text ? m.message.extendedTextMessage.text : (m.mtype == 'buttonsResponseMessage' && m.message.buttonsResponseMessage.selectedButtonId) ? m.message.buttonsResponseMessage.selectedButtonId : (m.mtype == 'templateButtonReplyMessage') && m.message.templateButtonReplyMessage.selectedId ? m.message.templateButtonReplyMessage.selectedId : ''
const budy = (typeof m.text == 'string' ? m.text : '')
const prefix = /.]/.test(body) ? body.match(/.]/gi) : '.'
const isCmd = body.startsWith(prefix)
const command = isCmd ? body.slice(prefix.length).trim().split(' ').shift().toLowerCase() : '' //kalau mau no prefix ganti jadi ini : const command = body.replace(prefix, '').trim().split(/ +/).shift().toLowerCase()
const cmd = prefix + command
const args = body.trim().split(/ +/).slice(1)
const quoted = m.quoted ? m.quoted : m
const mime = (quoted.msg || quoted).mimetype || ''
const qmsg = (quoted.msg || quoted)
const text = q = args.join(" ")
const botNumber = await danzz.decodeJid(danzz.user.id)
const owners = JSON.parse(fs.readFileSync("./all/database/owner.json"))
const isOwner = m.sender == owner+"@s.whatsapp.net" ? true : m.sender == botNumber ? true : false
const isGroup = m.chat.endsWith('@g.us')
const senderNumber = m.sender.split('@')[0]
const pushname = m.pushName || `${senderNumber}`
const isBot = botNumber.includes(senderNumber)
const groupMetadata = isGroup ? await danzz.groupMetadata(m.key.remoteJid) : {}
let participant_bot = (isGroup ? groupMetadata.participants.find((v) => v.id == botNumber) : {}) || {}
let participant_sender = (isGroup ? groupMetadata.participants.find((v) => v.id == m.sender) : {}) || {}
const isBotAdmin = participant_bot?.admin !== null ? true : false
const isAdmin = participant_sender?.admin !== null ? true : false
const { runtime, getRandom, getTime, tanggal, toRupiah, telegraPh, pinterest, ucapan, generateProfilePicture, getBuffer, fetchJson } = require('./all/function.js')
const { toAudio, toPTT, toVideo, ffmpeg } = require("./all/converter.js")
const antilink = JSON.parse(fs.readFileSync('./all/database/antilink.json'))
const antilink2 = JSON.parse(fs.readFileSync('./all/database/antilink2.json'))
const contacts = JSON.parse(fs.readFileSync("./all/database/contacts.json"))
const premium = JSON.parse(fs.readFileSync("./all/database/premium.json"))
const isPremium = isOwner ? true : premium.includes(m.sender) ? true : false

if (isCmd) {
console.log(chalk.yellow.bgCyan.bold(namabot), color(`[ PESAN ]`, `blue`), color(`FROM`, `blue`), color(`${senderNumber}`, `blue`), color(`Text :`, `blue`), color(`${cmd}`, `white`))
}

if (isGroup && antilink.includes(m.chat) && isBotAdmin) {
if (!isAdmin && !isOwner && !m.fromMe) {
var link = /chat.whatsapp.com|buka tautaniniuntukbergabungkegrupwhatsapp/gi
if (link.test(m.text)) {
var gclink = (`https://chat.whatsapp.com/` + await danzz.groupInviteCode(m.chat))
var isLinkThisGc = new RegExp(gclink, 'i')
var isgclink = isLinkThisGc.test(m.text)
if (isgclink) return
let delet = m.key.participant
let bang = m.key.id
await danzz.sendMessage(m.chat, {text: `@${m.sender.split("@")[0]} Maaf Kamu Akan Saya Keluarkan Dari Grup Ini Karna Admin/Owner Bot Menyalakan Fitur *Antilink* Grup Lain!`, contextInfo: {mentionedJid: [m.sender], externalAdReply: {thumbnailUrl: "https://k.top4top.io/p_32569m9nv0.jpg", title: "ï½¢ LINK GRUP DETECTED ï½£", previewType: "PHOTO"}}}, {quoted: m})
await danzz.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: bang, participant: delet }})
await danzz.groupParticipantsUpdate(m.chat, [m.sender], "remove")
}
}}

if (isGroup && antilink2.includes(m.chat) && isBotAdmin) {
if (!isAdmin && !isOwner && !m.fromMe) {
var link = /chat.whatsapp.com|buka tautaniniuntukbergabungkegrupwhatsapp/gi
if (link.test(m.text)) {
var gclink = (`https://chat.whatsapp.com/` + await danzz.groupInviteCode(m.chat))
var isLinkThisGc = new RegExp(gclink, 'i')
var isgclink = isLinkThisGc.test(m.text)
if (isgclink) return
let delet = m.key.participant
let bang = m.key.id
await danzz.sendMessage(m.chat, {text: `@${m.sender.split("@")[0]} Maaf Pesan Kamu Saya Hapus Karna Admin/Owner Bot Menyalakan Fitur *Antilink* Grup Lain!`, contextInfo: {mentionedJid: [m.sender], externalAdReply: {thumbnailUrl: "https://k.top4top.io/p_32569m9nv0.jpg", title: "ï½¢ LINK GRUP DETECTED ï½£", previewType: "PHOTO"}}}, {quoted: m})
await danzz.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: bang, participant: delet }})
}
}}

const qdoc = {key : {participant : '0@s.whatsapp.net', ...(m.chat ? { remoteJid: `status@broadcast` } : {}) },message: {documentMessage: {title: 'Whatsapp Bot By DanzMarketplace',jpegThumbnail: ""}}}

const qloc = {key: {participant: '0@s.whatsapp.net', ...(m.chat ? {remoteJid: `status@broadcast`} : {})}, message: {locationMessage: {name: `Whatsapp Jpm By ${global.namaowner}`,jpegThumbnail: ""}}}

const qloc2 = {key: {participant: '0@s.whatsapp.net', ...(m.chat ? {remoteJid: `status@broadcast`} : {})}, message: {locationMessage: {name: `Whatsapp Bot By ${global.namaowner}`,jpegThumbnail: ""}}}

const qpayment = {key: {remoteJid: '0@s.whatsapp.net', fromMe: true, id: `namaowner`, participant: '0@s.whatsapp.net'}, message: {requestPaymentMessage: {currencyCodeIso4217: "USD", amount1000: 999999999, requestFrom: '0@s.whatsapp.net', noteMessage: { extendedTextMessage: { text: "Simple Botz"}}, expiryTimestamp: 999999999, amount: {value: 91929291929, offset: 1000, currencyCode: "USD"}}}}

let example = (teks) => {
return `\n*Contoh Penggunaan :*\nketik *${cmd}* ${teks}\n`
}

var resize = async (image, width, height) => {
let oyy = await Jimp.read(image)
let kiyomasa = await oyy.resize(width, height).getBufferAsync(Jimp.MIME_JPEG)
return kiyomasa
}

function capital(string) {
  return string.charAt(0).toUpperCase() + string.slice(1);
}

const createSerial = (size) => {
return crypto.randomBytes(size).toString('hex').slice(0, size)
} 

//=====[ Func Reply ]
async function DnzReply(teks, jid = m.chat, mention = []) {
await danzz.sendMessage(jid, {text: `${teks}`, contextInfo: {mentionedJid: mention, externalAdReply: {thumbnailUrl: global.imgfake, title: "© Powered By DanzzMarketplace", body: ` Powered By ${namaowner}`, 
previewType: "NONE"}}}, {quoted: m})
}

if (isCmd && !isPremium) {
return danzz.sendMessage(m.chat, {text: global.msg.premium, mentions: [m.sender], contextInfo: {
isForwarded: true, 
forwardingScore: 9999, 
businessMessageForwardInfo: { businessOwnerJid: global.owner+"@s.whatsapp.net" }, forwardedNewsletterMessageInfo: { newsletterName: `${global.namabot}`, newsletterJid: global.idsaluran }, 
externalAdReply: {
title: global.namabot, 
body: `© Powered By Powered By ${global.namaowner}`, 
thumbnailUrl: global.image, 
sourceUrl: null, 
}}}, {quoted: null})
}

switch (command) {
case "danz": case "menu": {
await danzz.sendMessage(m.chat, { react: { text: '🔥', key: m.key } })
let teksnya = `
╭────『 \`D A N Z - B O T Z\` 』
├ ▧ NamaOwner : ${global.namaowner}
├ ▧ NomorOwner : ${global.owner}
├ ▧ VersiScript : ${global.v}
├ ▧ TypeScript : ${global.type}
├ ▧ NomorBotz : ${danzz.user.id.split(":")[0]}
╰─────────────

*— Jpm-Menu*
々 .jpmch
々 .jpm
々 .jpm2
々 .jpmhidetag
々 .jpmtesti

*— Pushkontak-Menu*
々 .pushkontak
々 .pushkontak1
々 .pushkontak2

*— CekId-Menu*
々 .cekidgc
々 .cekidch

*— Savekontak-Menu*
々 .savekontak

*— Payment-Menu*
々 .dana
々 .qris

*— Store-Menu*
々 .done
々 .proses

*— Produk-Menu*
々 .hargaptreodactyl
々 .hargascript
`
await danzz.sendMessage(m.chat, {video: fs.readFileSync("./media/dan.mp4"), caption: `${teksnya}`, gifPlayback: true, contextInfo: {
isForwarded: true, 
forwardingScore: 9999, 
businessMessageForwardInfo: { businessOwnerJid: global.owner+"@s.whatsapp.net" }, forwardedNewsletterMessageInfo: { newsletterName: `${global.namabot}`, newsletterJid: global.idsal }, 
mentionedJid: [global.namaowner+"@s.whatsapp.net", m.sender], externalAdReply: {containsAutoReply: true, thumbnailUrl: global.image, title: `© Copyright By ${namaowner}`, 
renderLargerThumbnail: true, sourceUrl: global.saluran, mediaType: 1}}}, {quoted: qdoc})

await danzz.sendMessage(m.chat, {audio: fs.readFileSync("./media/sigma.mp3"), mimetype: "audio/mpeg", ptt: true})
}
break

case "jpmallch": case "jpmch": {
 if (!isOwner) return DnzReply(msg.owner); // Periksa apakah pengguna adalah Owner
 if (!text) return DnzReply("teksnya"); // Periksa apakah teks tersedia
 
 // Daftar saluran WhatsApp (array berisi ID saluran WhatsApp)
 const daftarSaluran = [
"120363359997306140@newsletter",
"120363360931081918@newsletter",
"120363361135749739@newsletter",
"120363380847203061@newsletter",
"120363296267647634@newsletter",
"120363362120667402@newsletter",
"120363372134164940@newsletter",
"120363359100834951@newsletter",
"120363364058382744@newsletter",
"120363298018430229@newsletter",
// Tambahkan ID saluran lainnya
 ];

 // Kirim pesan ke semua saluran dalam daftar
 for (const idSaluran of daftarSaluran) {
 try {
 await danzz.sendMessage(idSaluran, { text: text }); // Mengirim pesan ke saluran
 } catch (error) {
 console.error(`Gagal mengirim ke saluran ${idSaluran}:`, error); // Log jika gagal
 }
 }
 DnzReply("*Berhasil mengirim teks ke channel*");
}
break
case "jpmhidetag": {
if (!isOwner) return DnzReply(msg.owner)
if (!text && !m.quoted) return DnzReply(example("teksnya atau reply teks"))
var teks = m.quoted ? m.quoted.text : text
let total = 0
let getGroups = await danzz.groupFetchAllParticipating()
let groups = Object.entries(getGroups).slice(0).map((entry) => entry[1])
let usergc = groups.map((v) => v.id)
m.reply(`Processing sending text message to ${usergc.length} groups`)
for (let jid of usergc) {
try {
await danzz.sendMessage(jid, {text: teks, mentions: getGroups[jid].participants.map(e => e.id)}, {quoted: qloc})
total += 1
} catch (e) {
console.log(e)
}
await sleep(global.delayjpm)
}
DnzReply(`Successfully sent message to ${total} groups`)
}
break
case "jpm": {
if (!isOwner) return DnzReply(msg.owner)
if (!text && !m.quoted) return m.reply(example("teksnya atau replyteks"))
var teks = m.quoted ? m.quoted.text : text
let total = 0
let getGroups = await danzz.groupFetchAllParticipating()
let groups = Object.entries(getGroups).slice(0).map((entry) => entry[1])
let usergc = groups.map((v) => v.id)
m.reply(`Processing sending text message to ${usergc.length} groups`)
for (let jid of usergc) {
try {
await danzz.sendMessage(jid, {text: teks}, {quoted: qloc})
total += 1
} catch {}
await sleep(global.delayjpm)
}
DnzReply(`Successfully sent message to ${total} groups`)
}
break
case "jpm2": {
if (!isOwner) return DnzReply(msg.owner)
if (!text) return DnzReply(example("teksnya dengan balas/kirim foto"))
if (!/image/.test(mime)) return m.reply(example("teksnya dengan balas/kirim foto"))
let image = await danzz.downloadAndSaveMediaMessage(qmsg)
let total = 0
let getGroups = await danzz.groupFetchAllParticipating()
let groups = Object.entries(getGroups).slice(0).map((entry) => entry[1])
let usergc = groups.map((v) => v.id)
DnzReply(`Processing sending text & photo message to ${usergc.length} groups`)
for (let jid of usergc) {
try {
danzz.sendMessage(jid, {image: await fs.readFileSync(image), caption: text, contextInfo: {forwardingScore: 1,
isForwarded: true}}, {quoted: qloc})
total += 1
} catch {}
await sleep(global.delayjpm)
}
await fs.unlinkSync(image)
DnzReply(`Successfully sent message to ${total} groups`)
}
break
case "jpmtesti": {
if (!isOwner) return DnzReply(msg.owner)
if (!text) return DnzReply("teksnya dengan balas/kirim foto")
if (!/image/.test(mime)) return m.reply(example("teksnya dengan balas/kirim foto"))
let image = await danzz.downloadAndSaveMediaMessage(qmsg)
if (global.idsal == "120363375814628609@newsletter") return m.reply('Mohon isi ID Saluran di file setting.js pada panelmu.')
let total = 0
let getGroups = await danzz.groupFetchAllParticipating()
let groups = Object.entries(getGroups).slice(0).map((entry) => entry[1])
let usergc = groups.map((v) => v.id)
DnzReply(`Successfully sent message to ${total} groups`)
for (let jid of usergc) {
try {
danzz.sendMessage(jid, {image: await fs.readFileSync(image), caption: text, contextInfo: {forwardingScore: 1,
isForwarded: true, forwardedNewsletterMessageInfo: {newsletterJid: global.idsal, serverMessageId: 100, 
newsletterName: `Testimoni [ DanzzMarketplace ]`
}}}, {quoted: qloc})
total += 1
} catch {}
await sleep(global.delayjpm)
}
await fs.unlinkSync(image)
DnzReply(`Successfully sent message to ${total} groups`)
}
break

/*=========================
========= PAY MENU=======*/

case "dana": {
if (!isOwner) return DnzReply(msg.owner)
let teks = `
*PAYMENT DANA DANZMARKETPLACE*

* *Nomor :* ${global.dana}
* *Atas Nama :* Z*** R*******

*[ ! ] Penting :* \`\`\`Wajib kirimkan bukti transfer demi keamanan bersama\`\`\`
`
await danzz.sendMessage(m.chat, {text: teks}, {quoted: qpayment})
}
break

case "qris": {
if (!isOwner) return DnzReply(msg.owner)
await danzz.sendMessage(m.chat, {image: {url: global.qris}, caption: "\n*PAYMENT QRIS DANZPEDIA*\n\n*[ ! ] Penting :* \`\`\`Wajib kirimkan bukti transfer demi keamanan bersama\`\`\`"}, {quoted: qpayment})
}
break

/*========================
======== STORE MENU ======*/

case "done": {
if (!isOwner) return DnzReply(msg.owner)
if (!q) return DnzReply("jasa install panel")
let teks = `📦 ${text}
⏰ ${tanggal(Date.now())}

*Testimoni :*
${global.linktesti}

*Marketplace :*
${global.linkgc}`
await danzz.sendMessage(m.chat, {text: teks, mentions: [m.sender], contextInfo: {
externalAdReply: {
title: `Transaksi Done ✅`, 
body: `© Powered By ${namaowner}`, 
thumbnailUrl: global.imgfake, 
sourceUrl: linktesti,
}}}, {quoted: null})
}
break

case "proses": {
if (!isOwner) return DnzReply(msg.owner)
if (!q) return DnzReply("jasa install panel")
let teks = `📦 ${text}
⏰ ${tanggal(Date.now())}

*Testimoni :*
${global.linktesti}

*Marketplace :*
${global.linkgc}`
await danzz.sendMessage(m.chat, {text: teks, mentions: [m.sender], contextInfo: {
externalAdReply: {
title: `Dana Masuk ✅`, 
body: `© Powered By ${namaowner}`, 
thumbnailUrl: global.image, 
sourceUrl: linktesti,
}}}, {quoted: null})
}
break

case "hargaptero": case "hargapterodactyl": {
let teks = `
* *Reseller Panel*
* *Price : 5.000*

* *Admin Panel*
* *Price : 8.000*

* *Partner Panel*
* *Price : 15.000*

* *Owner Panel*
* *Price : 22.000*
`
await danzz.sendMessage(m.chat, {text: teks, mentions: [m.sender], contextInfo: {
externalAdReply: {
title: `Harga Pterodactyl`, 
body: `© Powered By ${namaowner}`, 
thumbnailUrl: global.image, 
sourceUrl: linktesti,
}}}, {quoted: null})
}
break

case "hargasc": case "hargascript": {
let teks = `
* *SimpleScript V1*
* *Price 6.000*

*— Fitur*
* JpmAllCh
* Pushkontak
* Savekontak
* Cekidgc
* Cekidch
* Free Update ( 1X )
`
await danzz.sendMessage(m.chat, {text: teks, mentions: [m.sender], contextInfo: {
externalAdReply: {
title: `Script Versi 1`, 
body: `© Powered By ${namaowner}`, 
thumbnailUrl: global.image, 
sourceUrl: linktesti,
}}}, {quoted: null})
}
break
/*=========================
==========================
==========[ PUSH + SAVE NON ID X REQUIRE ID ]===========*/
case "cekidgc": {
let gcall = Object.values(await danzz.groupFetchAllParticipating().catch(_=> null))
let listgc = `*｢ LIST ALL CHAT GRUP ｣*\n\n`
await gcall.forEach((u, i) => {
listgc += `*• Nama :* ${u.subject}\n*• ID :* ${u.id}\n*• Total Member :* ${u.participants.length} Member\n*• Status Grup :* ${u.announce == true ? "Tertutup" : "Terbuka"}\n*• Pembuat :* ${u.owner ? u.owner.split('@')[0] : 'Sudah keluar'}\n\n`
})
DnzReply(listgc)
}
break
case "cekidch": case "idch": {
if (!text) return DnzReply("linkchnya")
if (!text.includes("https://whatsapp.com/channel/")) return m.reply("Link tautan tidak valid")
let result = text.split('https://whatsapp.com/channel/')[1]
let res = await danzz.newsletterMetadata("invite", result)
let teks = `
* *ID :* ${res.id}
* *Nama :* ${res.name}
* *Total Pengikut :* ${res.subscribers}
* *Status :* ${res.state}
* *Verified :* ${res.verification == "VERIFIED" ? "Terverifikasi" : "Tidak"}
`
return DnzReply(teks)
}
break
case "pushkontak": case "pushkon": {
if (!isOwner) return m.reply(msg.owner)
if (!isGroup) return m.reply(msg.group)
if (!text) return m.reply(example("pesannya"))
var teks = text
const halls = await groupMetadata.participants.filter(v => v.id.endsWith('.net')).map(v => v.id)
m.reply(`\`乂 D A N Z - B O T Z 乂\`\n Pushkontak sedang dalam proses`)
for (let mem of halls) {
if (mem !== m.sender) {
contacts.push(mem)
await fs.writeFileSync('./all/database/contacts.json', JSON.stringify(contacts))
await danzz.sendMessage(mem, {text: teks}, {quoted: qloc2})
await sleep(global.delaypushkontak)
}}
try {
const uniqueContacts = [...new Set(contacts)]
const vcardContent = uniqueContacts.map((contact, index) => {
const vcard = [
"BEGIN:VCARD",
"VERSION:3.0",
`FN:${global.namaKontak} [${createSerial(2)}]`,
`TEL;type=CELL;type=VOICE;waid=${contact.split("@")[0]}:+${contact.split("@")[0]}`,
"END:VCARD",
"", ].join("\n")
return vcard }).join("")
fs.writeFileSync("./all/database/contacts.vcf", vcardContent, "utf8")
} catch (err) {
m.reply(err.toString())
} finally {
if (m.chat !== m.sender) await m.reply(`Successfully sent a message to ${halls.length} group members, contact file successfully sent to private chat by 𝐋𝐲𝐧𝐳𝐳𝐎𝐟𝐜`)
await danzz.sendMessage(m.sender, { document: fs.readFileSync("./all/database/contacts.vcf"), fileName: "contacts.vcf", caption: "Contact file successfully created by 𝐋𝐲𝐧𝐳𝐳𝐎𝐟𝐜", mimetype: "text/vcard", }, { quoted: m })
contacts.splice(0, contacts.length)
await fs.writeFileSync("./all/database/contacts.json", JSON.stringify(contacts))
await fs.writeFileSync("./all/database/contacts.vcf", "")
}}
break
case "pushkontak1": {
if (!isOwner) return m.reply(msg.owner)
if (!text) return m.reply(example("idgrup|pesan\n\nketik *.listgc* untuk melihat semua list id grup"))
if (!text.split("|")) return m.reply(example("idgrup|pesannya\n\nketik *.listgc* untuk melihat semua list id grup"))
var [idnya, teks] = text.split("|")
var groupMetadataa
try {
groupMetadataa = await danzz.groupMetadata(`${idnya}`)
} catch (e) {
return m.reply("*Invalid ID Group")
}
const participants = await groupMetadataa.participants
const halls = await participants.filter(v => v.id.endsWith('.net')).map(v => v.id)
m.reply(`\`乂 D A N Z - B O T Z 乂\`\n Pushkontak sedang dalam proses`)
for (let mem of halls) {
if (mem !== m.sender) {
contacts.push(mem)
await fs.writeFileSync('./all/database/contacts.json', JSON.stringify(contacts))
await danzz.sendMessage(mem, {text: teks}, {quoted: qloc2})
await sleep(global.delaypushkontak)
}}
try {
const uniqueContacts = [...new Set(contacts)]
const vcardContent = uniqueContacts.map((contact, index) => {
const vcard = [
"BEGIN:VCARD",
"VERSION:3.0",
`FN:${global.namaKontak} [${createSerial(2)}]`,
`TEL;type=CELL;type=VOICE;waid=${contact.split("@")[0]}:+${contact.split("@")[0]}`,
"END:VCARD",
"", ].join("\n")
return vcard }).join("")
fs.writeFileSync("./all/database/contacts.vcf", vcardContent, "utf8")
} catch (err) {
m.reply(err.toString())
} finally {
if (m.chat !== m.sender) await m.reply(`Successfully sent a message to ${halls.length} group members, contact file successfully sent to private chat by 𝐋𝐲𝐧𝐳𝐳𝐎𝐟𝐜`)
await danzz.sendMessage(m.sender, { document: fs.readFileSync("./all/database/contacts.vcf"), fileName: "contacts.vcf", caption: "Contact file successfully created by 𝐋𝐲𝐧𝐳𝐳𝐎𝐟𝐜", mimetype: "text/vcard", }, { quoted: m })
contacts.splice(0, contacts.length)
await fs.writeFileSync("./all/database/contacts.json", JSON.stringify(contacts))
await fs.writeFileSync("./all/database/contacts.vcf", "")
}}
break
case "pushkontak2": {
if (!isOwner) return DnzReply(msg.owner)
if (!text) return DnzReply("*Contoh Command :*\n.pushkontak2 idgc|jeda|pesan\n\n*Note :* Jeda 1 detik = 1000\nketik *.listgc* untuk melihat semua list id grup")
if (!text.split("|")) return m.reply("*Contoh Command :*\n.pushkontak2 idgc|jeda|pesan\n\n*Note :* Jeda 1 detik = 1000\nketik *.listgc* untuk melihat semua list id grup")
var idnya = text.split("|")[0]
var delay = Number(text.split("|")[1])
var teks = text.split("|")[2]
if (!idnya.endsWith("@g.us")) return m.reply("Invalid group ID format")
if (isNaN(delay)) return m.reply("Invalid delay format")
if (!teks) return m.reply("*Contoh Command :*\n.pushkontak2 idgc|jeda|pesan\n\n*Note :* Jeda 1 detik = 1000\nketik *.listgc* untuk melihat semua list id grup")
var groupMetadataa
try {
groupMetadataa = await danzz.groupMetadata(`${idnya}`)
} catch (e) {
return m.reply("Invalid group ID")
}
const participants = await groupMetadataa.participants
const halls = await participants.filter(v => v.id.endsWith('.net')).map(v => v.id)
DnzReply(`\`乂 D A N Z - B O T Z 乂\`\n Pushkontak sedang dalam proses`)
for (let mem of halls) {
if (mem !== m.sender) {
contacts.push(mem)
await fs.writeFileSync('./all/database/contacts.json', JSON.stringify(contacts))
await danzz.sendMessage(mem, {text: teks}, {quoted: qloc2})
await sleep(Number(delay))
}}
try {
const uniqueContacts = [...new Set(contacts)]
const vcardContent = uniqueContacts.map((contact, index) => {
const vcard = [
"BEGIN:VCARD",
"VERSION:3.0",
`FN:${global.namaKontak} [${createSerial(2)}]`,
`TEL;type=CELL;type=VOICE;waid=${contact.split("@")[0]}:+${contact.split("@")[0]}`,
"END:VCARD",
"", ].join("\n")
return vcard }).join("")
fs.writeFileSync("./all/database/contacts.vcf", vcardContent, "utf8")
} catch (err) {
m.reply(err.toString())
} finally {
if (m.chat !== m.sender) await m.reply(`Successfully sent a message to ${halls.length} group members, contact file successfully sent to private chat by 𝐋𝐲𝐧𝐳𝐳𝐎𝐟𝐜`)
await danzz.sendMessage(m.sender, { document: fs.readFileSync("./all/database/contacts.vcf"), fileName: "contacts.vcf", caption: "Contact file successfully created by 𝐋𝐲𝐧𝐳𝐳𝐎𝐟𝐜", mimetype: "text/vcard", }, { quoted: m })
contacts.splice(0, contacts.length)
await fs.writeFileSync("./all/database/contacts.json", JSON.stringify(contacts))
await fs.writeFileSync("./all/database/contacts.vcf", "")
}}
break
case "savekontak": {
if (!isOwner) return m.reply(msg.owner)
if (!isGroup) return m.reply(msg.group)
const halls = await groupMetadata.participants.filter(v => v.id.endsWith('.net')).map(v => v.id)
for (let mem of halls) {
if (mem !== m.sender) {
contacts.push(mem)
fs.writeFileSync('./all/database/contacts.json', JSON.stringify(contacts))
}}
try {
const uniqueContacts = [...new Set(contacts)]
const vcardContent = uniqueContacts.map((contact, index) => {
const vcard = [
"BEGIN:VCARD",
"VERSION:3.0",
`FN:${global.namaKontak} [${createSerial(2)}]`,
`TEL;type=CELL;type=VOICE;waid=${contact.split("@")[0]}:+${contact.split("@")[0]}`,
"END:VCARD",
"", ].join("\n")
return vcard }).join("")
fs.writeFileSync("./all/database/contacts.vcf", vcardContent, "utf8")
} catch (err) {
m.reply(err.toString())
} finally {
if (m.chat !== m.sender) await m.reply(`Contact file successfully sent to private chat by 𝐋𝐲𝐧𝐳𝐳𝐎𝐟𝐜`)
await Lynzid.sendMessage(m.sender, { document: fs.readFileSync("./all/database/contacts.vcf"), fileName: "contacts.vcf", caption: "Contact file successfully created by 𝐋𝐲𝐧𝐳𝐳𝐎𝐟𝐜", mimetype: "text/vcard", }, { quoted: m })
contacts.splice(0, contacts.length)
await fs.writeFileSync("./all/database/contacts.json", JSON.stringify(contacts))
await fs.writeFileSync("./all/database/contacts.vcf", "")
}}
break
default:
if (budy.startsWith('$')) {
if (!isOwner) return
exec(budy.slice(2), (err, stdout) => {
if(err) return danzz.sendMessage(m.chat, {text: err.toString()}, {quoted: m})
if (stdout) return danzz.sendMessage(m.chat, {text: util.format(stdout)}, {quoted: m})
})}

if (budy.startsWith(">")) {
if (!isOwner) return
try {
let evaled = await eval(text)
if (typeof evaled !== 'string') evaled = util.inspect(evaled)
danzz.sendMessage(m.chat, {text: util.format(evaled)}, {quoted: m})
} catch (e) {
danzz.sendMessage(m.chat, {text: util.format(e)}, {quoted: m})
}}

if (budy.startsWith("=>")) {
if (!isOwner) return
try {
const evaling = await eval(`;(async () => { ${text} })();`);
return danzz.sendMessage(m.chat, {text: util.format(evaling)}, {quoted: m})
} catch (e) {
return danzz.sendMessage(m.chat, {text: util.format(e)}, {quoted: m})
}}

}} catch (e) {
console.log(e)
danzz.sendMessage(`${owner}@s.whatsapp.net`, {text:`${util.format(e)}`})
}}

let file = require.resolve(__filename) 
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(chalk.redBright(`Update ${__filename}`))
delete require.cache[file]
require(file)
})