require("./all/module.js")

//========== Setting Owner ==========//
global.owner = "6285664637742" //ganti nomor kalian
global.namaowner = "DanzMarketplace" //ganti nama owner

//======== Setting Bot & Link ========//
global.namabot = "*\`乂 B O Y Z - B O T Z 乂\`*" // ganti nama bot
global.idsaluran = "120363364159254858@newsletter" // ganti id saluran @newsletter
global.linkgc = 'https://chat.whatsapp.com/Kz6JWbQY6m7A0aKUDfEi8r'
global.linktesti = 'https://whatsapp.com/channel/0029Vb1r2d95vKABTDoMOu0K'
global.packname = "Stiker By DanzzBot"
global.author = "Anomali Danz"

//
// Settings Api Panel Pterodactyl
global.egg = "15" // Egg ID
global.nestid = "5" // nest ID
global.loc = "1" // Location ID
global.domain = "https://fajri-offc.sandeva-hosting.my.id"
global.apikey = "ptla_OGzIcRdvqVq8LSH4i4NHhKOlqxX9bxToW0dcbyPncP5" //ptla
global.capikey = "ptlc_81JoG2B5S9InNztHRKHyNpdHMeqKLx5AO8ckAQzMsOP" //ptlc

//========== Setting Event ==========//
global.welcome = false
global.autoread = false
global.anticall = false

//========= Setting Url Foto =========//
global.image = "https://img101.pixhost.to/images/330/550821732_skyzopedia.jpg"
global.imgfake = "https://img101.pixhost.to/images/330/550821732_skyzopedia.jpg"
global.qris = "https://img101.pixhost.to/images/330/550821732_skyzopedia.jpg"

//========= Setting Message =========//
global.msg = {
"error": "*\`乂 B O Y Z - B O T Z 乂\`*\nTerjadi kesalahan saat menggunakan fitur",
"done": "*\`乂 B O Y Z - B O T Z 乂\`*\nFitur sudah selesai", 
"premium": "*\`乂 B O Y Z - B O T Z 乂\`*\nFitur hanya bisa diakses oleh *premium*", 
"wait": "*\`乂 B O Y Z - B O T Z 乂\`*\nSedang menjalankan fitur", 
"group": "*\`乂 B O Y Z - B O T Z 乂\`*\nFitur hanya bisa diakses di group", 
"private": "*\`乂 B O Y Z - B O T Z 乂\`*\nHanya bisa diakses di pribdi botz", 
"admin": "*\`乂 B O Y Z - B O T Z 乂\`*\nHanya admin group", 
"adminbot": "*\`乂 B O Y Z - B O T Z 乂\`*\nBot harus admin", 
"owner": "*\`乂 B O Y Z - B O T Z 乂\`*\nHanya bisa di akses owner", 
"developer": "*\`乂 B O Y Z - B O T Z 乂\`*\nHanya bisa di akses developer"
}


let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})