const fs = require('fs');
const chalk = require('chalk');

// Settings Bot 
global.owner = '628'
global.versi = "Unkown"
global.namaOwner = "p"
global.packname = 'b b'
global.botname = 'ha'
global.botname2 = 'tol'
global.type = 'kon'

global.tempatDB = 'database.json' // Jangan ubah
global.pairing_code = true // Jangan ubah

// Settings Link / Tautan
global.linkOwner = "https://wa.me/6285664637742"
global.linkGrup = "https://chat.whatsapp.com/FyqffgGmrNYK1b52xECZtk"
global.linkGrup2 = "https://chat.whatsapp.com/FyqffgGmrNYK1b52xECZtk"
global.imageh = false
global.imgfake = 'https://img0.pixhost.to/images/921/557863308_skyzopedia.jpg'
global.imgmenu = 'https://img97.pixhost.to/images/743/557317373_skyzopedia.jpg'

// Settings Channel / Saluran
global.linkSaluran = "https://whatsapp.com/channel/0029VayrD8xI1rcrL9sc4s03"
global.idSaluran = "120363373941283254@newsletter"
global.namaSaluran = "DanzBotz Channel"

// Message Command 
global.mess = {
	owner: "* *Akses Ditolak*\nFitur ini hanya untuk owner bot!",
	admin: "* *Akses Ditolak*\nFitur ini hanya untuk admin grup!",
	botAdmin: "* *Akses Ditolak*\nFitur ini hanya untuk ketika bot menjadi admin!",
	group: "* *Akses Ditolak*\nFitur ini hanya untuk dalam grup!",
	private: "* *Akses Ditolak*\nFitur ini hanya untuk dalam private chat!",
	prem: "* *Akses Ditolak*\nFitur ini hanya untuk user premium!",
	wait: 'Loading...',
	error: 'Error!',
	done: 'Done'
}

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})