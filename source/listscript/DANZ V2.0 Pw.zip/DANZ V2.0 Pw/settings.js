/* 

udah no enc guys jan lup masuk gb + foll ch

*/

const fs = require('fs');
const chalk = require('chalk');

// Settings Bot 
global.owner = '628892987132'
global.versi = "2.0"
global.namaOwner = "𝐃𝐚𝐧𝐳𝐇𝐨𝐬𝐭"
global.packname = '𝙱𝚘𝚝 𝚆𝚑𝚊𝚝𝚜𝙰𝚙𝚙'
global.botname = '𝙳𝚊𝚗𝚣𝙱𝚘𝚝𝚣'
global.botname2 = '𝙳𝚊𝚗𝚣𝚣𝙱𝚘𝚝𝚣'
global.type = 'case'

global.tempatDB = 'database.json' // Jangan ubah
global.pairing_code = true // Jangan ubah

// Settings Link / Tautan
global.linkOwner = "https://wa.me/6285664637742"
global.linkGrup = "https://chat.whatsapp.com/FyqffgGmrNYK1b52xECZtk"
global.linkGrup2 = "https://chat.whatsapp.com/FyqffgGmrNYK1b52xECZtk"
global.imageh = false
global.imgfake = 'https://img101.pixhost.to/images/330/550821732_skyzopedia.jpg'
global.imgmenu = 'https://img97.pixhost.to/images/743/557317373_skyzopedia.jpg'

// Delay Jpm & Pushctc || 1000 = 1detik
global.delayJpm = 3500
global.delayPushkontak = 6000

// Settings Channel / Saluran
global.linkSaluran = "https://whatsapp.com/channel/0029VayrD8xI1rcrL9sc4s03"
global.idSaluran = "120363373941283254@newsletter"
global.namaSaluran = "DanzBotz Channel"

global.merchantIdOrderKuota = "-"
global.apiOrderKuota = "-"
global.qrisOrderKuota = "-"

// Settings All Payment
global.dana = "089690235468"
global.ovo = "Tidak Tersedia"
global.gopay = "Tidak Tersedia"
global.qris = false

// Settings Api Panel Pterodactyl
global.egg = "15" // Egg ID
global.nestid = "5" // nest ID
global.loc = "1" // Location ID
global.domain = "https://fajri-offc.sandeva-hosting.my.id"
global.apikey = "ptla_OGzIcRdvqVq8LSH4i4NHhKOlqxX9bxToW0dcbyPncP5" //ptla
global.capikey = "ptlc_81JoG2B5S9InNztHRKHyNpdHMeqKLx5AO8ckAQzMsOP" //ptlc

// Settings Api Panel Pterodactyl Server 2
global.eggV2 = "15" // Egg ID
global.nestidV2 = "5" // nest ID
global.locV2 = "1" // Location ID
global.domainV2 = "https://-"
global.apikeyV2 = "-" //ptla
global.capikeyV2 = "-" //ptlc

// Settings Api Panel Pterodactyl Server 3
global.eggV3 = "15" // Egg ID
global.nestidV3 = "5" // nest ID
global.locV3 = "1" // Location ID
global.domainV3 = "https://-"
global.apikeyV3 = "-" //ptla
global.capikeyV3 = "-" //ptlc

// Settings Api Panel Pterodactyl Server 4
global.eggV4 = "15" // Egg ID
global.nestidV4 = "5" // nest ID
global.locV4 = "1" // Location ID
global.domainV4 = "https://-"
global.apikeyV4 = "-" //ptla
global.capikeyV4 = "-" //ptlc

// Settings Api Panel Pterodactyl Server 5
global.eggV5 = "15" // Egg ID
global.nestidV5 = "5" // nest ID
global.locV5 = "1" // Location ID
global.domainV5 = "https://-"
global.apikeyV5 = "-" //ptla
global.capikeyV5 = "-" //ptlc

// Settings Api Subdomain
global.subdomain = {
"digitalserver.biz.id": {
"zone": "c2047082b74a80e5be03959bad59592a", 
"apitoken": "SDG2MrxgoJLZ8GDkpWk2PalEn-Vg8PQkjEsPQ_Wy"
}, 
"marketplace.us.kg": {
"zone": "2f33118c3db00b12c38d07cf1c823ed1", 
"apitoken": "6WS_Op6yuPOWcO17NiO-sOP8Vq9tjSAFZyAn82db"
}, 
"serverpanell.biz.id": {
"zone": "225512a558115605508656b7bdf29b28", 
"apitoken": "XasxSSnGp8M9QixvT6AAlh1vEm4icVgzDyz7KDiF"
}, 
"sincecraf.my.id": {
"zone": "a89500d3dcf7e531f5a6e25081c7c874", 
"apitoken": "aV-ilSaLRwfgIGz0c79ah6fbnpcLilDREvysdUsk"
}, 
"xyz-store.biz.id": {
"zone": "8ae812c35a94b7bd2da993a777b8b16d", 
"apitoken": "oqZafkd3mSt1bABD9MMTidpCtD9VZdiPTjElVKJB"
}, 
"shopserver.us.kg": {
"zone": "54ca38e266bfdf2dcdb7f51fd79c2db5", 
"apitoken": "4qOupI-Of-6yNrBaeS1-H0KySuKCd0wS-x0P5XQ4"
}
}

// Message Command 
global.mess = {
	owner: "* *Akses Ditolak*\nFitur ini hanya untuk owner bot!",
	admin: "* *Akses Ditolak*\nFitur ini hanya untuk admin grup!",
	botAdmin: "* *Akses Ditolak*\nFitur ini hanya untuk ketika bot menjadi admin!",
	group: "* *Akses Ditolak*\nFitur ini hanya untuk dalam grup!",
	private: "* *Akses Ditolak*\nFitur ini hanya untuk dalam private chat!",
	prem: "* *Akses Ditolak*\nFitur ini hanya untuk user premium!",
	wait: 'Loading...',
	error: 'Error!',
	done: 'Done'
}

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})